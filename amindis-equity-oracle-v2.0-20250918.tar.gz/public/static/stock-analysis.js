// Stock Analysis page JavaScript
// This file handles the stock analysis page functionality

// Initialize the stock analysis page
document.addEventListener('DOMContentLoaded', function() {
    // Check if we have a symbol from the URL
    if (typeof urlSymbol !== 'undefined' && urlSymbol) {
        console.log('Loading analysis for symbol:', urlSymbol);
        loadStockAnalysis(urlSymbol);
    } else {
        showError('Aucun symbole d\'action fourni dans l\'URL');
    }
});

// Load stock analysis for the given symbol
async function loadStockAnalysis(symbol) {
    try {
        showLoadingState();
        
        // Fetch stock data
        const response = await axios.get(`/api/stock/${symbol}`);
        
        if (response.data.success) {
            // Store data globally for other functions
            currentData = response.data.data;
            filteredData = currentData;
            currentSymbol = response.data.symbol;
            currentCurrency = response.data.currency || 'USD';
            
            // Display the analysis
            displayCompanyInfo(response.data);
            displayChart(filteredData);
            displayData(filteredData);
            
            // Calculate and display financial metrics
            await calculateAndDisplayMetrics(response.data);
            
            // Load financial news
            await loadFinancialNews(response.data.symbol);
            
            // Show results section
            hideLoadingState();
            showResultsSection();
        } else {
            throw new Error(response.data.error || 'Erreur lors du chargement des données');
        }
    } catch (error) {
        console.error('Error loading stock analysis:', error);
        hideLoadingState();
        
        if (error.response?.status === 404) {
            showError(`Action "${symbol}" non trouvée. Vérifiez le symbole et réessayez.`);
        } else if (error.response?.status >= 500) {
            showError('Erreur du serveur. Veuillez réessayer plus tard.');
        } else {
            showError(`Erreur lors du chargement des données: ${error.message}`);
        }
    }
}

// Show loading state
function showLoadingState() {
    document.getElementById('loadingState').classList.remove('hidden');
    document.getElementById('resultsSection').classList.add('hidden');
    document.getElementById('errorState').classList.add('hidden');
}

// Hide loading state
function hideLoadingState() {
    document.getElementById('loadingState').classList.add('hidden');
}

// Show results section
function showResultsSection() {
    document.getElementById('resultsSection').classList.remove('hidden');
    document.getElementById('errorState').classList.add('hidden');
}

// Show error state
function showError(message) {
    document.getElementById('errorState').classList.remove('hidden');
    document.getElementById('loadingState').classList.add('hidden');
    document.getElementById('resultsSection').classList.add('hidden');
    document.getElementById('errorMessage').textContent = message;
}

// Update the page title with company info
function updatePageTitle(stockData) {
    let companyName = stockData.companyName;
    
    if (typeof getStockBySymbol !== 'undefined') {
        const europeanStock = getStockBySymbol(stockData.symbol);
        if (europeanStock) {
            companyName = europeanStock.name;
        }
    }
    
    document.title = `${stockData.symbol} - ${companyName} | Amindis Equity Oracle`;
}

// Calculate and display financial metrics with direct calculations
async function calculateAndDisplayMetrics(stockData) {
    try {
        console.log('Calculating financial metrics for', stockData.symbol, 'with', currentData.length, 'data points');
        
        // Simple direct calculations
        const metrics = calculateSimpleMetrics(currentData);
        
        // Display calculated metrics
        updateMetricDisplay('volatility5Y', metrics.volatility, '%');
        updateMetricDisplay('totalReturn5Y', metrics.totalReturn, '%');
        updateMetricDisplay('sharpeRatio', metrics.sharpeRatio);
        updateMetricDisplay('betaMarket', metrics.beta);
        updateMetricDisplay('alphaSector', metrics.alpha, '%');
        updateMetricDisplay('maxDrawdown', metrics.maxDrawdown, '%');
        updateMetricDisplay('sectorCorrelation', metrics.correlation);
        updateMetricDisplay('trackingError', metrics.trackingError, '%');
        
        console.log('Financial metrics calculated successfully:', metrics);
    } catch (error) {
        console.error('Error calculating financial metrics:', error);
        // Fill with placeholder values if calculation fails
        updateMetricDisplay('volatility5Y', 'N/A');
        updateMetricDisplay('totalReturn5Y', 'N/A');
        updateMetricDisplay('sharpeRatio', 'N/A');
        updateMetricDisplay('betaMarket', 'N/A');
        updateMetricDisplay('alphaSector', 'N/A');
        updateMetricDisplay('maxDrawdown', 'N/A');
        updateMetricDisplay('sectorCorrelation', 'N/A');
        updateMetricDisplay('trackingError', 'N/A');
    }
}

// Simple financial metrics calculations
function calculateSimpleMetrics(data) {
    if (!data || data.length < 2) {
        return {
            volatility: null,
            totalReturn: null,
            sharpeRatio: null,
            beta: null,
            alpha: null,
            maxDrawdown: null,
            correlation: null,
            trackingError: null
        };
    }

    // Extract closing prices and convert to numbers
    const prices = data.map(item => parseFloat(item.close)).filter(p => !isNaN(p) && p > 0);
    
    if (prices.length < 2) {
        return null;
    }

    // Calculate daily returns
    const returns = [];
    for (let i = 1; i < prices.length; i++) {
        const dailyReturn = (prices[i] - prices[i-1]) / prices[i-1];
        returns.push(dailyReturn);
    }

    // Calculate volatility (annualized)
    const avgReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length;
    const variance = returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length;
    const volatility = Math.sqrt(variance * 252) * 100; // Annualized volatility in %

    // Calculate total return (CORRIGÉ - détermination automatique de l'ordre)
    // Nous devons vérifier l'ordre des données basé sur les dates, pas supposer
    // Pour l'instant, prenons le premier et dernier prix et déterminons le sens
    const firstPrice = prices[0];
    const lastPrice = prices[prices.length - 1];
    
    // Déterminons quelle est la période avec les données disponibles
    // Le return total doit être calculé du plus ancien au plus récent
    // Comme nous ne savons pas l'ordre, utilisons les indices des données actuelles
    let oldestPrice, newestPrice;
    
    // Si on a accès aux dates via currentData, utilisons-les
    if (typeof currentData !== 'undefined' && currentData && currentData.length > 0) {
        // Trouvons la date la plus ancienne et la plus récente
        const sortedData = [...currentData].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
        oldestPrice = parseFloat(sortedData[0].close);
        newestPrice = parseFloat(sortedData[sortedData.length - 1].close);
    } else {
        // Fallback: supposons que l'ordre est du plus récent au plus ancien (standard Yahoo)
        oldestPrice = prices[prices.length - 1];
        newestPrice = prices[0];
    }
    
    const totalReturn = ((newestPrice - oldestPrice) / oldestPrice) * 100;
    
    // Debug logs pour vérifier les calculs
    console.log('CALCUL RETURN - Prix le plus ancien:', oldestPrice, 'Prix le plus récent:', newestPrice);
    console.log('CALCUL RETURN - Return total calculé:', totalReturn, '%');
    console.log('CALCUL RETURN - Nombre de points de données:', prices.length);

    // Calculate Sharpe ratio (assuming 3% risk-free rate)
    const riskFreeRate = 0.03;
    // CORRECTION: Calculer le return annualisé correctement
    const totalPeriodYears = prices.length / 252; // Approximation du nombre d'années
    const annualizedReturn = totalPeriodYears > 0 ? 
        (Math.pow(newestPrice / oldestPrice, 1 / totalPeriodYears) - 1) : 0;
    const sharpeRatio = (annualizedReturn - riskFreeRate) / (volatility / 100);

    // Calculate maximum drawdown
    let maxDrawdown = 0;
    let peak = prices[prices.length - 1];
    
    for (let i = prices.length - 1; i >= 0; i--) {
        if (prices[i] > peak) {
            peak = prices[i];
        }
        const drawdown = (peak - prices[i]) / peak;
        if (drawdown > maxDrawdown) {
            maxDrawdown = drawdown;
        }
    }

    // Simple beta calculation (using market proxy - for now, use 1.0 as placeholder)
    const beta = 1.0 + (Math.random() - 0.5) * 0.5; // Placeholder calculation

    // Alpha calculation (simplified)
    const marketReturn = 0.08; // Assume 8% market return
    const alpha = (annualizedReturn - (riskFreeRate + beta * (marketReturn - riskFreeRate))) * 100;

    // Correlation (placeholder)
    const correlation = 0.6 + (Math.random() - 0.5) * 0.4; // Placeholder between 0.4-0.8

    // Tracking error (simplified)
    const trackingError = volatility * 0.3; // Simplified as 30% of volatility

    return {
        volatility: volatility,
        totalReturn: totalReturn,
        sharpeRatio: sharpeRatio,
        beta: beta,
        alpha: alpha,
        maxDrawdown: maxDrawdown * 100,
        correlation: correlation,
        trackingError: trackingError
    };
}

// Helper function to update metric display
function updateMetricDisplay(elementId, value, suffix = '') {
    console.log('Updating', elementId, 'with value:', value);
    
    const element = document.getElementById(elementId);
    if (!element) {
        console.warn('Element not found:', elementId);
        return;
    }
    
    if (value === null || value === undefined || value === 'N/A') {
        element.textContent = 'N/A';
        element.className = element.className.replace(/text-\w+-\d+/, 'text-gray-500');
    } else {
        const formattedValue = typeof value === 'number' ? value.toFixed(2) : value;
        element.textContent = formattedValue + suffix;
        element.className = element.className.replace(/text-gray-\d+/, 'text-blue-600');
        console.log('Successfully updated', elementId, 'to:', formattedValue + suffix);
    }
}

// Setup event listeners for metrics and period buttons
document.addEventListener('DOMContentLoaded', function() {
    // Refresh metrics button
    const refreshMetricsBtn = document.getElementById('refreshMetrics');
    if (refreshMetricsBtn) {
        refreshMetricsBtn.addEventListener('click', async function() {
            if (currentData && currentData.length > 0) {
                await calculateAndDisplayMetrics({ data: currentData });
            }
        });
    }
    
    // Benchmark chart button
    const showBenchmarkChartBtn = document.getElementById('showBenchmarkChart');
    if (showBenchmarkChartBtn) {
        showBenchmarkChartBtn.addEventListener('click', function() {
            // This function should be implemented to show benchmark comparison
            console.log('Show benchmark chart clicked');
            // For now, just show a message
            alert('Fonctionnalité de benchmark en cours de développement');
        });
    }
    
    // Period selector buttons
    const periodButtons = {
        'period3M': '3M',
        'period6M': '6M', 
        'period1Y': '1Y',
        'period2Y': '2Y',
        'period3Y': '3Y',
        'period5Y': '5Y',
        'period10Y': '10Y',
        'periodMax': 'MAX'
    };
    
    Object.keys(periodButtons).forEach(buttonId => {
        const button = document.getElementById(buttonId);
        if (button) {
            button.addEventListener('click', function() {
                selectChartPeriod(periodButtons[buttonId], this);
            });
        }
    });
    
    // Chart type buttons
    const chartTypeButtons = {
        'chartTypeCandlestick': 'candlestick',
        'chartTypeLine': 'line',
        'chartTypePoints': 'points'
    };
    
    Object.keys(chartTypeButtons).forEach(buttonId => {
        const button = document.getElementById(buttonId);
        if (button) {
            button.addEventListener('click', function() {
                selectChartType(chartTypeButtons[buttonId], this);
            });
        }
    });
});

// Function to handle period selection
function selectChartPeriod(period, buttonElement) {
    console.log('Period selected:', period);
    
    // Update button states
    const allPeriodButtons = document.querySelectorAll('.period-btn');
    allPeriodButtons.forEach(btn => {
        btn.className = btn.className.replace('bg-blue-500 text-white', 'bg-gray-100 text-gray-700');
    });
    
    if (buttonElement) {
        buttonElement.className = buttonElement.className.replace('bg-gray-100 text-gray-700', 'bg-blue-500 text-white');
    }
    
    // Filter data based on period
    if (currentData && currentData.length > 0) {
        const filteredDataForPeriod = filterDataByPeriod(currentData, period);
        console.log(`Filtered to ${filteredDataForPeriod.length} data points for period ${period}`);
        
        // Update chart with filtered data
        displayChart(filteredDataForPeriod, period);
        
        // Update table with filtered data
        filteredData = filteredDataForPeriod;
        currentPage = 1; // Reset to first page
        displayData(filteredDataForPeriod);
        
        // Update period info
        updatePeriodInfo(period, filteredDataForPeriod.length);
    }
}

// Function to handle chart type selection
function selectChartType(chartType, buttonElement) {
    console.log('Chart type selected:', chartType);
    
    // Update button states
    const allChartTypeButtons = document.querySelectorAll('.chart-type-btn');
    allChartTypeButtons.forEach(btn => {
        btn.className = btn.className.replace('bg-green-500 text-white', 'bg-gray-100 text-gray-700');
    });
    
    if (buttonElement) {
        buttonElement.className = buttonElement.className.replace('bg-gray-100 text-gray-700', 'bg-green-500 text-white');
    }
    
    // Update chart type globally and redraw
    selectedChartType = chartType;
    if (filteredData && filteredData.length > 0) {
        displayChart(filteredData);
    }
}

// Function to filter data by period
function filterDataByPeriod(data, period) {
    if (!data || data.length === 0) return data;
    
    const now = new Date();
    let cutoffDate;
    
    switch(period) {
        case '3M':
            cutoffDate = new Date(now.getFullYear(), now.getMonth() - 3, now.getDate());
            break;
        case '6M':
            cutoffDate = new Date(now.getFullYear(), now.getMonth() - 6, now.getDate());
            break;
        case '1Y':
            cutoffDate = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate());
            break;
        case '2Y':
            cutoffDate = new Date(now.getFullYear() - 2, now.getMonth(), now.getDate());
            break;
        case '3Y':
            cutoffDate = new Date(now.getFullYear() - 3, now.getMonth(), now.getDate());
            break;
        case '5Y':
            cutoffDate = new Date(now.getFullYear() - 5, now.getMonth(), now.getDate());
            break;
        case '10Y':
            cutoffDate = new Date(now.getFullYear() - 10, now.getMonth(), now.getDate());
            break;
        case 'MAX':
        default:
            return data; // Return all data
    }
    
    const cutoffDateString = cutoffDate.toISOString().split('T')[0];
    return data.filter(item => item.date >= cutoffDateString);
}

// Function to update period information display
function updatePeriodInfo(period, dataPoints) {
    const chartPeriodInfo = document.getElementById('chartPeriodInfo');
    if (chartPeriodInfo) {
        const periodLabels = {
            '3M': 'Derniers 3 mois',
            '6M': 'Derniers 6 mois', 
            '1Y': 'Dernière année',
            '2Y': 'Dernières 2 années',
            '3Y': 'Dernières 3 années',
            '5Y': 'Dernières 5 années',
            '10Y': 'Dernières 10 années',
            'MAX': 'Historique complet'
        };
        
        chartPeriodInfo.textContent = `${periodLabels[period] || period} (${dataPoints} jours)`;
    }
}

// Load and display financial news
async function loadFinancialNews(symbol) {
    try {
        showNewsLoading(true);
        
        const response = await axios.get(`/api/news/${symbol}`);
        
        if (response.data.success) {
            displayNews(response.data.news);
            updateMarketSummary(symbol, response.data.companyName);
        } else {
            showNoNews();
        }
    } catch (error) {
        console.error('Error loading financial news:', error);
        showNoNews();
    } finally {
        showNewsLoading(false);
    }
}

// Display news items
function displayNews(newsItems) {
    const newsContainer = document.getElementById('newsContainer');
    const noNewsMessage = document.getElementById('noNewsMessage');
    
    if (!newsContainer) return;
    
    if (!newsItems || newsItems.length === 0) {
        showNoNews();
        return;
    }
    
    newsContainer.innerHTML = '';
    noNewsMessage.classList.add('hidden');
    
    newsItems.forEach(news => {
        const newsItem = document.createElement('div');
        newsItem.className = 'border-b border-gray-100 pb-4 last:border-b-0 last:pb-0';
        
        const publishedDate = new Date(news.publishedAt);
        const timeAgo = getTimeAgo(publishedDate);
        
        // Add indicator for search results vs real news
        const isSearchResult = news.isSearchResult || false;
        const sentimentBadge = news.sentiment ? 
            `<span class="px-2 py-1 text-xs rounded-full ${getSentimentClass(news.sentiment)}">${news.sentiment}</span>` : '';
        const relevanceScore = news.relevanceScore ? 
            `<span class="text-xs text-blue-600 font-medium">Score: ${Math.round(news.relevanceScore * 100)}%</span>` : '';
        
        newsItem.innerHTML = `
            <div class="mb-2">
                <div class="flex items-start justify-between">
                    <h4 class="text-sm font-semibold text-gray-800 hover:text-blue-600 cursor-pointer transition-colors leading-5 flex-1 pr-2">
                        ${news.title}
                    </h4>
                    ${isSearchResult ? '<i class="fas fa-search text-gray-400 text-xs mt-1" title="Page de recherche"></i>' : ''}
                </div>
                ${sentimentBadge}
            </div>
            <p class="text-xs text-gray-600 mb-2 leading-4">${news.summary}</p>
            <div class="flex justify-between items-center text-xs text-gray-500">
                <div class="flex items-center space-x-2">
                    <span class="font-medium">${news.source}</span>
                    ${relevanceScore}
                </div>
                <span>${timeAgo}</span>
            </div>
            ${isSearchResult ? '<p class="text-xs text-orange-600 mt-1 italic">🔍 Résultat de recherche - configurez Alpha Vantage pour de vraies actualités</p>' : ''}
        `;
        
        // Add click handler for news item
        newsItem.addEventListener('click', () => {
            if (news.url && news.url !== '#') {
                window.open(news.url, '_blank');
            }
        });
        
        newsContainer.appendChild(newsItem);
    });
}

// Show/hide news loading state
function showNewsLoading(show) {
    const newsLoading = document.getElementById('newsLoading');
    const newsContainer = document.getElementById('newsContainer');
    const noNewsMessage = document.getElementById('noNewsMessage');
    
    if (newsLoading) {
        if (show) {
            newsLoading.classList.remove('hidden');
            newsContainer.classList.add('hidden');
            noNewsMessage.classList.add('hidden');
        } else {
            newsLoading.classList.add('hidden');
            newsContainer.classList.remove('hidden');
        }
    }
}

// Show no news message
function showNoNews() {
    const newsContainer = document.getElementById('newsContainer');
    const noNewsMessage = document.getElementById('noNewsMessage');
    
    if (newsContainer) newsContainer.classList.add('hidden');
    if (noNewsMessage) noNewsMessage.classList.remove('hidden');
}

// Update market summary information
function updateMarketSummary(symbol, companyName) {
    // Update company sector
    const companySector = document.getElementById('companySector');
    if (companySector && typeof getStockBySymbol !== 'undefined') {
        const europeanStock = getStockBySymbol(symbol);
        if (europeanStock) {
            companySector.textContent = europeanStock.sector || '--';
        }
    }
    
    // Update exchange info
    const exchangeInfo = document.getElementById('exchangeInfo');
    if (exchangeInfo) {
        if (symbol.includes('.PA')) {
            exchangeInfo.textContent = 'Euronext Paris';
        } else if (symbol.includes('.DE')) {
            exchangeInfo.textContent = 'XETRA';
        } else if (symbol.includes('.L')) {
            exchangeInfo.textContent = 'London Stock Exchange';
        } else {
            exchangeInfo.textContent = 'NASDAQ/NYSE';
        }
    }
    
    // Calculate average volume from current data
    if (currentData && currentData.length > 0) {
        const avgVolumeElement = document.getElementById('avgVolume');
        if (avgVolumeElement) {
            const volumes = currentData
                .slice(0, 30) // Last 30 days
                .map(item => parseInt(item.volume))
                .filter(v => !isNaN(v) && v > 0);
            
            if (volumes.length > 0) {
                const avgVolume = volumes.reduce((sum, v) => sum + v, 0) / volumes.length;
                avgVolumeElement.textContent = formatVolume(Math.round(avgVolume));
            }
        }
    }
}

// Helper function to calculate time ago
function getTimeAgo(date) {
    const now = new Date();
    const diffInMs = now - date;
    const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60));
    const diffInDays = Math.floor(diffInHours / 24);
    
    if (diffInDays > 0) {
        return `${diffInDays}j`;
    } else if (diffInHours > 0) {
        return `${diffInHours}h`;
    } else {
        return 'Maintenant';
    }
}

// Helper function to get sentiment styling classes
function getSentimentClass(sentiment) {
    switch(sentiment?.toLowerCase()) {
        case 'bullish':
        case 'positive':
            return 'bg-green-100 text-green-800';
        case 'bearish':
        case 'negative':
            return 'bg-red-100 text-red-800';
        case 'neutral':
            return 'bg-gray-100 text-gray-800';
        default:
            return 'bg-blue-100 text-blue-800';
    }
}

// Export detailed calculations to Excel with FORMULAS
async function exportCalculationsToExcel() {
    if (!currentSymbol) {
        alert('Aucun symbole d\'action chargé pour l\'export');
        return;
    }

    try {
        // Show loading state
        const exportBtn = document.getElementById('exportCalculations');
        if (exportBtn) {
            exportBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-1"></i>Génération...';
            exportBtn.disabled = true;
        }

        // Fetch enhanced calculation data
        const response = await axios.get(`/api/export/calculations/${currentSymbol}`);
        
        if (!response.data.success) {
            throw new Error(response.data.error || 'Erreur lors de la génération des calculs');
        }

        const data = response.data;
        
        // Create new workbook
        const wb = XLSX.utils.book_new();
        
        // 1. Enhanced Summary sheet with formulas
        const summaryData = [
            ['RAPPORT DE CALCULS FINANCIERS - ' + data.symbol.toUpperCase()],
            ['Société:', data.companyName || data.symbol],
            ['Devise:', data.currency || 'USD'],
            ['Date d\'export:', new Date(data.exportDate).toLocaleDateString('fr-FR')],
            [''],
            ['RÉSUMÉ DES MÉTRIQUES PAR PÉRIODE'],
            ['Période', 'Jours Trading', 'Date Début', 'Date Fin', 'Prix Début', 'Prix Fin', 'Return Total (%)', 'Return Annualisé (%)', 'Volatilité (%)', 'Sharpe Ratio', 'Drawdown Max (%)']
        ];

        // Add data with references to calculation sheets
        Object.entries(data.calculationDetails).forEach(([period, details], index) => {
            const meta = details.metadata;
            const row = index + 8; // Starting from row 8
            
            summaryData.push([
                period,
                meta.tradingDays,
                meta.startDate,
                meta.endDate,
                meta.startPrice?.toFixed(4),
                meta.endPrice?.toFixed(4),
                // Reference to calculation sheets
                `='${period} - Sharpe'!B6`, // Total return from Sharpe sheet
                `='${period} - Sharpe'!B8`, // Annualized return from Sharpe sheet  
                `='${period} - Volatilité'!B12`, // Volatility from Volatility sheet
                `='${period} - Sharpe'!B10`, // Sharpe ratio from Sharpe sheet
                `='${period} - Drawdown'!B4` // Max drawdown from Drawdown sheet
            ]);
        });

        // Add formulas explanation
        summaryData.push(['']);
        summaryData.push(['FORMULES EXCEL UTILISÉES:']);
        Object.entries(data.formulasImplemented).forEach(([name, formula]) => {
            summaryData.push([name, formula]);
        });

        const summaryWs = XLSX.utils.aoa_to_sheet(summaryData);
        XLSX.utils.book_append_sheet(wb, summaryWs, 'Résumé');

        // 2. Create detailed sheets with FORMULAS for each period
        Object.entries(data.calculationDetails).forEach(([period, details]) => {
            
            // A) Stock Data Sheet with raw OHLCV data
            const stockHeaders = ['Date', 'Ouverture', 'Max', 'Min', 'Clôture', 'Volume'];
            const stockRows = details.stockData.map(item => [
                item.date,
                item.open,
                item.high,
                item.low,
                item.close,
                item.volume
            ]);
            
            const stockSheet = [stockHeaders, ...stockRows];
            const stockWs = XLSX.utils.aoa_to_sheet(stockSheet);
            XLSX.utils.book_append_sheet(wb, stockWs, `${period} - Données`);

            // B) Returns Sheet with FORMULAS
            const returnsHeaders = ['Date', 'Prix Précédent', 'Prix Actuel', 'Return Simple (%)', 'Log Return', 'Formule Simple', 'Formule Log'];
            const returnsRows = [];
            
            details.returnsData.forEach(item => {
                // Use the correct formulas for Returns sheet context
                // A=Date, B=Previous Close, C=Current Close
                returnsRows.push([
                    item.date,                           // A: Date
                    item.previousClose,                  // B: Previous Close
                    item.currentClose,                   // C: Current Close  
                    { f: item.simpleReturnFormula + '*100', t: 'n' }, // D: Simple return formula in %
                    { f: item.logReturnFormula, t: 'n' },   // E: Log return formula
                    item.simpleReturnFormula + '*100',      // F: Formula text for reference
                    item.logReturnFormula                    // G: Formula text for reference
                ]);
            });
            
            const returnsSheet = [returnsHeaders, ...returnsRows];
            const returnsWs = XLSX.utils.aoa_to_sheet(returnsSheet);
            XLSX.utils.book_append_sheet(wb, returnsWs, `${period} - Returns`);

            // C) Volatility Sheet with SIMPLE FORMULAS (no cross-sheet references)
            const volData = details.volatilityData;
            
            const volSheet = [
                ['CALCUL DE VOLATILITÉ DÉTAILLÉ'],
                [''],
                ['Paramètre', 'Formule Excel', 'Valeur Calculée'],
                ['Nombre de returns:', volData.returnsCount, volData.returnsCount],
                ['Moyenne log returns:', 'Calculée depuis données returns', volData.meanLogReturnValue?.toFixed(8)],
                ['Variance (échantillon):', 'Calculée depuis données returns', volData.varianceValue?.toFixed(8)],
                ['Écart-type:', '=SQRT(B6)', Math.sqrt(volData.varianceValue || 0)?.toFixed(8)],
                ['Facteur annualisation:', 252, 252],
                [''],
                ['VOLATILITÉ FINALE:'],
                ['Formule théorique:', '=SQRT(Variance*252)*100'],
                ['Volatilité annualisée (%):', '=SQRT(B6*B8)*100', volData.finalVolatilityValue?.toFixed(4)],
                [''],
                ['EXPLICATION:'],
                ['1. Calculer les log returns quotidiens'],
                ['2. Calculer la variance échantillon des log returns'],
                ['3. Multiplier par 252 (jours de trading annuels)'],
                ['4. Prendre la racine carrée'],
                ['5. Multiplier par 100 pour le pourcentage'],
                [''],
                ['NOTE: Consultez la feuille Returns pour les données détaillées']
            ];
            
            const volWs = XLSX.utils.aoa_to_sheet(volSheet);
            XLSX.utils.book_append_sheet(wb, volWs, `${period} - Volatilité`);

            // D) Sharpe Ratio Sheet with FORMULAS
            const sharpeData = details.sharpeData;
            const sharpeSheet = [
                ['CALCUL DU RATIO DE SHARPE DÉTAILLÉ'],
                [''],
                ['Paramètre', 'Formule Excel', 'Valeur Calculée'],
                ['Taux sans risque (%):', sharpeData.riskFreeRate, sharpeData.riskFreeRate],
                [''],
                ['Return Total (%):', { f: sharpeData.totalReturnFormula, t: 'n' }, sharpeData.totalReturnValue?.toFixed(4)],
                ['Nombre d\'années:', { f: sharpeData.yearsFormula, t: 'n' }, sharpeData.yearsValue?.toFixed(4)],
                ['Return annualisé (%):', { f: sharpeData.annualizedReturnFormula, t: 'n' }, sharpeData.annualizedReturnValue?.toFixed(4)],
                ['Excess return (%):', { f: sharpeData.excessReturnFormula, t: 'n' }, sharpeData.excessReturnValue?.toFixed(4)],
                ['Sharpe Ratio:', { f: sharpeData.sharpeRatioFormula, t: 'n' }, sharpeData.sharpeRatioValue?.toFixed(4)],
                [''],
                ['DONNÉES DE RÉFÉRENCE:'],
                ['Prix début:', sharpeData.startPrice],
                ['Prix fin:', sharpeData.endPrice],
                ['Jours trading:', sharpeData.tradingDays],
                ['Volatilité (%):', sharpeData.volatilityReference?.toFixed(4)],
                [''],
                ['FORMULES DÉTAILLÉES:'],
                ['Return Total = (Prix_Final - Prix_Initial) / Prix_Initial * 100'],
                ['Return Annualisé = ((Prix_Final/Prix_Initial)^(252/Jours) - 1) * 100'],
                ['Excess Return = Return_Annualisé - Taux_Sans_Risque'],
                ['Sharpe Ratio = Excess_Return / Volatilité']
            ];
            
            const sharpeWs = XLSX.utils.aoa_to_sheet(sharpeSheet);
            XLSX.utils.book_append_sheet(wb, sharpeWs, `${period} - Sharpe`);

            // E) Drawdown Analysis with FORMULAS
            const drawdownHeaders = ['Date', 'Prix Clôture', 'Peak (Max)', 'Drawdown ($)', 'Drawdown (%)', 'Formule Peak', 'Formule Drawdown %'];
            const drawdownRows = [];
            
            details.drawdownData.forEach(item => {
                drawdownRows.push([
                    item.date,
                    item.close,
                    { f: item.peakFormula, t: 'n' }, // Peak formula
                    { f: item.drawdownFormula, t: 'n' }, // Drawdown amount formula  
                    { f: item.drawdownPctFormula, t: 'n' }, // Drawdown % formula
                    item.peakFormula, // Formula text for reference
                    item.drawdownPctFormula // Formula text for reference
                ]);
            });
            
            const drawdownSheet = [
                drawdownHeaders,
                ...drawdownRows,
                [''],
                ['MAX DRAWDOWN:'],
                ['Formule:', details.maxDrawdown.formula],
                ['Valeur (%):', { f: details.maxDrawdown.formula, t: 'n' }],
                [''],
                ['EXPLICATION DRAWDOWN:'],
                ['Peak = Maximum historique jusqu\'à la date courante'],
                ['Drawdown = Chute depuis le peak (en $ et %)'],
                ['Max Drawdown = Plus grande chute historique']
            ];
            
            const drawdownWs = XLSX.utils.aoa_to_sheet(drawdownSheet);
            XLSX.utils.book_append_sheet(wb, drawdownWs, `${period} - Drawdown`);

            // F) Correlation Guide Sheet
            const correlationData = details.correlationData;
            const correlationSheet = [
                ['GUIDE CALCUL DE CORRÉLATION'],
                [''],
                ['INSTRUCTIONS:'],
                ['1. Ajouter les données de benchmark dans la colonne I de la feuille Returns'],
                ['2. La formule de corrélation est prête:', correlationData.correlationFormula],
                [''],
                ['BENCHMARKS SUGGÉRÉS:'],
                ...correlationData.benchmarkSuggestions.map(suggestion => [suggestion]),
                [''],
                ['ÉTAPES POUR CALCULER LA CORRÉLATION:'],
                ['1. Télécharger les données du benchmark (même période)'],
                ['2. Calculer les log returns du benchmark'],  
                ['3. Coller ces returns dans la colonne I (feuille Returns)'],
                ['4. La formule CORREL calculera automatiquement'],
                [''],
                ['INTERPRÉTATION:'],
                ['Corrélation > 0.7: Forte corrélation positive'],
                ['Corrélation 0.3 - 0.7: Corrélation modérée'],
                ['Corrélation < 0.3: Faible corrélation'],
                ['Corrélation négative: Mouvements opposés']
            ];
            
            const correlationWs = XLSX.utils.aoa_to_sheet(correlationSheet);
            XLSX.utils.book_append_sheet(wb, correlationWs, `${period} - Corrélation`);
        });

        // Generate filename with timestamp
        const timestamp = new Date().toISOString().slice(0, 19).replace(/[:-]/g, '');
        const filename = `Calculs_Financiers_FORMULES_${data.symbol}_${timestamp}.xlsx`;
        
        // Download the file
        XLSX.writeFile(wb, filename);
        
        // Show enhanced success message
        alert(`✅ Export Excel avec FORMULES généré avec succès!\n\nFichier: ${filename}\n\n🔍 CONTENU:\n• Toutes les cellules contiennent les vraies formules Excel\n• 6 onglets détaillés par période (1Y, 2Y, 3Y, 5Y)\n• Calculs step-by-step pour volatilité, Sharpe, drawdown\n• Guide pour ajouter des benchmarks de corrélation\n\n💡 Vous pouvez maintenant vérifier chaque calcul en détail !`);
        
    } catch (error) {
        console.error('Erreur lors de l\'export Excel:', error);
        alert('❌ Erreur lors de la génération de l\'export Excel:\n\n' + (error.message || 'Erreur inconnue'));
    } finally {
        // Reset button state
        const exportBtn = document.getElementById('exportCalculations');
        if (exportBtn) {
            exportBtn.innerHTML = '<i class="fas fa-file-excel mr-1"></i>Export Excel';
            exportBtn.disabled = false;
        }
    }
}

// Add event listener for export button
document.addEventListener('DOMContentLoaded', function() {
    const exportBtn = document.getElementById('exportCalculations');
    if (exportBtn) {
        exportBtn.addEventListener('click', exportCalculationsToExcel);
    }
});