// Base de données étendue des actions européennes
// Inclut CAC 40, DAX 30, IBEX 35, FTSE MIB 40, BEL 20, AEX 25

const EUROPEAN_STOCKS_EXTENDED = {
    // France - CAC 40
    'FR': {
        country: 'France',
        flag: '🇫🇷',
        index: 'CAC 40',
        currency: 'EUR',
        suffix: '.PA',
        companies: [
            { symbol: 'AC.PA', name: 'Accor', sector: 'Services aux consommateurs' },
            { symbol: 'ATO.PA', name: 'Atos', sector: 'Technologie' },
            { symbol: 'CS.PA', name: 'AXA', sector: 'Assurance' },
            { symbol: 'BNP.PA', name: 'BNP Paribas', sector: 'Banque' },
            { symbol: 'EN.PA', name: 'Bouygues', sector: 'Construction' },
            { symbol: 'CAP.PA', name: 'Capgemini', sector: 'Technologie' },
            { symbol: 'CA.PA', name: 'Carrefour', sector: 'Distribution' },
            { symbol: 'ACA.PA', name: 'Crédit Agricole', sector: 'Banque' },
            { symbol: 'BN.PA', name: 'Danone', sector: 'Agroalimentaire' },
            { symbol: 'ENGI.PA', name: 'ENGIE', sector: 'Énergie' },
            { symbol: 'EL.PA', name: 'EssilorLuxottica', sector: 'Santé' },
            { symbol: 'RMS.PA', name: 'Hermès', sector: 'Luxe' },
            { symbol: 'LR.PA', name: 'Legrand', sector: 'Industrie' },
            { symbol: 'LHN.PA', name: 'L\'Oréal', sector: 'Cosmétiques' },
            { symbol: 'MC.PA', name: 'LVMH', sector: 'Luxe' },
            { symbol: 'ML.PA', name: 'Michelin', sector: 'Automobile' },
            { symbol: 'OR.PA', name: 'L\'Oréal', sector: 'Cosmétiques' },
            { symbol: 'RI.PA', name: 'Pernod Ricard', sector: 'Boissons' },
            { symbol: 'KER.PA', name: 'Kering', sector: 'Luxe' },
            { symbol: 'RNO.PA', name: 'Renault', sector: 'Automobile' },
            { symbol: 'SAF.PA', name: 'Safran', sector: 'Aéronautique' },
            { symbol: 'SAN.PA', name: 'Sanofi', sector: 'Pharmacie' },
            { symbol: 'SU.PA', name: 'Schneider Electric', sector: 'Industrie' },
            { symbol: 'GLE.PA', name: 'Société Générale', sector: 'Banque' },
            { symbol: 'STM.PA', name: 'STMicroelectronics', sector: 'Technologie' },
            { symbol: 'TEP.PA', name: 'Teleperformance', sector: 'Services' },
            { symbol: 'HO.PA', name: 'Thales', sector: 'Défense' },
            { symbol: 'TTE.PA', name: 'TotalEnergies', sector: 'Énergie' },
            { symbol: 'UG.PA', name: 'Peugeot', sector: 'Automobile' },
            { symbol: 'VIE.PA', name: 'Veolia', sector: 'Services aux collectivités' },
            { symbol: 'DG.PA', name: 'Vinci', sector: 'Construction' },
            { symbol: 'VIV.PA', name: 'Vivendi', sector: 'Médias' },
            { symbol: 'WLN.PA', name: 'Worldline', sector: 'Technologie' }
        ]
    },

    // Allemagne - DAX 30
    'DE': {
        country: 'Allemagne',
        flag: '🇩🇪',
        index: 'DAX 30',
        currency: 'EUR',
        suffix: '.DE',
        companies: [
            { symbol: 'ADS.DE', name: 'Adidas', sector: 'Articles de sport' },
            { symbol: 'ALV.DE', name: 'Allianz', sector: 'Assurance' },
            { symbol: 'BAS.DE', name: 'BASF', sector: 'Chimie' },
            { symbol: 'BAYN.DE', name: 'Bayer', sector: 'Pharmacie' },
            { symbol: 'BMW.DE', name: 'BMW', sector: 'Automobile' },
            { symbol: 'CON.DE', name: 'Continental', sector: 'Automobile' },
            { symbol: 'DAI.DE', name: 'Mercedes-Benz Group', sector: 'Automobile' },
            { symbol: 'DB1.DE', name: 'Deutsche Bank', sector: 'Banque' },
            { symbol: 'DBK.DE', name: 'Deutsche Bank', sector: 'Banque' },
            { symbol: 'DTE.DE', name: 'Deutsche Telekom', sector: 'Télécommunications' },
            { symbol: 'EOAN.DE', name: 'E.ON', sector: 'Énergie' },
            { symbol: 'FRE.DE', name: 'Fresenius', sector: 'Santé' },
            { symbol: 'FME.DE', name: 'Fresenius Medical Care', sector: 'Santé' },
            { symbol: 'HEI.DE', name: 'Heidelberg Cement', sector: 'Construction' },
            { symbol: 'HEN3.DE', name: 'Henkel', sector: 'Biens de consommation' },
            { symbol: 'IFX.DE', name: 'Infineon', sector: 'Technologie' },
            { symbol: 'LIN.DE', name: 'Linde', sector: 'Chimie' },
            { symbol: 'MRK.DE', name: 'Merck KGaA', sector: 'Pharmacie' },
            { symbol: 'MTX.DE', name: 'MTU Aero Engines', sector: 'Aéronautique' },
            { symbol: 'MUV2.DE', name: 'Munich Re', sector: 'Assurance' },
            { symbol: 'RWE.DE', name: 'RWE', sector: 'Énergie' },
            { symbol: 'SAP.DE', name: 'SAP', sector: 'Technologie' },
            { symbol: 'SIE.DE', name: 'Siemens', sector: 'Industrie' },
            { symbol: 'VNA.DE', name: 'Vonovia', sector: 'Immobilier' },
            { symbol: 'VOW3.DE', name: 'Volkswagen', sector: 'Automobile' },
            { symbol: 'WDI.DE', name: 'Wirecard', sector: 'Technologie' },
            { symbol: 'ZAL.DE', name: 'Zalando', sector: 'E-commerce' }
        ]
    },

    // Espagne - IBEX 35
    'ES': {
        country: 'Espagne',
        flag: '🇪🇸',
        index: 'IBEX 35',
        currency: 'EUR',
        suffix: '.MC',
        companies: [
            { symbol: 'ACS.MC', name: 'ACS', sector: 'Construction' },
            { symbol: 'AENA.MC', name: 'Aena', sector: 'Transport' },
            { symbol: 'AMS.MC', name: 'Amadeus', sector: 'Technologie' },
            { symbol: 'ANA.MC', name: 'Acciona', sector: 'Énergie' },
            { symbol: 'BBVA.MC', name: 'BBVA', sector: 'Banque' },
            { symbol: 'CABK.MC', name: 'CaixaBank', sector: 'Banque' },
            { symbol: 'CLNX.MC', name: 'Cellnex', sector: 'Télécommunications' },
            { symbol: 'COL.MC', name: 'Colonial', sector: 'Immobilier' },
            { symbol: 'ELE.MC', name: 'Endesa', sector: 'Énergie' },
            { symbol: 'ENG.MC', name: 'Enagás', sector: 'Énergie' },
            { symbol: 'FDR.MC', name: 'Fluidra', sector: 'Industrie' },
            { symbol: 'FER.MC', name: 'Ferrovial', sector: 'Construction' },
            { symbol: 'GAM.MC', name: 'Siemens Gamesa', sector: 'Énergie' },
            { symbol: 'GRF.MC', name: 'Grifols', sector: 'Pharmacie' },
            { symbol: 'IAG.MC', name: 'IAG', sector: 'Transport' },
            { symbol: 'IBE.MC', name: 'Iberdrola', sector: 'Énergie' },
            { symbol: 'IDR.MC', name: 'Indra', sector: 'Technologie' },
            { symbol: 'ITX.MC', name: 'Inditex', sector: 'Textile' },
            { symbol: 'LOG.MC', name: 'Logista', sector: 'Distribution' },
            { symbol: 'MAP.MC', name: 'Mapfre', sector: 'Assurance' },
            { symbol: 'MAS.MC', name: 'Masmóvil', sector: 'Télécommunications' },
            { symbol: 'MEL.MC', name: 'Meliá Hotels', sector: 'Tourisme' },
            { symbol: 'MRL.MC', name: 'Merlin Properties', sector: 'Immobilier' },
            { symbol: 'MTS.MC', name: 'ArcelorMittal', sector: 'Métallurgie' },
            { symbol: 'NTGY.MC', name: 'Naturgy', sector: 'Énergie' },
            { symbol: 'PHM.MC', name: 'Pharma Mar', sector: 'Pharmacie' },
            { symbol: 'REE.MC', name: 'Red Eléctrica', sector: 'Énergie' },
            { symbol: 'REP.MC', name: 'Repsol', sector: 'Énergie' },
            { symbol: 'ROVI.MC', name: 'Rovi', sector: 'Pharmacie' },
            { symbol: 'SAN.MC', name: 'Banco Santander', sector: 'Banque' },
            { symbol: 'SCYR.MC', name: 'Sacyr', sector: 'Construction' },
            { symbol: 'SOL.MC', name: 'Solaria', sector: 'Énergie' },
            { symbol: 'TEF.MC', name: 'Telefónica', sector: 'Télécommunications' },
            { symbol: 'UNI.MC', name: 'Unicaja', sector: 'Banque' },
            { symbol: 'VIS.MC', name: 'Viscofan', sector: 'Agroalimentaire' }
        ]
    },

    // Italie - FTSE MIB 40
    'IT': {
        country: 'Italie',
        flag: '🇮🇹',
        index: 'FTSE MIB 40',
        currency: 'EUR',
        suffix: '.MI',
        companies: [
            { symbol: 'A2A.MI', name: 'A2A', sector: 'Énergie' },
            { symbol: 'RACE.MI', name: 'Ferrari', sector: 'Automobile' },
            { symbol: 'ATL.MI', name: 'Atlantia', sector: 'Transport' },
            { symbol: 'AZM.MI', name: 'Azimut', sector: 'Finance' },
            { symbol: 'BAMI.MI', name: 'Banco BPM', sector: 'Banque' },
            { symbol: 'BZU.MI', name: 'Buzzi Unicem', sector: 'Construction' },
            { symbol: 'CPR.MI', name: 'Campari', sector: 'Boissons' },
            { symbol: 'CNH.MI', name: 'CNH Industrial', sector: 'Industrie' },
            { symbol: 'DIA.MI', name: 'Diasorin', sector: 'Santé' },
            { symbol: 'ENEL.MI', name: 'Enel', sector: 'Énergie' },
            { symbol: 'ENI.MI', name: 'Eni', sector: 'Énergie' },
            { symbol: 'EXO.MI', name: 'Exor', sector: 'Finance' },
            { symbol: 'FCA.MI', name: 'Stellantis', sector: 'Automobile' },
            { symbol: 'G.MI', name: 'Generali', sector: 'Assurance' },
            { symbol: 'HER.MI', name: 'Hera', sector: 'Services aux collectivités' },
            { symbol: 'IG.MI', name: 'Italgas', sector: 'Énergie' },
            { symbol: 'INW.MI', name: 'Inwit', sector: 'Télécommunications' },
            { symbol: 'ISP.MI', name: 'Intesa Sanpaolo', sector: 'Banque' },
            { symbol: 'LDO.MI', name: 'Leonardo', sector: 'Défense' },
            { symbol: 'MB.MI', name: 'Mediobanca', sector: 'Banque' },
            { symbol: 'MONC.MI', name: 'Moncler', sector: 'Luxe' },
            { symbol: 'MS.MI', name: 'Mediaset', sector: 'Médias' },
            { symbol: 'NEXI.MI', name: 'Nexi', sector: 'Technologie' },
            { symbol: 'PIRC.MI', name: 'Pirelli', sector: 'Automobile' },
            { symbol: 'PST.MI', name: 'Poste Italiane', sector: 'Services' },
            { symbol: 'PRY.MI', name: 'Prysmian', sector: 'Industrie' },
            { symbol: 'REC.MI', name: 'RecordTi', sector: 'Technologie' },
            { symbol: 'SPM.MI', name: 'Saipem', sector: 'Énergie' },
            { symbol: 'SFER.MI', name: 'Salvatore Ferragamo', sector: 'Luxe' },
            { symbol: 'SRG.MI', name: 'Snam', sector: 'Énergie' },
            { symbol: 'STLA.MI', name: 'Stellantis', sector: 'Automobile' },
            { symbol: 'TEN.MI', name: 'Tenaris', sector: 'Industrie' },
            { symbol: 'TIT.MI', name: 'Telecom Italia', sector: 'Télécommunications' },
            { symbol: 'TOD.MI', name: 'Tod\'s', sector: 'Luxe' },
            { symbol: 'UCG.MI', name: 'UniCredit', sector: 'Banque' },
            { symbol: 'UNI.MI', name: 'Unipol', sector: 'Assurance' }
        ]
    },

    // Pays-Bas - AEX 25
    'NL': {
        country: 'Pays-Bas',
        flag: '🇳🇱',
        index: 'AEX 25',
        currency: 'EUR',
        suffix: '.AS',
        companies: [
            { symbol: 'ADYEN.AS', name: 'Adyen', sector: 'Technologie' },
            { symbol: 'AGN.AS', name: 'Aegon', sector: 'Assurance' },
            { symbol: 'AD.AS', name: 'Ahold Delhaize', sector: 'Distribution' },
            { symbol: 'AKZA.AS', name: 'Akzo Nobel', sector: 'Chimie' },
            { symbol: 'ASML.AS', name: 'ASML', sector: 'Technologie' },
            { symbol: 'ASR.AS', name: 'ASR Nederland', sector: 'Assurance' },
            { symbol: 'BESI.AS', name: 'BE Semiconductor', sector: 'Technologie' },
            { symbol: 'DSM.AS', name: 'Royal DSM', sector: 'Chimie' },
            { symbol: 'GLPG.AS', name: 'Galapagos', sector: 'Pharmacie' },
            { symbol: 'HEIA.AS', name: 'Heineken', sector: 'Boissons' },
            { symbol: 'INGA.AS', name: 'ING Group', sector: 'Banque' },
            { symbol: 'JDE.AS', name: 'JDE Peet\'s', sector: 'Agroalimentaire' },
            { symbol: 'KPN.AS', name: 'KPN', sector: 'Télécommunications' },
            { symbol: 'NN.AS', name: 'NN Group', sector: 'Assurance' },
            { symbol: 'PHIA.AS', name: 'Philips', sector: 'Technologie' },
            { symbol: 'PRX.AS', name: 'Prosus', sector: 'Technologie' },
            { symbol: 'RAND.AS', name: 'Randstad', sector: 'Services' },
            { symbol: 'RDSA.AS', name: 'Shell', sector: 'Énergie' },
            { symbol: 'SBM.AS', name: 'SBM Offshore', sector: 'Énergie' },
            { symbol: 'TKWY.AS', name: 'Just Eat Takeaway', sector: 'E-commerce' },
            { symbol: 'UNA.AS', name: 'Unilever', sector: 'Biens de consommation' },
            { symbol: 'VPK.AS', name: 'Vopak', sector: 'Énergie' },
            { symbol: 'WKL.AS', name: 'Wolters Kluwer', sector: 'Services' }
        ]
    },

    // Belgique - BEL 20
    'BE': {
        country: 'Belgique',
        flag: '🇧🇪',
        index: 'BEL 20',
        currency: 'EUR',
        suffix: '.BR',
        companies: [
            { symbol: 'ABINBEV.BR', name: 'AB InBev', sector: 'Boissons' },
            { symbol: 'ACKB.BR', name: 'Ackermans & van Haaren', sector: 'Finance' },
            { symbol: 'AGS.BR', name: 'Ageas', sector: 'Assurance' },
            { symbol: 'APAQ.BR', name: 'Apaq Technology', sector: 'Technologie' },
            { symbol: 'COFB.BR', name: 'Cofinimmo', sector: 'Immobilier' },
            { symbol: 'COLR.BR', name: 'Colruyt', sector: 'Distribution' },
            { symbol: 'DELB.BR', name: 'Delphi Technologies', sector: 'Automobile' },
            { symbol: 'ELI.BR', name: 'Elia Group', sector: 'Énergie' },
            { symbol: 'GBLB.BR', name: 'Groupe Bruxelles Lambert', sector: 'Finance' },
            { symbol: 'KBC.BR', name: 'KBC Group', sector: 'Banque' },
            { symbol: 'MELE.BR', name: 'Melexis', sector: 'Technologie' },
            { symbol: 'PROX.BR', name: 'Proximus', sector: 'Télécommunications' },
            { symbol: 'SOF.BR', name: 'Sofina', sector: 'Finance' },
            { symbol: 'SOLB.BR', name: 'Solvay', sector: 'Chimie' },
            { symbol: 'TEL.BR', name: 'Telenet', sector: 'Télécommunications' },
            { symbol: 'UCB.BR', name: 'UCB', sector: 'Pharmacie' },
            { symbol: 'UMG.BR', name: 'Umicore', sector: 'Métallurgie' },
            { symbol: 'WBI.BR', name: 'Warehouse De Pauw', sector: 'Immobilier' }
        ]
    }
};

// Fonction pour obtenir tous les stocks par pays
function getStocksByCountry(countryCode) {
    return EUROPEAN_STOCKS_EXTENDED[countryCode] || null;
}

// Fonction pour obtenir tous les stocks par secteur
function getStocksBySector() {
    const sectors = {};
    
    Object.keys(EUROPEAN_STOCKS_EXTENDED).forEach(countryCode => {
        const country = EUROPEAN_STOCKS_EXTENDED[countryCode];
        country.companies.forEach(company => {
            if (!sectors[company.sector]) {
                sectors[company.sector] = [];
            }
            sectors[company.sector].push({
                ...company,
                country: country.country,
                countryCode,
                flag: country.flag,
                currency: country.currency
            });
        });
    });
    
    return sectors;
}

// Fonction pour rechercher des stocks
function searchExtendedStocks(query) {
    const results = [];
    const searchTerm = query.toLowerCase();
    
    Object.keys(EUROPEAN_STOCKS_EXTENDED).forEach(countryCode => {
        const country = EUROPEAN_STOCKS_EXTENDED[countryCode];
        country.companies.forEach(company => {
            if (company.name.toLowerCase().includes(searchTerm) || 
                company.symbol.toLowerCase().includes(searchTerm) ||
                company.sector.toLowerCase().includes(searchTerm)) {
                results.push({
                    ...company,
                    country: country.country,
                    countryCode,
                    flag: country.flag,
                    currency: country.currency,
                    index: country.index
                });
            }
        });
    });
    
    return results;
}

// Fonction pour détecter la devise automatiquement
function detectCurrencyExtended(symbol) {
    if (symbol.includes('.PA') || symbol.includes('.MC') || symbol.includes('.MI') || 
        symbol.includes('.DE') || symbol.includes('.AS') || symbol.includes('.BR')) {
        return 'EUR';
    }
    return 'USD';
}

// Fonction pour formater les prix avec la devise appropriée
function formatPriceExtended(price, currency) {
    const numPrice = parseFloat(price);
    if (isNaN(numPrice)) return price;
    
    if (currency === 'EUR') {
        return numPrice.toLocaleString('fr-FR', { 
            style: 'currency', 
            currency: 'EUR',
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }
    
    return numPrice.toLocaleString('en-US', { 
        style: 'currency', 
        currency: 'USD',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

// Export global
window.EUROPEAN_STOCKS_EXTENDED = EUROPEAN_STOCKS_EXTENDED;
window.getStocksByCountry = getStocksByCountry;
window.getStocksBySector = getStocksBySector;
window.searchExtendedStocks = searchExtendedStocks;
window.detectCurrencyExtended = detectCurrencyExtended;
window.formatPriceExtended = formatPriceExtended;