// Calculs financiers académiques selon la littérature académique
// Implémentation des formules standard pour métriques de risque et performance

class AcademicFinancialCalculator {
    constructor() {
        // Taux sans risque annuel (ex: obligations d'État 10 ans Europe ~3%)
        this.riskFreeRate = 0.03; // 3% annuel
        this.tradingDaysPerYear = 252;
    }

    /**
     * Convertit les prix en rendements logarithmiques
     * @param {Array} prices - Array des prix [prix1, prix2, ...]
     * @returns {Array} - Rendements logarithmiques
     */
    calculateLogReturns(prices) {
        if (!prices || prices.length < 2) return [];
        
        const returns = [];
        for (let i = 1; i < prices.length; i++) {
            if (prices[i] && prices[i-1] && prices[i] > 0 && prices[i-1] > 0) {
                returns.push(Math.log(prices[i] / prices[i-1]));
            }
        }
        return returns;
    }

    /**
     * Calcule les rendements simples 
     * @param {Array} prices 
     * @returns {Array}
     */
    calculateSimpleReturns(prices) {
        if (!prices || prices.length < 2) return [];
        
        const returns = [];
        for (let i = 1; i < prices.length; i++) {
            if (prices[i] && prices[i-1] && prices[i-1] !== 0) {
                returns.push((prices[i] - prices[i-1]) / prices[i-1]);
            }
        }
        return returns;
    }

    /**
     * Statistiques de base d'une série
     * @param {Array} data 
     * @returns {Object}
     */
    calculateBasicStats(data) {
        if (!data || data.length === 0) {
            return { mean: 0, variance: 0, stdDev: 0, count: 0 };
        }

        const n = data.length;
        const mean = data.reduce((sum, val) => sum + val, 0) / n;
        
        // Variance échantillon (n-1) - formule académique standard
        const variance = data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / (n - 1);
        const stdDev = Math.sqrt(variance);

        return { mean, variance, stdDev, count: n };
    }

    /**
     * Volatilité annualisée (écart-type des rendements)
     * Formule: σ_annual = σ_daily * sqrt(252) pour données quotidiennes
     * @param {Array} returns - Rendements périodiques
     * @param {string} frequency - 'daily', 'monthly', 'annual'
     * @returns {number} - Volatilité annualisée en %
     */
    calculateAnnualizedVolatility(returns, frequency = 'daily') {
        const stats = this.calculateBasicStats(returns);
        if (stats.count < 2) return null;

        let annualizationFactor;
        switch (frequency.toLowerCase()) {
            case 'daily':
                annualizationFactor = Math.sqrt(252);
                break;
            case 'monthly':
                annualizationFactor = Math.sqrt(12);
                break;
            case 'weekly':
                annualizationFactor = Math.sqrt(52);
                break;
            case 'annual':
                annualizationFactor = 1;
                break;
            default:
                annualizationFactor = Math.sqrt(252);
        }

        return stats.stdDev * annualizationFactor * 100; // En pourcentage
    }

    /**
     * Rendement total annualisé
     * Formule: (Prix_final / Prix_initial)^(252/n_jours) - 1
     * @param {number} startPrice 
     * @param {number} endPrice 
     * @param {number} tradingDays 
     * @returns {number} - Rendement annualisé en %
     */
    calculateAnnualizedReturn(startPrice, endPrice, tradingDays) {
        if (!startPrice || !endPrice || startPrice <= 0 || endPrice <= 0 || tradingDays <= 0) {
            return null;
        }

        const totalReturn = endPrice / startPrice;
        const annualizedReturn = Math.pow(totalReturn, 252 / tradingDays) - 1;
        return annualizedReturn * 100; // En pourcentage
    }

    /**
     * Ratio de Sharpe académique
     * Formule: (Rp - Rf) / σ_p
     * @param {Array} returns - Rendements périodiques
     * @param {string} frequency 
     * @returns {number}
     */
    calculateSharpeRatio(returns, frequency = 'daily') {
        const stats = this.calculateBasicStats(returns);
        if (stats.count < 2) return null;

        // Rendement moyen annualisé
        let periodFactor;
        switch (frequency.toLowerCase()) {
            case 'daily':
                periodFactor = 252;
                break;
            case 'monthly':
                periodFactor = 12;
                break;
            case 'weekly':
                periodFactor = 52;
                break;
            default:
                periodFactor = 252;
        }

        const annualizedMeanReturn = stats.mean * periodFactor;
        const annualizedVolatility = this.calculateAnnualizedVolatility(returns, frequency) / 100;

        if (annualizedVolatility === 0) return null;

        return (annualizedMeanReturn - this.riskFreeRate) / annualizedVolatility;
    }

    /**
     * Bêta par rapport au marché (CAPM)
     * Formule: β = Cov(Ri, Rm) / Var(Rm)
     * @param {Array} assetReturns 
     * @param {Array} marketReturns 
     * @returns {number}
     */
    calculateBeta(assetReturns, marketReturns) {
        if (!assetReturns || !marketReturns || 
            assetReturns.length !== marketReturns.length || 
            assetReturns.length < 2) {
            return null;
        }

        const n = assetReturns.length;
        const assetMean = assetReturns.reduce((sum, r) => sum + r, 0) / n;
        const marketMean = marketReturns.reduce((sum, r) => sum + r, 0) / n;

        // Covariance
        const covariance = assetReturns.reduce((sum, assetReturn, i) => {
            return sum + (assetReturn - assetMean) * (marketReturns[i] - marketMean);
        }, 0) / (n - 1);

        // Variance du marché
        const marketVariance = marketReturns.reduce((sum, marketReturn) => {
            return sum + Math.pow(marketReturn - marketMean, 2);
        }, 0) / (n - 1);

        if (marketVariance === 0) return null;

        return covariance / marketVariance;
    }

    /**
     * Alpha de Jensen (CAPM)
     * Formule: α = Rp - [Rf + β(Rm - Rf)]
     * @param {Array} assetReturns 
     * @param {Array} marketReturns 
     * @param {string} frequency 
     * @returns {number}
     */
    calculateAlpha(assetReturns, marketReturns, frequency = 'daily') {
        const beta = this.calculateBeta(assetReturns, marketReturns);
        if (beta === null) return null;

        const assetStats = this.calculateBasicStats(assetReturns);
        const marketStats = this.calculateBasicStats(marketReturns);

        if (assetStats.count < 2 || marketStats.count < 2) return null;

        // Annualiser les rendements moyens
        let periodFactor;
        switch (frequency.toLowerCase()) {
            case 'daily':
                periodFactor = 252;
                break;
            case 'monthly':
                periodFactor = 12;
                break;
            default:
                periodFactor = 252;
        }

        const annualizedAssetReturn = assetStats.mean * periodFactor;
        const annualizedMarketReturn = marketStats.mean * periodFactor;

        // Alpha = Rp - [Rf + β(Rm - Rf)]
        const expectedReturn = this.riskFreeRate + beta * (annualizedMarketReturn - this.riskFreeRate);
        return (annualizedAssetReturn - expectedReturn) * 100; // En pourcentage
    }

    /**
     * Maximum Drawdown
     * Formule: MDD = max(Peak - Trough) / Peak
     * @param {Array} prices 
     * @returns {number} - En pourcentage
     */
    calculateMaxDrawdown(prices) {
        if (!prices || prices.length < 2) return null;

        let maxDrawdown = 0;
        let peak = prices[0];

        for (let i = 1; i < prices.length; i++) {
            if (prices[i] > peak) {
                peak = prices[i];
            }
            
            const drawdown = (peak - prices[i]) / peak;
            if (drawdown > maxDrawdown) {
                maxDrawdown = drawdown;
            }
        }

        return maxDrawdown * 100; // En pourcentage
    }

    /**
     * Ratio de Calmar
     * Formule: Rendement annualisé / Maximum Drawdown
     * @param {Array} prices 
     * @param {number} tradingDays 
     * @returns {number}
     */
    calculateCalmarRatio(prices, tradingDays) {
        if (!prices || prices.length < 2) return null;

        const annualizedReturn = this.calculateAnnualizedReturn(prices[0], prices[prices.length - 1], tradingDays);
        const maxDrawdown = this.calculateMaxDrawdown(prices);

        if (annualizedReturn === null || maxDrawdown === null || maxDrawdown === 0) {
            return null;
        }

        return annualizedReturn / maxDrawdown;
    }

    /**
     * Tracking Error vs benchmark
     * Formule: σ(Rp - Rb) - écart-type des rendements actifs
     * @param {Array} assetReturns 
     * @param {Array} benchmarkReturns 
     * @param {string} frequency 
     * @returns {number}
     */
    calculateTrackingError(assetReturns, benchmarkReturns, frequency = 'daily') {
        if (!assetReturns || !benchmarkReturns || 
            assetReturns.length !== benchmarkReturns.length || 
            assetReturns.length < 2) {
            return null;
        }

        // Calcul des rendements actifs (excès)
        const activeReturns = assetReturns.map((assetReturn, i) => 
            assetReturn - benchmarkReturns[i]
        );

        return this.calculateAnnualizedVolatility(activeReturns, frequency);
    }

    /**
     * Ratio d'information
     * Formule: Rendement actif moyen / Tracking Error
     * @param {Array} assetReturns 
     * @param {Array} benchmarkReturns 
     * @param {string} frequency 
     * @returns {number}
     */
    calculateInformationRatio(assetReturns, benchmarkReturns, frequency = 'daily') {
        if (!assetReturns || !benchmarkReturns || 
            assetReturns.length !== benchmarkReturns.length || 
            assetReturns.length < 2) {
            return null;
        }

        const activeReturns = assetReturns.map((assetReturn, i) => 
            assetReturn - benchmarkReturns[i]
        );

        const activeStats = this.calculateBasicStats(activeReturns);
        const trackingError = this.calculateTrackingError(assetReturns, benchmarkReturns, frequency);

        if (trackingError === null || trackingError === 0) return null;

        // Annualiser le rendement actif moyen
        let periodFactor;
        switch (frequency.toLowerCase()) {
            case 'daily':
                periodFactor = 252;
                break;
            case 'monthly':
                periodFactor = 12;
                break;
            default:
                periodFactor = 252;
        }

        const annualizedActiveReturn = activeStats.mean * periodFactor * 100; // En %

        return annualizedActiveReturn / trackingError;
    }

    /**
     * Corrélation avec benchmark
     * Formule standard de Pearson
     * @param {Array} assetReturns 
     * @param {Array} benchmarkReturns 
     * @returns {number}
     */
    calculateCorrelation(assetReturns, benchmarkReturns) {
        if (!assetReturns || !benchmarkReturns || 
            assetReturns.length !== benchmarkReturns.length || 
            assetReturns.length < 2) {
            return null;
        }

        const n = assetReturns.length;
        const assetMean = assetReturns.reduce((sum, r) => sum + r, 0) / n;
        const benchmarkMean = benchmarkReturns.reduce((sum, r) => sum + r, 0) / n;

        const numerator = assetReturns.reduce((sum, assetReturn, i) => {
            return sum + (assetReturn - assetMean) * (benchmarkReturns[i] - benchmarkMean);
        }, 0);

        const assetSumSquares = assetReturns.reduce((sum, assetReturn) => {
            return sum + Math.pow(assetReturn - assetMean, 2);
        }, 0);

        const benchmarkSumSquares = benchmarkReturns.reduce((sum, benchmarkReturn) => {
            return sum + Math.pow(benchmarkReturn - benchmarkMean, 2);
        }, 0);

        const denominator = Math.sqrt(assetSumSquares * benchmarkSumSquares);

        if (denominator === 0) return null;

        return numerator / denominator;
    }

    /**
     * Calcule toutes les métriques pour un actif
     * @param {Array} prices - Prix historiques
     * @param {Array} marketPrices - Prix du benchmark marché
     * @param {Array} sectorPrices - Prix du benchmark sectoriel (optionnel)
     * @param {string} frequency - Fréquence des données
     * @returns {Object} - Toutes les métriques calculées
     */
    calculateAllMetrics(prices, marketPrices = null, sectorPrices = null, frequency = 'daily') {
        if (!prices || prices.length < 10) {
            return this.getEmptyMetrics();
        }

        // Calcul des rendements
        const returns = this.calculateLogReturns(prices);
        const marketReturns = marketPrices ? this.calculateLogReturns(marketPrices) : null;
        const sectorReturns = sectorPrices ? this.calculateLogReturns(sectorPrices) : null;

        // Synchroniser les longueurs des séries
        const minLength = Math.min(
            returns.length,
            marketReturns ? marketReturns.length : returns.length,
            sectorReturns ? sectorReturns.length : returns.length
        );

        const syncReturns = returns.slice(-minLength);
        const syncMarketReturns = marketReturns ? marketReturns.slice(-minLength) : null;
        const syncSectorReturns = sectorReturns ? sectorReturns.slice(-minLength) : null;

        // Calcul du nombre de jours de trading
        const tradingDays = prices.length - 1;

        // Métriques de base
        const volatility5Y = this.calculateAnnualizedVolatility(syncReturns, frequency);
        const totalReturn5Y = this.calculateAnnualizedReturn(prices[0], prices[prices.length - 1], tradingDays);
        const sharpeRatio = this.calculateSharpeRatio(syncReturns, frequency);
        const maxDrawdown = this.calculateMaxDrawdown(prices);
        const calmarRatio = this.calculateCalmarRatio(prices, tradingDays);

        // Métriques vs marché
        let beta = null, alpha = null, correlationMarket = null, trackingErrorMarket = null, informationRatioMarket = null;
        if (syncMarketReturns && syncMarketReturns.length === syncReturns.length) {
            beta = this.calculateBeta(syncReturns, syncMarketReturns);
            alpha = this.calculateAlpha(syncReturns, syncMarketReturns, frequency);
            correlationMarket = this.calculateCorrelation(syncReturns, syncMarketReturns);
            trackingErrorMarket = this.calculateTrackingError(syncReturns, syncMarketReturns, frequency);
            informationRatioMarket = this.calculateInformationRatio(syncReturns, syncMarketReturns, frequency);
        }

        // Métriques vs secteur
        let correlationSector = null, trackingErrorSector = null, informationRatioSector = null;
        if (syncSectorReturns && syncSectorReturns.length === syncReturns.length) {
            correlationSector = this.calculateCorrelation(syncReturns, syncSectorReturns);
            trackingErrorSector = this.calculateTrackingError(syncReturns, syncSectorReturns, frequency);
            informationRatioSector = this.calculateInformationRatio(syncReturns, syncSectorReturns, frequency);
        }

        return {
            // Métriques de base
            volatility5Y,
            totalReturn5Y,
            sharpeRatio,
            maxDrawdown,
            calmarRatio,

            // Métriques vs marché
            beta,
            alpha,
            correlationMarket,
            trackingErrorMarket,
            informationRatioMarket,

            // Métriques vs secteur  
            correlationSector,
            trackingErrorSector,
            informationRatioSector,

            // Métadonnées
            dataPoints: syncReturns.length,
            tradingDays,
            frequency
        };
    }

    /**
     * Retourne des métriques vides en cas d'erreur
     * @returns {Object}
     */
    getEmptyMetrics() {
        return {
            volatility5Y: null,
            totalReturn5Y: null,
            sharpeRatio: null,
            maxDrawdown: null,
            calmarRatio: null,
            beta: null,
            alpha: null,
            correlationMarket: null,
            trackingErrorMarket: null,
            informationRatioMarket: null,
            correlationSector: null,
            trackingErrorSector: null,
            informationRatioSector: null,
            dataPoints: 0,
            tradingDays: 0,
            frequency: 'daily'
        };
    }
}

// Export global
window.AcademicFinancialCalculator = AcademicFinancialCalculator;