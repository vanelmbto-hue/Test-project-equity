// Extension avancée pour Amindis Equity Oracle
// Intégration des 15 marchés européens et métriques financières avancées

// Variables globales étendues
let currentFinancialAnalytics = null;
let benchmarkData = {};
let currentBenchmarks = {
    national: null,
    sector: null
};
let showingBenchmarks = false;

// Initialisation des fonctionnalités étendues
document.addEventListener('DOMContentLoaded', function() {
    // Attendre que tous les scripts soient chargés
    setTimeout(() => {
        console.log('Script dependencies check:', {
            FinancialAnalytics: typeof FinancialAnalytics,
            STOXX_SECTORS: typeof window.STOXX_SECTORS,
            EUROPEAN_STOCKS_COMPLETE: typeof EUROPEAN_STOCKS_COMPLETE
        });
        
        // Initialiser les analytics financières
        if (typeof FinancialAnalytics !== 'undefined') {
            currentFinancialAnalytics = new FinancialAnalytics();
        }
        
        setupAdvancedEventListeners();
        initializeEuropeanMatrix();
        setupBenchmarkFunctionality();
    }, 100);
});

function setupAdvancedEventListeners() {
    // Gestionnaires pour les nouveaux boutons de filtrage des pays
    const matrixFilters = [
        { id: 'matrixShowAll', country: 'all' },
        { id: 'matrixShowFrance', country: 'FR' },
        { id: 'matrixShowGermany', country: 'DE' },
        { id: 'matrixShowSpain', country: 'ES' },
        { id: 'matrixShowItaly', country: 'IT' },
        { id: 'matrixShowNetherlands', country: 'NL' },
        { id: 'matrixShowBelgium', country: 'BE' },
        { id: 'matrixShowUK', country: 'GB' },
        { id: 'matrixShowSwitzerland', country: 'CH' },
        { id: 'matrixShowSweden', country: 'SE' },
        { id: 'matrixShowNorway', country: 'NO' },
        { id: 'matrixShowFinland', country: 'FI' },
        { id: 'matrixShowDenmark', country: 'DK' },
        { id: 'matrixShowAustria', country: 'AT' },
        { id: 'matrixShowPoland', country: 'PL' }
    ];

    matrixFilters.forEach(filter => {
        const element = document.getElementById(filter.id);
        if (element) {
            element.addEventListener('click', () => filterMatrixByCountry(filter.country));
        }
    });

    // Gestionnaires pour les métriques avancées
    const refreshMetricsBtn = document.getElementById('refreshMetrics');
    if (refreshMetricsBtn) {
        refreshMetricsBtn.addEventListener('click', calculateAdvancedMetrics);
    }

    const showBenchmarkChartBtn = document.getElementById('showBenchmarkChart');
    if (showBenchmarkChartBtn) {
        showBenchmarkChartBtn.addEventListener('click', displayBenchmarkChart);
    }

    // Gestionnaire pour les clics sur les entreprises dans la matrice
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('company-link')) {
            e.preventDefault();
            const symbol = e.target.getAttribute('data-symbol');
            if (symbol) {
                console.log('Matrix company clicked:', symbol);
                // Utiliser la même fonction que la recherche principale
                if (typeof performSearch === 'function') {
                    performSearch(symbol);
                } else if (typeof window.performSearch === 'function') {
                    window.performSearch(symbol);
                } else {
                    console.error('performSearch function not found');
                }
            }
        }
    });

    // Gestionnaires pour les benchmarks
    const benchmarkButtons = [
        { id: 'showNationalBenchmark', type: 'national' },
        { id: 'showSectorBenchmark', type: 'sector' },
        { id: 'hideBenchmarks', type: 'hide' }
    ];

    benchmarkButtons.forEach(btn => {
        const element = document.getElementById(btn.id);
        if (element) {
            element.addEventListener('click', () => toggleBenchmark(btn.type));
        }
    });

    // Gestionnaires pour les sélecteurs rapides étendus
    const quickSelectors = [
        { id: 'quickFTSE100', index: 'FTSE100' },
        { id: 'quickAEX25', index: 'AEX25' }
    ];

    quickSelectors.forEach(selector => {
        const element = document.getElementById(selector.id);
        if (element) {
            element.addEventListener('click', () => showQuickIndex(selector.index));
        }
    });
}

function initializeEuropeanMatrix() {
    if (typeof EUROPEAN_STOCKS_COMPLETE === 'undefined') {
        console.warn('EUROPEAN_STOCKS_COMPLETE non disponible');
        return;
    }

    generateSectorMatrix();
}

function generateSectorMatrix() {
    const matrixBody = document.getElementById('matrixTableBody');
    if (!matrixBody || typeof window.STOXX_SECTORS === 'undefined' || typeof EUROPEAN_STOCKS_COMPLETE === 'undefined') {
        console.log('Matrix generation delayed - waiting for dependencies to load');
        setTimeout(generateSectorMatrix, 200);
        return;
    }

    matrixBody.innerHTML = '';

    // Obtenir tous les secteurs STOXX
    Object.entries(window.STOXX_SECTORS).forEach(([sectorKey, sectorInfo]) => {
        const row = document.createElement('tr');
        row.className = 'hover:bg-gray-50';

        // Colonne secteur
        const sectorCell = document.createElement('td');
        sectorCell.className = 'border border-gray-300 px-4 py-3 font-medium text-gray-800';
        sectorCell.innerHTML = `
            <div class="flex items-center">
                <i class="fas fa-industry mr-2 text-blue-600"></i>
                <span>${sectorInfo.name}</span>
            </div>
            <div class="text-xs text-gray-500 mt-1">${sectorInfo.benchmark}</div>
        `;
        row.appendChild(sectorCell);

        // Colonnes pays - utiliser la base de données complète
        const countries = ['FR', 'DE', 'ES', 'IT', 'NL', 'BE', 'GB', 'CH', 'SE', 'NO', 'FI', 'DK', 'AT', 'PL'];
        
        countries.forEach(countryCode => {
            const cell = document.createElement('td');
            cell.className = 'border border-gray-300 px-2 py-3 text-center text-sm';
            
            // Chercher des entreprises de ce secteur dans ce pays
            const companies = findCompaniesBySectorAndCountry(sectorKey, countryCode);
            
            if (companies.length > 0) {
                // Afficher jusqu'à 2 entreprises principales
                cell.innerHTML = companies.slice(0, 2).map(company => 
                    `<button class="company-link block w-full text-blue-600 hover:text-blue-800 hover:bg-blue-50 px-1 py-1 rounded text-xs mb-1 transition-colors" data-symbol="${company.symbol}">
                        ${company.name}
                    </button>`
                ).join('');
                
                if (companies.length > 2) {
                    cell.innerHTML += `<div class="text-xs text-gray-400">+${companies.length - 2} autres</div>`;
                }
            } else {
                cell.innerHTML = '<span class="text-gray-300">-</span>';
            }
            
            row.appendChild(cell);
        });

        matrixBody.appendChild(row);
    });

    // Ajouter les gestionnaires d'événements pour les liens d'entreprises
    setupCompanyLinks();
}

function findCompaniesBySectorAndCountry(sectorKey, countryCode) {
    if (typeof EUROPEAN_STOCKS_COMPLETE === 'undefined' || !EUROPEAN_STOCKS_COMPLETE[countryCode]) {
        return [];
    }

    const countryData = EUROPEAN_STOCKS_COMPLETE[countryCode];
    return countryData.companies.filter(company => company.sector === sectorKey);
}

function setupCompanyLinks() {
    document.querySelectorAll('.company-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const symbol = this.getAttribute('data-symbol');
            if (symbol) {
                // Utiliser la fonction existante de recherche
                if (typeof quickSearchInput !== 'undefined') {
                    quickSearchInput.value = symbol;
                }
                if (typeof searchInput !== 'undefined') {
                    searchInput.value = symbol;
                }
                handleSearch();
            }
        });
    });
}

function filterMatrixByCountry(country) {
    // Mise à jour des styles des boutons
    document.querySelectorAll('.matrix-filter-btn').forEach(btn => {
        btn.className = btn.className.replace('bg-blue-500 text-white', 'bg-gray-100 text-gray-700');
    });

    const activeBtn = document.querySelector(`#matrixShow${country === 'all' ? 'All' : getCountryButtonName(country)}`);
    if (activeBtn) {
        activeBtn.className = activeBtn.className.replace('bg-gray-100 text-gray-700', 'bg-blue-500 text-white');
    }

    if (country === 'all') {
        // Afficher toutes les colonnes
        showAllMatrixColumns();
    } else {
        // Afficher seulement la colonne du pays sélectionné
        hideMatrixColumnsExcept(country);
    }
}

function getCountryButtonName(countryCode) {
    const countryNames = {
        'FR': 'France', 'DE': 'Germany', 'ES': 'Spain', 'IT': 'Italy',
        'NL': 'Netherlands', 'BE': 'Belgium', 'GB': 'UK', 'CH': 'Switzerland',
        'SE': 'Sweden', 'NO': 'Norway', 'FI': 'Finland', 'DK': 'Denmark',
        'AT': 'Austria', 'PL': 'Poland'
    };
    return countryNames[countryCode] || countryCode;
}

function showAllMatrixColumns() {
    const table = document.getElementById('sectorCountryMatrix');
    if (!table) return;

    // Afficher toutes les colonnes
    table.querySelectorAll('th, td').forEach(cell => {
        cell.style.display = '';
    });
}

function hideMatrixColumnsExcept(countryCode) {
    const table = document.getElementById('sectorCountryMatrix');
    if (!table) return;

    const countries = ['FR', 'DE', 'ES', 'IT', 'NL', 'BE', 'GB', 'CH', 'SE', 'NO', 'FI', 'DK', 'AT', 'PL'];
    const targetIndex = countries.indexOf(countryCode);

    if (targetIndex === -1) return;

    // Masquer toutes les colonnes sauf secteur (index 0) et pays cible (index targetIndex + 1)
    const headerRow = table.querySelector('thead tr');
    const bodyRows = table.querySelectorAll('tbody tr');

    // Headers
    headerRow.querySelectorAll('th').forEach((th, index) => {
        if (index === 0 || index === targetIndex + 1) {
            th.style.display = '';
        } else {
            th.style.display = 'none';
        }
    });

    // Body cells
    bodyRows.forEach(row => {
        row.querySelectorAll('td').forEach((td, index) => {
            if (index === 0 || index === targetIndex + 1) {
                td.style.display = '';
            } else {
                td.style.display = 'none';
            }
        });
    });
}

// Fonctions pour les métriques financières avancées
async function calculateAdvancedMetrics() {
    if (!currentData || currentData.length === 0 || !currentFinancialAnalytics) {
        return;
    }

    try {
        // Afficher un indicateur de chargement
        updateMetricsDisplay({
            volatility5Y: 'Calcul...',
            totalReturn5Y: 'Calcul...',
            sectorCorrelation: 'Calcul...',
            trackingError: 'Calcul...',
            sharpeRatio: 'Calcul...',
            betaMarket: 'Calcul...',
            alphaSector: 'Calcul...',
            maxDrawdown: 'Calcul...'
        });

        // Calculer les métriques sur 5 ans (ou maximum disponible)
        const prices = currentData.slice(-1260).map(d => parseFloat(d.close)); // 5 ans ≈ 1260 jours de trading
        
        // Volatilité 5 ans
        const volatility5Y = currentFinancialAnalytics.calculateVolatility(prices);
        
        // Return total 5 ans
        const totalReturn5Y = currentFinancialAnalytics.calculateTotalReturn(prices);
        
        // Maximum drawdown
        const maxDrawdown = currentFinancialAnalytics.calculateMaxDrawdown(prices);
        
        // Sharpe ratio (approximatif avec risk-free rate à 2%)
        const returns = currentFinancialAnalytics.calculateReturns(prices);
        const sharpeRatio = currentFinancialAnalytics.calculateSharpeRatio(returns, 0.02);

        let sectorCorrelation = '--';
        let trackingError = '--';
        let betaMarket = '--';
        let alphaSector = '--';

        // Tenter de récupérer les données de benchmark pour les calculs avancés
        const stockInfo = getStockInfo(currentSymbol);
        if (stockInfo) {
            try {
                // Récupérer les benchmarks
                await fetchBenchmarkData(stockInfo);
                
                if (benchmarkData.sector && benchmarkData.sector.length > 0) {
                    const benchmarkPrices = benchmarkData.sector.slice(-1260).map(d => parseFloat(d.close));
                    const benchmarkReturns = currentFinancialAnalytics.calculateReturns(benchmarkPrices);
                    
                    // Corrélation avec le secteur
                    sectorCorrelation = currentFinancialAnalytics.calculateCorrelation(returns, benchmarkReturns);
                    
                    // Tracking error vs secteur
                    trackingError = currentFinancialAnalytics.calculateTrackingError(returns, benchmarkReturns);
                    
                    // Alpha vs secteur
                    alphaSector = currentFinancialAnalytics.calculateAlpha(returns, benchmarkReturns, 0.02);
                }

                if (benchmarkData.national && benchmarkData.national.length > 0) {
                    const nationalPrices = benchmarkData.national.slice(-1260).map(d => parseFloat(d.close));
                    const nationalReturns = currentFinancialAnalytics.calculateReturns(nationalPrices);
                    
                    // Bêta vs marché national
                    betaMarket = currentFinancialAnalytics.calculateBeta(returns, nationalReturns);
                }
            } catch (error) {
                console.warn('Erreur lors du calcul des métriques de benchmark:', error);
            }
        }

        // Mettre à jour l'affichage
        updateMetricsDisplay({
            volatility5Y: `${(volatility5Y * 100).toFixed(2)}%`,
            totalReturn5Y: `${(totalReturn5Y * 100).toFixed(2)}%`,
            sectorCorrelation: typeof sectorCorrelation === 'number' ? sectorCorrelation.toFixed(3) : sectorCorrelation,
            trackingError: typeof trackingError === 'number' ? `${(trackingError * 100).toFixed(2)}%` : trackingError,
            sharpeRatio: sharpeRatio.toFixed(3),
            betaMarket: typeof betaMarket === 'number' ? betaMarket.toFixed(3) : betaMarket,
            alphaSector: typeof alphaSector === 'number' ? `${(alphaSector * 100).toFixed(2)}%` : alphaSector,
            maxDrawdown: `${(maxDrawdown * 100).toFixed(2)}%`
        });

    } catch (error) {
        console.error('Erreur lors du calcul des métriques avancées:', error);
        updateMetricsDisplay({
            volatility5Y: 'Erreur',
            totalReturn5Y: 'Erreur',
            sectorCorrelation: 'Erreur',
            trackingError: 'Erreur',
            sharpeRatio: 'Erreur',
            betaMarket: 'Erreur',
            alphaSector: 'Erreur',
            maxDrawdown: 'Erreur'
        });
    }
}

function updateMetricsDisplay(metrics) {
    Object.entries(metrics).forEach(([key, value]) => {
        const element = document.getElementById(key);
        if (element) {
            element.textContent = value;
        }
    });
}

function getStockInfo(symbol) {
    if (typeof EUROPEAN_STOCKS_COMPLETE === 'undefined') {
        return null;
    }

    // Chercher dans la base de données complète
    for (const [countryCode, countryData] of Object.entries(EUROPEAN_STOCKS_COMPLETE)) {
        const company = countryData.companies.find(c => c.symbol === symbol);
        if (company) {
            return {
                ...company,
                country: countryCode,
                nationalBenchmark: countryData.benchmark,
                sectorBenchmark: window.STOXX_SECTORS?.[company.sector]?.benchmark || null
            };
        }
    }
    return null;
}

async function fetchBenchmarkData(stockInfo) {
    benchmarkData = { national: null, sector: null };

    try {
        // Récupérer le benchmark national
        if (stockInfo.nationalBenchmark) {
            const nationalResponse = await axios.get(`/api/stock/${stockInfo.nationalBenchmark}`);
            if (nationalResponse.data.success) {
                benchmarkData.national = nationalResponse.data.data;
            }
        }

        // Récupérer le benchmark sectoriel
        if (stockInfo.sectorBenchmark) {
            const sectorResponse = await axios.get(`/api/stock/${stockInfo.sectorBenchmark}`);
            if (sectorResponse.data.success) {
                benchmarkData.sector = sectorResponse.data.data;
            }
        }
    } catch (error) {
        console.warn('Erreur lors du chargement des benchmarks:', error);
    }
}

// Fonctions pour la gestion des benchmarks dans les graphiques
function setupBenchmarkFunctionality() {
    // Cette fonction sera appelée quand des données de stock sont chargées
}

async function toggleBenchmark(type) {
    if (!currentSymbol || !currentFinancialAnalytics) {
        return;
    }

    const stockInfo = getStockInfo(currentSymbol);
    if (!stockInfo) {
        return;
    }

    // Mettre à jour les styles des boutons
    updateBenchmarkButtonStyles(type);

    if (type === 'hide') {
        showingBenchmarks = false;
        // Redessiner le graphique sans benchmarks
        if (currentData.length > 0) {
            displayChart(currentData, selectedPeriod);
        }
        updateBenchmarkInfo('');
        return;
    }

    try {
        showingBenchmarks = true;
        
        // Charger les données de benchmark si nécessaire
        if (!benchmarkData.national && !benchmarkData.sector) {
            updateBenchmarkInfo('Chargement des benchmarks...');
            await fetchBenchmarkData(stockInfo);
        }

        let benchmarkToShow = null;
        let benchmarkName = '';

        if (type === 'national' && benchmarkData.national) {
            benchmarkToShow = benchmarkData.national;
            benchmarkName = `Benchmark National: ${stockInfo.nationalBenchmark}`;
        } else if (type === 'sector' && benchmarkData.sector) {
            benchmarkToShow = benchmarkData.sector;
            benchmarkName = `Benchmark Sectoriel: ${stockInfo.sectorBenchmark}`;
        }

        if (benchmarkToShow) {
            // Redessiner le graphique avec le benchmark
            displayChartWithBenchmark(currentData, benchmarkToShow, selectedPeriod);
            updateBenchmarkInfo(benchmarkName);
        } else {
            updateBenchmarkInfo('Benchmark non disponible');
        }

    } catch (error) {
        console.error('Erreur lors de l\'affichage du benchmark:', error);
        updateBenchmarkInfo('Erreur lors du chargement du benchmark');
    }
}

function updateBenchmarkButtonStyles(activeType) {
    document.querySelectorAll('.benchmark-btn').forEach(btn => {
        btn.className = btn.className.replace('bg-blue-500 text-white', 'bg-gray-100 text-gray-700')
                                    .replace('bg-green-500 text-white', 'bg-gray-100 text-gray-700');
    });

    let activeBtn = null;
    if (activeType === 'national') {
        activeBtn = document.getElementById('showNationalBenchmark');
        if (activeBtn) {
            activeBtn.className = activeBtn.className.replace('bg-gray-100 text-gray-700', 'bg-blue-500 text-white');
        }
    } else if (activeType === 'sector') {
        activeBtn = document.getElementById('showSectorBenchmark');
        if (activeBtn) {
            activeBtn.className = activeBtn.className.replace('bg-gray-100 text-gray-700', 'bg-green-500 text-white');
        }
    }
}

function updateBenchmarkInfo(info) {
    const benchmarkInfo = document.getElementById('benchmarkInfo');
    if (benchmarkInfo) {
        benchmarkInfo.textContent = info || 'Les benchmarks permettent de comparer la performance relative de l\'action.';
    }
}

function displayChartWithBenchmark(stockData, benchmarkData, period = '1Y') {
    // Cette fonction étend la fonction displayChart existante pour inclure les benchmarks
    if (!priceChart) {
        return;
    }

    const filteredStockData = filterDataByPeriod(stockData, period);
    const filteredBenchmarkData = filterDataByPeriod(benchmarkData, period);

    // Préparer les données du benchmark pour Chart.js
    const benchmarkChartData = filteredBenchmarkData.map(item => ({
        x: item.date,
        y: parseFloat(item.close)
    }));

    // Normaliser les données (base 100 au début de la période)
    if (benchmarkChartData.length > 0 && filteredStockData.length > 0) {
        const stockBasePrice = parseFloat(filteredStockData[0].close);
        const benchmarkBasePrice = benchmarkChartData[0].y;

        const normalizedStockData = filteredStockData.map(item => ({
            x: item.date,
            y: (parseFloat(item.close) / stockBasePrice) * 100
        }));

        const normalizedBenchmarkData = benchmarkChartData.map(item => ({
            x: item.x,
            y: (item.y / benchmarkBasePrice) * 100
        }));

        // Mettre à jour le graphique existant avec les données normalisées et le benchmark
        priceChart.data.datasets = [
            {
                label: currentSymbol,
                data: normalizedStockData,
                borderColor: 'rgb(59, 130, 246)',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                borderWidth: 2,
                fill: false,
                tension: 0.1
            },
            {
                label: 'Benchmark',
                data: normalizedBenchmarkData,
                borderColor: 'rgb(239, 68, 68)',
                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                borderWidth: 2,
                fill: false,
                tension: 0.1,
                borderDash: [5, 5]
            }
        ];

        priceChart.options.scales.y.title.text = 'Performance Relative (Base 100)';
        priceChart.update();
    }
}

// Fonction pour afficher un graphique de benchmark séparé
async function displayBenchmarkChart() {
    if (!currentSymbol) {
        alert('Veuillez d\'abord sélectionner une action');
        return;
    }

    const stockInfo = getStockInfo(currentSymbol);
    if (!stockInfo) {
        alert('Informations de l\'action non trouvées');
        return;
    }

    // Créer une modal ou une section pour afficher le graphique de comparaison
    await showBenchmarkComparisonModal(stockInfo);
}

async function showBenchmarkComparisonModal(stockInfo) {
    // Créer une modal pour afficher la comparaison des benchmarks
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    modal.innerHTML = `
        <div class="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-90vh overflow-y-auto">
            <div class="p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-xl font-bold text-gray-800">
                        <i class="fas fa-chart-line mr-2"></i>
                        Comparaison avec Benchmarks - ${currentSymbol}
                    </h3>
                    <button id="closeBenchmarkModal" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
                <div class="mb-4">
                    <p class="text-gray-600">
                        <strong>Secteur:</strong> ${window.STOXX_SECTORS?.[stockInfo.sector]?.name || 'Non classifié'} |
                        <strong>Pays:</strong> ${EUROPEAN_STOCKS_COMPLETE[stockInfo.country]?.country || stockInfo.country}
                    </p>
                </div>
                <div id="benchmarkChartContainer" style="height: 400px;">
                    <canvas id="benchmarkComparisonChart"></canvas>
                </div>
                <div class="mt-4 text-sm text-gray-600">
                    <p>Performance normalisée (base 100) - comparaison sur la période sélectionnée</p>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(modal);

    // Gestionnaire pour fermer la modal
    document.getElementById('closeBenchmarkModal').addEventListener('click', () => {
        document.body.removeChild(modal);
    });

    // Charger et afficher les données
    try {
        await fetchBenchmarkData(stockInfo);
        renderBenchmarkComparisonChart(stockInfo);
    } catch (error) {
        console.error('Erreur lors de l\'affichage de la comparaison:', error);
    }
}

function renderBenchmarkComparisonChart(stockInfo) {
    const ctx = document.getElementById('benchmarkComparisonChart');
    if (!ctx || !currentData) return;

    const datasets = [];
    
    // Données de l'action (normalisées)
    const stockPeriodData = filterDataByPeriod(currentData, selectedPeriod);
    if (stockPeriodData.length > 0) {
        const stockBasePrice = parseFloat(stockPeriodData[0].close);
        const normalizedStockData = stockPeriodData.map(item => ({
            x: item.date,
            y: (parseFloat(item.close) / stockBasePrice) * 100
        }));

        datasets.push({
            label: `${currentSymbol} (Action)`,
            data: normalizedStockData,
            borderColor: 'rgb(59, 130, 246)',
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            borderWidth: 3,
            fill: false,
            tension: 0.1
        });
    }

    // Benchmark national
    if (benchmarkData.national && benchmarkData.national.length > 0) {
        const nationalPeriodData = filterDataByPeriod(benchmarkData.national, selectedPeriod);
        if (nationalPeriodData.length > 0) {
            const nationalBasePrice = parseFloat(nationalPeriodData[0].close);
            const normalizedNationalData = nationalPeriodData.map(item => ({
                x: item.date,
                y: (parseFloat(item.close) / nationalBasePrice) * 100
            }));

            datasets.push({
                label: `${stockInfo.nationalBenchmark} (National)`,
                data: normalizedNationalData,
                borderColor: 'rgb(239, 68, 68)',
                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                borderWidth: 2,
                fill: false,
                tension: 0.1,
                borderDash: [5, 5]
            });
        }
    }

    // Benchmark sectoriel
    if (benchmarkData.sector && benchmarkData.sector.length > 0) {
        const sectorPeriodData = filterDataByPeriod(benchmarkData.sector, selectedPeriod);
        if (sectorPeriodData.length > 0) {
            const sectorBasePrice = parseFloat(sectorPeriodData[0].close);
            const normalizedSectorData = sectorPeriodData.map(item => ({
                x: item.date,
                y: (parseFloat(item.close) / sectorBasePrice) * 100
            }));

            datasets.push({
                label: `${stockInfo.sectorBenchmark} (Sectoriel)`,
                data: normalizedSectorData,
                borderColor: 'rgb(34, 197, 94)',
                backgroundColor: 'rgba(34, 197, 94, 0.1)',
                borderWidth: 2,
                fill: false,
                tension: 0.1,
                borderDash: [10, 5]
            });
        }
    }

    new Chart(ctx, {
        type: 'line',
        data: { datasets },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    type: 'time',
                    time: {
                        displayFormats: {
                            day: 'DD MMM',
                            month: 'MMM YYYY'
                        }
                    },
                    title: {
                        display: true,
                        text: 'Date'
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'Performance Relative (Base 100)'
                    }
                }
            },
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            interaction: {
                mode: 'nearest',
                axis: 'x',
                intersect: false
            }
        }
    });
}

// Fonctions pour la recherche étendue avec la nouvelle base de données
function extendedSearchEuropeanStocks(query) {
    if (!query || query.length < 1 || typeof EUROPEAN_STOCKS_COMPLETE === 'undefined') {
        return [];
    }
    
    const searchTerm = query.toLowerCase();
    const results = [];

    // Rechercher dans toutes les entreprises de tous les pays
    Object.entries(EUROPEAN_STOCKS_COMPLETE).forEach(([countryCode, countryData]) => {
        countryData.companies.forEach(company => {
            if (company.symbol.toLowerCase().includes(searchTerm) ||
                company.name.toLowerCase().includes(searchTerm) ||
                (company.fullName && company.fullName.toLowerCase().includes(searchTerm))) {
                
                results.push({
                    ...company,
                    country: countryCode,
                    countryName: countryData.country,
                    currency: countryData.currency,
                    sectorName: window.STOXX_SECTORS?.[company.sector]?.name || 'Non classifié'
                });
            }
        });
    });

    return results;
}

// Fonction pour afficher les suggestions étendues
function displayExtendedEuropeanSuggestions(results) {
    const suggestions = quickSearchSuggestions || searchSuggestions;
    if (!suggestions) return;

    suggestions.innerHTML = '';
    
    // Add title
    const titleDiv = document.createElement('div');
    titleDiv.className = 'px-4 py-2 bg-blue-50 text-sm font-semibold text-blue-700 border-b';
    titleDiv.innerHTML = '<i class="fas fa-globe-europe mr-1"></i>Actions Européennes (15 marchés)';
    suggestions.appendChild(titleDiv);
    
    results.forEach(stock => {
        const div = document.createElement('div');
        div.className = 'px-4 py-3 hover:bg-gray-100 cursor-pointer border-b border-gray-100';
        
        div.innerHTML = `
            <div class="flex justify-between items-center">
                <div>
                    <span class="inline-block px-2 py-1 text-xs bg-green-100 text-green-800 rounded mr-2">${stock.country}</span>
                    <span class="font-semibold text-blue-600">${stock.symbol}</span>
                    <span class="text-gray-800 ml-2">${stock.name}</span>
                </div>
                <span class="text-sm text-gray-500">${stock.currency}</span>
            </div>
            <div class="text-sm text-gray-600 mt-1 ml-14">
                <span class="text-blue-600">${stock.sectorName}</span> • ${stock.countryName}
            </div>
        `;
        
        div.addEventListener('click', function() {
            if (quickSearchInput) quickSearchInput.value = stock.symbol;
            if (searchInput) searchInput.value = stock.symbol;
            suggestions.classList.add('hidden');
            handleSearch();
        });
        
        suggestions.appendChild(div);
    });
    
    suggestions.classList.remove('hidden');
}

// Remplacer la fonction de recherche existante par la version étendue
if (typeof handleSearchSuggestions === 'function') {
    const originalHandleSearchSuggestions = handleSearchSuggestions;
    
    window.handleSearchSuggestions = async function() {
        const query = (quickSearchInput && quickSearchInput.value) || (searchInput && searchInput.value) || '';
        const trimmedQuery = query.trim();
        
        if (trimmedQuery.length < 1) {
            if (searchSuggestions) searchSuggestions.classList.add('hidden');
            if (quickSearchSuggestions) quickSearchSuggestions.classList.add('hidden');
            return;
        }

        // Priorité 1: Recherche dans les actions européennes étendues
        const europeanResults = extendedSearchEuropeanStocks(trimmedQuery);
        
        if (europeanResults.length > 0) {
            displayExtendedEuropeanSuggestions(europeanResults.slice(0, 15));
            return;
        }

        // Sinon, utiliser la recherche globale originale
        await originalHandleSearchSuggestions();
    };
}

// Fonction pour les sélecteurs rapides étendus
function showQuickIndex(indexName) {
    // Cette fonction peut être étendue pour gérer les nouveaux indices
    switch(indexName) {
        case 'FTSE100':
            if (quickSearchInput) quickSearchInput.value = '^FTSE';
            if (searchInput) searchInput.value = '^FTSE';
            break;
        case 'AEX25':
            if (quickSearchInput) quickSearchInput.value = '^AEX';
            if (searchInput) searchInput.value = '^AEX';
            break;
        default:
            return;
    }
    
    handleSearch();
}

// Export des fonctions pour compatibilité
if (typeof window !== 'undefined') {
    window.calculateAdvancedMetrics = calculateAdvancedMetrics;
    window.toggleBenchmark = toggleBenchmark;
    window.displayBenchmarkChart = displayBenchmarkChart;
    window.extendedSearchEuropeanStocks = extendedSearchEuropeanStocks;
    window.filterMatrixByCountry = filterMatrixByCountry;
}