// Global variables
let currentData = [];
let filteredData = [];
let currentPage = 1;
let recordsPerPage = 50;
let priceChart = null;
let currentSymbol = '';
let currentCurrency = 'USD';
let selectedPeriod = '1Y'; // Default period
let selectedChartType = 'candlestick'; // Default chart type
let chartData = [];
let volumeChart = null;

// DOM elements
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');
const searchSuggestions = document.getElementById('searchSuggestions');
const loadingState = document.getElementById('loadingState');
const resultsSection = document.getElementById('resultsSection');
const errorState = document.getElementById('errorState');
const errorMessage = document.getElementById('errorMessage');
const startDateInput = document.getElementById('startDate');
const endDateInput = document.getElementById('endDate');
const filterBtn = document.getElementById('filterBtn');

// Quick search elements (homepage)
const quickSearchInput = document.getElementById('quickSearchInput');
const quickSearchBtn = document.getElementById('quickSearchBtn');
const quickSearchSuggestions = document.getElementById('quickSearchSuggestions');
const showAdvancedSearchBtn = document.getElementById('showAdvancedSearch');

// European stocks selector buttons
const showCAC40Btn = document.getElementById('showCAC40');
const showDAX30Btn = document.getElementById('showDAX30');
const showAllEuropeanBtn = document.getElementById('showAllEuropean');
const clearSelectionBtn = document.getElementById('clearSelection');

// Period selector elements
const chartPeriodInfo = document.getElementById('chartPeriodInfo');
const periodButtons = {
    '3M': document.getElementById('period3M'),
    '6M': document.getElementById('period6M'),
    '1Y': document.getElementById('period1Y'),
    '2Y': document.getElementById('period2Y'),
    '3Y': document.getElementById('period3Y'),
    '5Y': document.getElementById('period5Y'),
    '10Y': document.getElementById('period10Y'),
    'MAX': document.getElementById('periodMax')
};

// Chart type selector elements
const chartTypeButtons = {
    'candlestick': document.getElementById('chartTypeCandlestick'),
    'line': document.getElementById('chartTypeLine'),
    'points': document.getElementById('chartTypePoints')
};

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    setupEventListeners();
    initializeDateInputs();
    initializeDashboard();
    showDashboard(); // Show dashboard by default
});

function setupEventListeners() {
    // Advanced search functionality
    if (searchBtn) {
        searchBtn.addEventListener('click', handleSearch);
    }
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                handleSearch();
            }
        });
    }

    // Quick search functionality (homepage)
    if (quickSearchBtn) {
        quickSearchBtn.addEventListener('click', handleQuickSearch);
    }
    if (quickSearchInput) {
        quickSearchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                handleQuickSearch();
            }
        });
    }

    // Show advanced search
    if (showAdvancedSearchBtn) {
        showAdvancedSearchBtn.addEventListener('click', function() {
            showSearchSection();
        });
    }

    // Real-time search suggestions
    searchInput.addEventListener('input', debounce(handleSearchSuggestions, 200));

    // European stocks selector buttons
    showCAC40Btn.addEventListener('click', () => showEuropeanStocksList('CAC40'));
    showDAX30Btn.addEventListener('click', () => showEuropeanStocksList('DAX30'));
    showAllEuropeanBtn.addEventListener('click', () => showEuropeanStocksList('ALL'));
    clearSelectionBtn.addEventListener('click', clearSuggestions);

    // Dashboard navigation
    const backToDashboardBtn = document.getElementById('backToDashboard');
    if (backToDashboardBtn) {
        backToDashboardBtn.addEventListener('click', showDashboard);
    }
    
    // Click outside to close suggestions
    document.addEventListener('click', function(e) {
        if (!searchInput.contains(e.target) && !searchSuggestions.contains(e.target)) {
            searchSuggestions.classList.add('hidden');
        }
    });

    // Date filtering
    filterBtn.addEventListener('click', handleDateFilter);

    // Table controls
    document.getElementById('recordsPerPage').addEventListener('change', function(e) {
        recordsPerPage = parseInt(e.target.value);
        currentPage = 1;
        displayData(filteredData);
    });

    document.getElementById('prevPage').addEventListener('click', function() {
        if (currentPage > 1) {
            currentPage--;
            displayData(filteredData);
        }
    });

    document.getElementById('nextPage').addEventListener('click', function() {
        const totalPages = Math.ceil(filteredData.length / recordsPerPage);
        if (currentPage < totalPages) {
            currentPage++;
            displayData(filteredData);
        }
    });

    // Export functionality
    document.getElementById('exportBtn').addEventListener('click', exportToCSV);
    document.getElementById('exportExcelBtn').addEventListener('click', exportToExcel);

    // Period selector functionality
    Object.entries(periodButtons).forEach(([period, button]) => {
        if (button) {
            button.addEventListener('click', () => selectChartPeriod(period));
        }
    });

    // Chart type selector functionality
    Object.entries(chartTypeButtons).forEach(([type, button]) => {
        if (button) {
            button.addEventListener('click', () => selectChartType(type));
        }
    });
}

function initializeDateInputs() {
    const today = new Date();
    const oneYearAgo = new Date(today);
    oneYearAgo.setFullYear(today.getFullYear() - 1);
    
    endDateInput.value = today.toISOString().split('T')[0];
    startDateInput.value = oneYearAgo.toISOString().split('T')[0];
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = function() {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

async function handleSearchSuggestions() {
    const query = searchInput.value.trim();
    
    if (query.length < 1) {
        searchSuggestions.classList.add('hidden');
        return;
    }

    // Priorité 1: Recherche dans les actions européennes (CAC40/DAX30)
    let europeanResults = [];
    if (typeof searchEuropeanStocks !== 'undefined') {
        europeanResults = searchEuropeanStocks(query);
    }

    // Si on a des résultats européens, les afficher en priorité
    if (europeanResults.length > 0) {
        displayEuropeanSuggestions(europeanResults.slice(0, 10));
        return;
    }

    // Priorité 2: Recherche globale via Yahoo Finance (si 2+ caractères)
    if (query.length >= 2) {
        try {
            const response = await axios.get(`/api/search/${encodeURIComponent(query)}`);
            const { results } = response.data;
            
            if (results && results.length > 0) {
                displaySearchSuggestions(results, 'Résultats globaux');
            } else {
                searchSuggestions.classList.add('hidden');
            }
        } catch (error) {
            console.error('Error fetching suggestions:', error);
            searchSuggestions.classList.add('hidden');
        }
    } else {
        searchSuggestions.classList.add('hidden');
    }
}

function displaySearchSuggestions(results, title = 'Résultats de recherche') {
    searchSuggestions.innerHTML = '';
    
    // Add title
    if (title) {
        const titleDiv = document.createElement('div');
        titleDiv.className = 'px-4 py-2 bg-gray-50 text-sm font-semibold text-gray-700 border-b';
        titleDiv.textContent = title;
        searchSuggestions.appendChild(titleDiv);
    }
    
    results.forEach(result => {
        const div = document.createElement('div');
        div.className = 'px-4 py-3 hover:bg-gray-100 cursor-pointer border-b border-gray-100';
        div.innerHTML = `
            <div class="flex justify-between items-center">
                <div>
                    <span class="font-semibold text-blue-600">${result.symbol}</span>
                    <span class="text-gray-800 ml-2">${result.shortname}</span>
                </div>
                <span class="text-sm text-gray-500">${result.exchDisp}</span>
            </div>
        `;
        
        div.addEventListener('click', function() {
            searchInput.value = result.symbol;
            searchSuggestions.classList.add('hidden');
            handleSearch();
        });
        
        searchSuggestions.appendChild(div);
    });
    
    searchSuggestions.classList.remove('hidden');
}

function displayEuropeanSuggestions(results) {
    searchSuggestions.innerHTML = '';
    
    // Add title
    const titleDiv = document.createElement('div');
    titleDiv.className = 'px-4 py-2 bg-blue-50 text-sm font-semibold text-blue-700 border-b';
    titleDiv.innerHTML = '<i class="fas fa-globe-europe mr-1"></i>Actions Européennes (CAC40 & DAX30)';
    searchSuggestions.appendChild(titleDiv);
    
    results.forEach(stock => {
        const div = document.createElement('div');
        div.className = 'px-4 py-3 hover:bg-gray-100 cursor-pointer border-b border-gray-100';
        
        const indexBadge = stock.symbol.includes('.PA') ? 
            '<span class="inline-block px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded mr-2">CAC40</span>' :
            '<span class="inline-block px-2 py-1 text-xs bg-green-100 text-green-800 rounded mr-2">DAX30</span>';
        
        div.innerHTML = `
            <div class="flex justify-between items-center">
                <div>
                    ${indexBadge}
                    <span class="font-semibold text-blue-600">${stock.symbol}</span>
                    <span class="text-gray-800 ml-2">${stock.name}</span>
                </div>
                <span class="text-sm text-gray-500">${stock.exchange}</span>
            </div>
            <div class="text-sm text-gray-600 mt-1 ml-12">${stock.fullName}</div>
        `;
        
        div.addEventListener('click', function() {
            searchInput.value = stock.symbol;
            searchSuggestions.classList.add('hidden');
            handleSearch();
        });
        
        searchSuggestions.appendChild(div);
    });
    
    searchSuggestions.classList.remove('hidden');
}

function showEuropeanStocksList(type) {
    searchSuggestions.innerHTML = '';
    
    let stocks = [];
    let title = '';
    let badgeClass = '';
    
    switch(type) {
        case 'CAC40':
            if (typeof EUROPEAN_STOCKS !== 'undefined') {
                stocks = EUROPEAN_STOCKS.CAC40;
            }
            title = '<i class="fas fa-flag-checkered mr-1"></i>CAC 40 - Toutes les valeurs (40)';
            badgeClass = 'bg-blue-100 text-blue-800';
            break;
        case 'DAX30':
            if (typeof EUROPEAN_STOCKS !== 'undefined') {
                stocks = EUROPEAN_STOCKS.DAX30;
            }
            title = '<i class="fas fa-flag-checkered mr-1"></i>DAX 30 - Toutes les valeurs (30)';
            badgeClass = 'bg-green-100 text-green-800';
            break;
        case 'ALL':
            if (typeof getAllEuropeanStocks !== 'undefined') {
                stocks = getAllEuropeanStocks();
            }
            title = '<i class="fas fa-globe-europe mr-1"></i>Toutes les actions européennes (70)';
            badgeClass = 'bg-purple-100 text-purple-800';
            break;
    }

    if (stocks.length === 0) {
        return;
    }
    
    // Add title
    const titleDiv = document.createElement('div');
    titleDiv.className = 'px-4 py-3 bg-gray-50 text-sm font-semibold text-gray-700 border-b sticky top-0';
    titleDiv.innerHTML = title;
    searchSuggestions.appendChild(titleDiv);
    
    // Add stocks
    stocks.forEach(stock => {
        const div = document.createElement('div');
        div.className = 'px-4 py-3 hover:bg-gray-100 cursor-pointer border-b border-gray-100';
        
        const indexBadge = type === 'ALL' ? 
            (stock.symbol.includes('.PA') ? 
                '<span class="inline-block px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded mr-2">CAC40</span>' :
                '<span class="inline-block px-2 py-1 text-xs bg-green-100 text-green-800 rounded mr-2">DAX30</span>') :
            `<span class="inline-block px-2 py-1 text-xs ${badgeClass} rounded mr-2">${type}</span>`;
        
        div.innerHTML = `
            <div class="flex justify-between items-center">
                <div>
                    ${indexBadge}
                    <span class="font-semibold text-blue-600">${stock.symbol}</span>
                    <span class="text-gray-800 ml-2">${stock.name}</span>
                </div>
                <span class="text-sm text-gray-500">${stock.exchange}</span>
            </div>
            <div class="text-sm text-gray-600 mt-1 ml-14">${stock.fullName}</div>
        `;
        
        div.addEventListener('click', function() {
            searchInput.value = stock.symbol;
            searchSuggestions.classList.add('hidden');
            handleSearch();
        });
        
        searchSuggestions.appendChild(div);
    });
    
    searchSuggestions.classList.remove('hidden');
}

function clearSuggestions() {
    searchInput.value = '';
    searchSuggestions.classList.add('hidden');
    searchInput.focus();
}

// Period management functions
function selectChartPeriod(period) {
    selectedPeriod = period;
    updatePeriodButtonStyles();
    
    if (currentData.length > 0) {
        // Filter data for the selected period
        filteredData = filterDataByPeriod(currentData, period);
        
        // Update chart
        displayChart(currentData, period);
        updateChartPeriodInfo(period);
        
        // Update table with filtered data
        currentPage = 1; // Reset to first page
        displayData(filteredData);
        updatePagination(filteredData);
        
        // Update records info to show period-specific count
        updateRecordsInfo(filteredData, period);
    }
}

function updatePeriodButtonStyles() {
    // Remove active class from all buttons
    Object.values(periodButtons).forEach(button => {
        if (button) {
            button.classList.remove('active');
            button.classList.add('bg-gray-100', 'text-gray-700');
            button.classList.remove('bg-blue-500', 'text-white');
        }
    });
    
    // Add active class to selected button
    const activeButton = periodButtons[selectedPeriod];
    if (activeButton) {
        activeButton.classList.add('active');
        activeButton.classList.remove('bg-gray-100', 'text-gray-700');
        activeButton.classList.add('bg-blue-500', 'text-white');
    }
}

function filterDataByPeriod(data, period) {
    if (!data || data.length === 0) return [];
    
    const now = new Date();
    let cutoffDate;
    
    switch(period) {
        case '3M':
            cutoffDate = new Date(now);
            cutoffDate.setMonth(now.getMonth() - 3);
            break;
        case '6M':
            cutoffDate = new Date(now);
            cutoffDate.setMonth(now.getMonth() - 6);
            break;
        case '1Y':
            cutoffDate = new Date(now);
            cutoffDate.setFullYear(now.getFullYear() - 1);
            break;
        case '2Y':
            cutoffDate = new Date(now);
            cutoffDate.setFullYear(now.getFullYear() - 2);
            break;
        case '3Y':
            cutoffDate = new Date(now);
            cutoffDate.setFullYear(now.getFullYear() - 3);
            break;
        case '5Y':
            cutoffDate = new Date(now);
            cutoffDate.setFullYear(now.getFullYear() - 5);
            break;
        case '10Y':
            cutoffDate = new Date(now);
            cutoffDate.setFullYear(now.getFullYear() - 10);
            break;
        case 'MAX':
            return data; // Return all data
        default:
            // Default to 1 year
            cutoffDate = new Date(now);
            cutoffDate.setFullYear(now.getFullYear() - 1);
    }
    
    const cutoffDateStr = cutoffDate.toISOString().split('T')[0];
    
    return data.filter(item => item.date >= cutoffDateStr);
}

function getPeriodLabel(period) {
    const labels = {
        '3M': '3 mois',
        '6M': '6 mois',
        '1Y': '1 an',
        '2Y': '2 ans',
        '3Y': '3 ans',
        '5Y': '5 ans',
        '10Y': '10 ans',
        'MAX': 'Historique complet'
    };
    return labels[period] || '1 an';
}

function updateChartPeriodInfo(period) {
    const label = getPeriodLabel(period);
    const dataCount = chartData.length;
    
    if (chartPeriodInfo) {
        chartPeriodInfo.textContent = `${label} (${dataCount} jours)`;
    }
}

// Chart type management functions
function selectChartType(type) {
    selectedChartType = type;
    updateChartTypeButtonStyles();
    
    if (currentData.length > 0) {
        displayChart(currentData, selectedPeriod);
    }
}

function updateChartTypeButtonStyles() {
    // Remove active class from all buttons
    Object.values(chartTypeButtons).forEach(button => {
        if (button) {
            button.classList.remove('active');
            button.classList.add('bg-gray-100', 'text-gray-700');
            button.classList.remove('bg-green-500', 'text-white', 'bg-blue-500');
        }
    });
    
    // Add active class to selected button
    const activeButton = chartTypeButtons[selectedChartType];
    if (activeButton) {
        activeButton.classList.add('active');
        activeButton.classList.remove('bg-gray-100', 'text-gray-700');
        if (selectedChartType === 'candlestick') {
            activeButton.classList.add('bg-green-500', 'text-white');
        } else {
            activeButton.classList.add('bg-blue-500', 'text-white');
        }
    }
}

async function handleSearch() {
    const symbol = searchInput.value.trim().toUpperCase();
    
    if (!symbol) {
        showError('Veuillez entrer un symbole d\'entreprise');
        return;
    }

    hideAllStates();
    showLoading();

    try {
        const response = await axios.get(`/api/stock/${encodeURIComponent(symbol)}`);
        const stockData = response.data;
        
        currentData = stockData.data;
        filteredData = [...currentData];
        currentPage = 1;
        currentSymbol = symbol;
        
        // Detect currency based on symbol and API response
        if (typeof detectCurrencyFromSymbol !== 'undefined') {
            currentCurrency = detectCurrencyFromSymbol(symbol);
        } else {
            currentCurrency = stockData.currency || 'USD';
        }
        
        // Override with API currency if available and different
        if (stockData.currency && stockData.currency !== 'USD' && stockData.currency !== currentCurrency) {
            currentCurrency = stockData.currency;
        }
        
        displayCompanyInfo(stockData);
        updatePeriodButtonStyles(); // Initialize period button styles
        updateChartTypeButtonStyles(); // Initialize chart type button styles
        
        // Apply period filter to data
        filteredData = filterDataByPeriod(currentData, selectedPeriod);
        
        displayChart(currentData, selectedPeriod);
        displayData(filteredData);
        updatePagination(filteredData);
        updateRecordsInfo(filteredData, selectedPeriod);
        showResults();
        
    } catch (error) {
        console.error('Error fetching stock data:', error);
        const errorMsg = error.response?.data?.details || error.response?.data?.error || 'Erreur lors de la récupération des données';
        showError(errorMsg);
    }
}

async function handleDateFilter() {
    const startDate = startDateInput.value;
    const endDate = endDateInput.value;
    
    if (!startDate || !endDate) {
        showError('Veuillez sélectionner les dates de début et de fin');
        return;
    }

    if (startDate > endDate) {
        showError('La date de début doit être antérieure à la date de fin');
        return;
    }

    // Filter current data
    filteredData = currentData.filter(item => {
        return item.date >= startDate && item.date <= endDate;
    });

    currentPage = 1;
    displayChart(filteredData);
    displayData(filteredData);
    
    // Update total days display
    document.getElementById('totalDays').textContent = filteredData.length;
}

function displayCompanyInfo(stockData) {
    // Try to get company info from European stocks database
    let companyName = stockData.companyName;
    let fullName = stockData.companyName;
    
    if (typeof getStockBySymbol !== 'undefined') {
        const europeanStock = getStockBySymbol(stockData.symbol);
        if (europeanStock) {
            companyName = europeanStock.name;
            fullName = europeanStock.fullName;
        }
    }
    
    document.getElementById('companyName').textContent = `${stockData.symbol} - ${companyName}`;
    
    // Add index badge if it's a European stock
    let indexBadge = '';
    if (stockData.symbol.includes('.PA')) {
        indexBadge = '<span class="inline-block px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded mr-2">CAC40</span>';
    } else if (stockData.symbol.includes('.DE')) {
        indexBadge = '<span class="inline-block px-2 py-1 text-xs bg-green-100 text-green-800 rounded mr-2">DAX30</span>';
    }
    
    document.getElementById('companyDetails').innerHTML = `
        ${indexBadge}
        <i class="fas fa-building mr-1"></i>${stockData.exchangeName || 'N/A'} • 
        <i class="fas fa-coins mr-1"></i>${currentCurrency}
        ${fullName !== companyName ? `<br><span class="text-sm text-gray-500">${fullName}</span>` : ''}
    `;
    document.getElementById('totalDays').textContent = stockData.totalDays;
}

function displayChart(data, period = null) {
    const priceCtx = document.getElementById('priceChart').getContext('2d');
    const volumeCtx = document.getElementById('volumeChart').getContext('2d');
    
    // Show loading state for large datasets
    const usePeriod = period || selectedPeriod;
    const shouldShowLoading = usePeriod === 'MAX' || (usePeriod === '10Y' && data.length > 2000);
    
    if (shouldShowLoading) {
        showChartLoading(true);
    }
    
    // Use setTimeout to allow UI to update
    setTimeout(() => {
        // Destroy existing charts
        if (priceChart) {
            priceChart.destroy();
        }
        if (volumeChart) {
            volumeChart.destroy();
        }

        // Filter data based on selected period
        chartData = filterDataByPeriod(data, usePeriod);
        
        // Optimize data for performance (sample large datasets)
        let optimizedData = chartData;
        if (chartData.length > 1000) {
            const sampleRate = Math.ceil(chartData.length / 1000);
            optimizedData = chartData.filter((item, index) => index % sampleRate === 0);
        }
        
        // Reverse for chart (oldest first)
        const chartDataReversed = [...optimizedData].reverse();
        
        // Create price chart
        createPriceChart(priceCtx, chartDataReversed, usePeriod);
        
        // Create volume chart
        createVolumeChart(volumeCtx, chartDataReversed, usePeriod);
        
        if (shouldShowLoading) {
            showChartLoading(false);
        }
    }, shouldShowLoading ? 100 : 0);
}

function createPriceChart(ctx, chartDataReversed, usePeriod) {
    const chartConfig = getPriceChartConfig(chartDataReversed, usePeriod);
    priceChart = new Chart(ctx, chartConfig);
}

function createVolumeChart(ctx, chartDataReversed, usePeriod) {
    // Prepare volume data with colors based on price movement
    const volumeData = chartDataReversed.map((item, index) => {
        const prevItem = chartDataReversed[index - 1];
        const currentClose = parseFloat(item.close);
        const prevClose = prevItem ? parseFloat(prevItem.close) : currentClose;
        const isUp = currentClose >= prevClose;
        
        return {
            x: item.date,
            y: parseInt(item.volume) || 0,
            backgroundColor: isUp ? '#10b981' : '#ef4444', // Green for up, red for down
            borderColor: isUp ? '#059669' : '#dc2626'
        };
    });

    volumeChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: chartDataReversed.map(item => formatDate(item.date)),
            datasets: [{
                label: 'Volume',
                data: volumeData.map(d => d.y),
                backgroundColor: volumeData.map(d => d.backgroundColor),
                borderColor: volumeData.map(d => d.borderColor),
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    display: true,
                    grid: {
                        color: '#404040'
                    },
                    ticks: {
                        color: '#b0b0b0'
                    }
                },
                y: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Volume',
                        color: '#b0b0b0'
                    },
                    grid: {
                        color: '#404040'
                    },
                    ticks: {
                        color: '#b0b0b0',
                        callback: function(value) {
                            if (value >= 1000000) {
                                return (value / 1000000).toFixed(1) + 'M';
                            } else if (value >= 1000) {
                                return (value / 1000).toFixed(1) + 'K';
                            }
                            return value;
                        }
                    }
                }
            }
        }
    });
}

function getPriceChartConfig(chartDataReversed, usePeriod) {
    const commonOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            title: {
                display: true,
                text: `Évolution des prix - ${getPeriodLabel(usePeriod)} (${chartData.length} jours)`,
                color: '#ffffff'
            },
            legend: {
                position: 'top',
                labels: {
                    color: '#b0b0b0'
                }
            }
        },
        scales: {
            x: {
                display: true,
                title: {
                    display: true,
                    text: 'Date',
                    color: '#b0b0b0'
                },
                grid: {
                    color: '#404040'
                },
                ticks: {
                    color: '#b0b0b0'
                }
            },
            y: {
                display: true,
                title: {
                    display: true,
                    text: `Prix (${currentCurrency})`,
                    color: '#b0b0b0'
                },
                grid: {
                    color: '#404040'
                },
                ticks: {
                    color: '#b0b0b0'
                }
            }
        }
    };

    switch(selectedChartType) {
        case 'candlestick':
            // Créer des chandeliers OHLC manuels avec barres
            return createCustomCandlestickChart(chartDataReversed, commonOptions);

        case 'line':
            return {
                type: 'line',
                data: {
                    labels: chartDataReversed.map(item => formatDate(item.date)),
                    datasets: [{
                        label: 'Prix de clôture',
                        data: chartDataReversed.map(item => parseFloat(item.close)),
                        borderColor: '#0ea5e9',
                        backgroundColor: 'rgba(14, 165, 233, 0.1)',
                        fill: true,
                        tension: 0.1,
                        pointRadius: 0,
                        pointHoverRadius: 4
                    }]
                },
                options: commonOptions
            };

        case 'points':
            return {
                type: 'line',
                data: {
                    labels: chartDataReversed.map(item => formatDate(item.date)),
                    datasets: [
                        {
                            label: 'Prix de clôture',
                            data: chartDataReversed.map(item => parseFloat(item.close)),
                            borderColor: '#0ea5e9',
                            backgroundColor: 'rgba(14, 165, 233, 0.8)',
                            pointBackgroundColor: '#0ea5e9',
                            pointBorderColor: '#0284c7',
                            pointRadius: 3,
                            pointHoverRadius: 6,
                            fill: false,
                            showLine: true,
                            tension: 0.1
                        },
                        {
                            label: 'Plus haut',
                            data: chartDataReversed.map(item => parseFloat(item.high)),
                            borderColor: '#ff6b35',
                            backgroundColor: 'rgba(255, 107, 53, 0.8)',
                            pointBackgroundColor: '#ff6b35',
                            pointBorderColor: '#ea580c',
                            pointRadius: 2,
                            pointHoverRadius: 5,
                            fill: false,
                            showLine: false,
                            tension: 0
                        },
                        {
                            label: 'Plus bas',
                            data: chartDataReversed.map(item => parseFloat(item.low)),
                            borderColor: '#ef4444',
                            backgroundColor: 'rgba(239, 68, 68, 0.8)',
                            pointBackgroundColor: '#ef4444',
                            pointBorderColor: '#dc2626',
                            pointRadius: 2,
                            pointHoverRadius: 5,
                            fill: false,
                            showLine: false,
                            tension: 0
                        }
                    ]
                },
                options: commonOptions
            };

        default:
            // Fallback to line chart
            return getPriceChartConfig(chartDataReversed, usePeriod);
    }
}

function createCustomCandlestickChart(chartDataReversed, commonOptions) {
    // Créer de vrais chandeliers OHLC avec des points et des lignes
    const ohlcData = chartDataReversed.map((item, index) => {
        const open = parseFloat(item.open);
        const high = parseFloat(item.high);
        const low = parseFloat(item.low);
        const close = parseFloat(item.close);
        const isUp = close >= open;
        
        return {
            index: index,
            open: open,
            high: high,
            low: low,
            close: close,
            isUp: isUp,
            color: isUp ? '#10b981' : '#ef4444',
            date: item.date
        };
    });

    return {
        type: 'line',
        data: {
            labels: chartDataReversed.map(item => formatDate(item.date)),
            datasets: [
                // Mèches (high-low lines)
                {
                    label: 'High-Low',
                    data: ohlcData.map(d => d.high),
                    borderColor: '#808080',
                    backgroundColor: 'transparent',
                    pointRadius: 0,
                    pointHoverRadius: 0,
                    showLine: false,
                    order: 3
                },
                {
                    label: 'Low points',
                    data: ohlcData.map(d => d.low),
                    borderColor: '#808080',
                    backgroundColor: 'transparent',
                    pointRadius: 0,
                    pointHoverRadius: 0,
                    showLine: false,
                    order: 3
                },
                // Corps des chandeliers (open-close)
                {
                    label: 'Prix de clôture',
                    data: ohlcData.map(d => d.close),
                    borderColor: ohlcData.map(d => d.color),
                    backgroundColor: ohlcData.map(d => d.color),
                    pointBackgroundColor: ohlcData.map(d => d.color),
                    pointBorderColor: ohlcData.map(d => d.color),
                    pointRadius: 4,
                    pointHoverRadius: 6,
                    showLine: false,
                    order: 1
                },
                {
                    label: 'Prix d\'ouverture',
                    data: ohlcData.map(d => d.open),
                    borderColor: ohlcData.map(d => d.color),
                    backgroundColor: 'transparent',
                    pointBackgroundColor: 'transparent',
                    pointBorderColor: ohlcData.map(d => d.color),
                    pointBorderWidth: 2,
                    pointRadius: 3,
                    pointHoverRadius: 5,
                    showLine: false,
                    order: 2
                }
            ]
        },
        options: {
            ...commonOptions,
            plugins: {
                ...commonOptions.plugins,
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    borderColor: '#404040',
                    borderWidth: 1,
                    callbacks: {
                        title: function(context) {
                            const index = context[0].dataIndex;
                            return formatDate(chartDataReversed[index].date);
                        },
                        label: function(context) {
                            const index = context.dataIndex;
                            const item = chartDataReversed[index];
                            const open = parseFloat(item.open);
                            const close = parseFloat(item.close);
                            const change = ((close - open) / open * 100).toFixed(2);
                            const changeSymbol = change >= 0 ? '+' : '';
                            
                            return [
                                `Ouverture: ${formatPrice(item.open)}`,
                                `Plus haut: ${formatPrice(item.high)}`,
                                `Plus bas: ${formatPrice(item.low)}`,
                                `Clôture: ${formatPrice(item.close)}`,
                                `Variation: ${changeSymbol}${change}%`
                            ];
                        }
                    }
                }
            },
            interaction: {
                mode: 'index',
                intersect: false
            }
        }
    };
}

function showChartLoading(show) {
    const chartContainer = document.querySelector('#priceChart').parentElement;
    let loadingDiv = chartContainer.querySelector('.chart-loading');
    
    if (show) {
        if (!loadingDiv) {
            loadingDiv = document.createElement('div');
            loadingDiv.className = 'chart-loading';
            loadingDiv.innerHTML = `
                <i class="fas fa-spinner fa-spin text-2xl text-blue-600 mb-2"></i>
                <p class="text-gray-600">Génération du graphique...</p>
            `;
            chartContainer.appendChild(loadingDiv);
        }
        loadingDiv.style.display = 'block';
    } else {
        if (loadingDiv) {
            loadingDiv.style.display = 'none';
        }
    }
}

function displayData(data) {
    const tableBody = document.getElementById('dataTableBody');
    const startIndex = (currentPage - 1) * recordsPerPage;
    const endIndex = startIndex + recordsPerPage;
    const pageData = data.slice(startIndex, endIndex);
    
    tableBody.innerHTML = '';
    
    pageData.forEach((item, index) => {
        const previousItem = data[startIndex + index + 1]; // Next item in array (previous day)
        const change = previousItem ? calculatePercentChange(parseFloat(previousItem.close), parseFloat(item.close)) : 0;
        const changeClass = change > 0 ? 'text-green-600' : change < 0 ? 'text-red-600' : 'text-gray-600';
        const changeIcon = change > 0 ? 'fa-arrow-up' : change < 0 ? 'fa-arrow-down' : 'fa-minus';
        
        const row = document.createElement('tr');
        row.className = 'hover:bg-gray-50';
        row.innerHTML = `
            <td class="px-4 py-3 border text-sm font-medium text-gray-900">${formatDate(item.date)}</td>
            <td class="px-4 py-3 border text-sm text-gray-900">${formatPrice(item.open)}</td>
            <td class="px-4 py-3 border text-sm text-green-600 font-medium">${formatPrice(item.high)}</td>
            <td class="px-4 py-3 border text-sm text-red-600 font-medium">${formatPrice(item.low)}</td>
            <td class="px-4 py-3 border text-sm text-gray-900 font-bold">${formatPrice(item.close)}</td>
            <td class="px-4 py-3 border text-sm text-gray-600">${formatVolume(item.volume)}</td>
            <td class="px-4 py-3 border text-sm font-medium ${changeClass}">
                <i class="fas ${changeIcon} mr-1"></i>
                ${change.toFixed(2)}%
            </td>
        `;
        tableBody.appendChild(row);
    });
    
    updatePagination(data);
}

function updatePagination(data) {
    const totalPages = Math.ceil(data.length / recordsPerPage);
    const startRecord = (currentPage - 1) * recordsPerPage + 1;
    const endRecord = Math.min(currentPage * recordsPerPage, data.length);
    
    document.getElementById('pageInfo').textContent = `Page ${currentPage} sur ${totalPages}`;
    document.getElementById('recordsInfo').textContent = `Affichage ${startRecord} à ${endRecord} sur ${data.length} enregistrements`;
    
    document.getElementById('prevPage').disabled = currentPage === 1;
    document.getElementById('nextPage').disabled = currentPage === totalPages;
}

function updateRecordsInfo(data, period) {
    const recordsInfo = document.getElementById('recordsInfo');
    const periodLabel = getPeriodLabel(period);
    const totalDays = data.length;
    
    if (period === 'MAX') {
        recordsInfo.innerHTML = `
            <span class="text-blue-600 font-medium">
                <i class="fas fa-infinity mr-1"></i>
                Historique complet : ${totalDays} jours de données
            </span>
        `;
    } else {
        recordsInfo.innerHTML = `
            <span class="text-green-600 font-medium">
                <i class="fas fa-calendar mr-1"></i>
                Période ${periodLabel} : ${totalDays} jours de données
            </span>
        `;
    }
}

function exportToCSV() {
    if (filteredData.length === 0) {
        showError('Aucune donnée à exporter');
        return;
    }

    const headers = ['Date', 'Ouverture', 'Plus Haut', 'Plus Bas', 'Clôture', 'Volume'];
    const csvContent = [
        headers.join(','),
        ...filteredData.map(item => [
            item.date,
            item.open,
            item.high,
            item.low,
            item.close,
            item.volume
        ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    
    const symbol = searchInput.value.trim().toUpperCase();
    const today = new Date().toISOString().split('T')[0];
    link.setAttribute('download', `${symbol}_prix_historiques_${today}.csv`);
    
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function exportToExcel() {
    if (filteredData.length === 0) {
        showError('Aucune donnée à exporter');
        return;
    }

    // Prepare data for Excel export
    const excelData = filteredData.map(item => {
        const previousItem = filteredData[filteredData.indexOf(item) + 1];
        const change = previousItem ? calculatePercentChange(parseFloat(previousItem.close), parseFloat(item.close)) : 0;
        
        return {
            'Date': formatDate(item.date),
            'Ouverture': formatPriceForExcel(item.open),
            'Plus Haut': formatPriceForExcel(item.high),
            'Plus Bas': formatPriceForExcel(item.low),
            'Clôture': formatPriceForExcel(item.close),
            'Volume': parseInt(item.volume) || 0,
            'Variation %': parseFloat(change.toFixed(2)),
            'Devise': currentCurrency
        };
    });

    // Create workbook and worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(excelData);

    // Set column widths
    const colWidths = [
        { wch: 12 }, // Date
        { wch: 12 }, // Ouverture
        { wch: 12 }, // Plus Haut
        { wch: 12 }, // Plus Bas
        { wch: 12 }, // Clôture
        { wch: 15 }, // Volume
        { wch: 12 }, // Variation %
        { wch: 8 }   // Devise
    ];
    ws['!cols'] = colWidths;

    // Add metadata sheet
    const metaData = [
        { 'Information': 'Symbole', 'Valeur': currentSymbol },
        { 'Information': 'Période', 'Valeur': getPeriodLabel(selectedPeriod) },
        { 'Information': 'Nombre de jours', 'Valeur': filteredData.length },
        { 'Information': 'Date d\'export', 'Valeur': new Date().toLocaleString('fr-FR') },
        { 'Information': 'Devise', 'Valeur': currentCurrency },
        { 'Information': 'Source', 'Valeur': 'Yahoo Finance via Amindis Equity Oracle' }
    ];
    const wsMetadata = XLSX.utils.json_to_sheet(metaData);
    
    // Add worksheets to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Données Historiques');
    XLSX.utils.book_append_sheet(wb, wsMetadata, 'Informations');

    // Generate filename
    const symbol = currentSymbol || 'ACTION';
    const periodLabel = selectedPeriod === 'MAX' ? 'COMPLET' : selectedPeriod;
    const today = new Date().toISOString().split('T')[0];
    const filename = `${symbol}_${periodLabel}_${filteredData.length}jours_${today}.xlsx`;

    // Download file
    XLSX.writeFile(wb, filename);
    
    // Show success message
    showSuccess(`Export Excel réussi: ${filename}`);
}

// Utility functions
function formatDate(dateStr) {
    const date = new Date(dateStr);
    return date.toLocaleDateString('fr-FR', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    });
}

function formatPrice(price, currency = null) {
    if (price === 'N/A' || !price) return 'N/A';
    
    // Use provided currency or global current currency
    const useCurrency = currency || currentCurrency || 'USD';
    
    // Get currency symbol
    let currencySymbol = '$'; // Default USD
    if (typeof getCurrencySymbol !== 'undefined') {
        currencySymbol = getCurrencySymbol(useCurrency);
    } else {
        // Fallback logic
        switch(useCurrency) {
            case 'EUR': currencySymbol = '€'; break;
            case 'GBP': currencySymbol = '£'; break;
            case 'JPY': currencySymbol = '¥'; break;
            case 'CHF': currencySymbol = 'CHF'; break;
            case 'CAD': currencySymbol = 'C$'; break;
            default: currencySymbol = '$';
        }
    }
    
    const formattedNumber = parseFloat(price).toLocaleString('fr-FR', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
    
    // For EUR, put symbol after the number (European convention)
    if (useCurrency === 'EUR') {
        return formattedNumber + ' ' + currencySymbol;
    } else {
        // For other currencies, put symbol before
        return currencySymbol + ' ' + formattedNumber;
    }
}

function formatVolume(volume) {
    if (volume === 'N/A' || !volume) return 'N/A';
    const num = parseInt(volume);
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toLocaleString('fr-FR');
}

function calculatePercentChange(oldValue, newValue) {
    if (!oldValue || oldValue === 0) return 0;
    return ((newValue - oldValue) / oldValue) * 100;
}

function formatPriceForExcel(price) {
    if (price === 'N/A' || !price) return 0;
    return parseFloat(price);
}

function showSuccess(message) {
    // Create success notification
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 transition-opacity duration-300';
    notification.innerHTML = `
        <div class="flex items-center">
            <i class="fas fa-check-circle mr-2"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

function hideAllStates() {
    loadingState.classList.add('hidden');
    resultsSection.classList.add('hidden');
    errorState.classList.add('hidden');
}

function showLoading() {
    loadingState.classList.remove('hidden');
}

function showResults() {
    resultsSection.classList.remove('hidden');
}

function showError(message) {
    errorMessage.textContent = message;
    errorState.classList.remove('hidden');
}

// API test on page load
async function testAPI() {
    try {
        const response = await axios.get('/api/status');
        console.log('API Status:', response.data);
    } catch (error) {
        console.error('API test failed:', error);
    }
}

// Dashboard and home page functions
function initializeDashboard() {
    if (typeof MARKET_INDICES !== 'undefined') {
        populateIndices();
    }
    
    // Load long-term indices chart (1995-2025)
    setTimeout(loadIndicesChart, 500);
    
    if (typeof COUNTRY_SECTOR_MATRIX !== 'undefined') {
        setupCountryButtons();
        showSectorMatrix('all');
    }
}

function populateIndices() {
    // Populate US indices
    const usContainer = document.getElementById('usIndices');
    if (usContainer && MARKET_INDICES.US) {
        usContainer.innerHTML = '';
        Object.entries(MARKET_INDICES.US).forEach(([symbol, info]) => {
            const div = document.createElement('div');
            div.className = 'flex justify-between items-center p-2 bg-white rounded cursor-pointer hover:bg-blue-100 transition-colors';
            div.innerHTML = `
                <span class="font-medium">${info.name}</span>
                <span class="text-sm text-gray-500">${symbol}</span>
            `;
            div.addEventListener('click', () => searchIndex(symbol));
            usContainer.appendChild(div);
        });
    }

    // Populate EU indices
    const euContainer = document.getElementById('euIndices');
    if (euContainer && MARKET_INDICES.EU) {
        euContainer.innerHTML = '';
        Object.entries(MARKET_INDICES.EU).forEach(([symbol, info]) => {
            const div = document.createElement('div');
            div.className = 'flex justify-between items-center p-2 bg-white rounded cursor-pointer hover:bg-green-100 transition-colors';
            div.innerHTML = `
                <span class="font-medium">${info.name}</span>
                <span class="text-sm text-gray-500">${symbol}</span>
            `;
            div.addEventListener('click', () => searchIndex(symbol));
            euContainer.appendChild(div);
        });
    }

    // Populate Asia indices
    const asiaContainer = document.getElementById('asiaIndices');
    if (asiaContainer && MARKET_INDICES.ASIA) {
        asiaContainer.innerHTML = '';
        Object.entries(MARKET_INDICES.ASIA).forEach(([symbol, info]) => {
            const div = document.createElement('div');
            div.className = 'flex justify-between items-center p-2 bg-white rounded cursor-pointer hover:bg-red-100 transition-colors';
            div.innerHTML = `
                <span class="font-medium">${info.name}</span>
                <span class="text-sm text-gray-500">${symbol}</span>
            `;
            div.addEventListener('click', () => searchIndex(symbol));
            asiaContainer.appendChild(div);
        });
    }
}

function loadIndicesChart() {
    // Placeholder for indices chart - would need real-time data
    const ctx = document.getElementById('indicesChart');
    if (ctx) {
        new Chart(ctx.getContext('2d'), {
            type: 'line',
            data: {
                labels: ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven'],
                datasets: [
                    {
                        label: 'S&P 500',
                        data: [4200, 4250, 4180, 4300, 4280],
                        borderColor: 'rgb(59, 130, 246)',
                        backgroundColor: 'rgba(59, 130, 246, 0.1)',
                        tension: 0.1
                    },
                    {
                        label: 'CAC 40',
                        data: [7000, 7100, 6950, 7150, 7120],
                        borderColor: 'rgb(34, 197, 94)',
                        backgroundColor: 'rgba(34, 197, 94, 0.1)',
                        tension: 0.1
                    },
                    {
                        label: 'DAX',
                        data: [15500, 15700, 15400, 15800, 15750],
                        borderColor: 'rgb(239, 68, 68)',
                        backgroundColor: 'rgba(239, 68, 68, 0.1)',
                        tension: 0.1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Performance des derniers 5 jours'
                    }
                }
            }
        });
    }
}

function setupCountryButtons() {
    const buttons = {
        'countryAll': () => showSectorMatrix('all'),
        'countryFrance': () => showSectorMatrix('France'),
        'countryGermany': () => showSectorMatrix('Allemagne'),
        'countryUS': () => showSectorMatrix('États-Unis')
    };

    Object.entries(buttons).forEach(([id, callback]) => {
        const button = document.getElementById(id);
        if (button) {
            button.addEventListener('click', callback);
        }
    });
}

function showSectorMatrix(country) {
    updateCountryButtonStyles(country);
    const container = document.getElementById('sectorMatrix');
    if (!container) return;

    container.innerHTML = '';

    let countries = [];
    if (country === 'all') {
        countries = getAllCountries ? getAllCountries() : ['France', 'Allemagne', 'États-Unis'];
    } else {
        countries = [country];
    }

    countries.forEach(countryName => {
        const sectors = getSectorsByCountry ? getSectorsByCountry(countryName) : [];
        
        sectors.forEach(sector => {
            const companies = getCompaniesByCountryAndSector ? getCompaniesByCountryAndSector(countryName, sector) : [];
            
            if (companies.length > 0) {
                const sectorDiv = document.createElement('div');
                sectorDiv.className = 'bg-gray-50 rounded-lg p-4 border border-gray-200';
                
                const flag = countryName === 'France' ? '🇫🇷' : countryName === 'Allemagne' ? '🇩🇪' : countryName === 'États-Unis' ? '🇺🇸' : '';
                
                sectorDiv.innerHTML = `
                    <h4 class="font-semibold text-gray-800 mb-3">
                        ${flag} ${countryName} - ${sector}
                    </h4>
                    <div class="space-y-2">
                        ${companies.map(company => `
                            <div class="flex justify-between items-center p-2 bg-white rounded hover:bg-blue-50 cursor-pointer transition-colors" onclick="searchCompany('${company.symbol}')">
                                <span class="font-medium text-sm">${company.name}</span>
                                <span class="text-xs text-gray-500">${company.symbol}</span>
                            </div>
                        `).join('')}
                    </div>
                `;
                
                container.appendChild(sectorDiv);
            }
        });
    });
}

function updateCountryButtonStyles(selectedCountry) {
    const buttons = ['countryAll', 'countryFrance', 'countryGermany', 'countryUS'];
    
    buttons.forEach(buttonId => {
        const button = document.getElementById(buttonId);
        if (button) {
            button.classList.remove('bg-blue-500', 'text-white');
            button.classList.add('bg-gray-100', 'text-gray-700');
        }
    });

    const activeButtonId = selectedCountry === 'all' ? 'countryAll' : 
                           selectedCountry === 'France' ? 'countryFrance' :
                           selectedCountry === 'Allemagne' ? 'countryGermany' :
                           selectedCountry === 'États-Unis' ? 'countryUS' : 'countryAll';
    
    const activeButton = document.getElementById(activeButtonId);
    if (activeButton) {
        activeButton.classList.remove('bg-gray-100', 'text-gray-700');
        activeButton.classList.add('bg-blue-500', 'text-white');
    }
}

function searchIndex(symbol) {
    searchInput.value = symbol;
    showSearchSection();
    handleSearch();
}

function searchCompany(symbol) {
    searchInput.value = symbol;
    showSearchSection();
    handleSearch();
}

function showDashboard() {
    document.getElementById('dashboardSection').classList.remove('hidden');
    document.getElementById('searchSection').classList.add('hidden');
    document.getElementById('resultsSection').classList.add('hidden');
    document.getElementById('errorState').classList.add('hidden');
    document.getElementById('loadingState').classList.add('hidden');
}

function showSearchSection() {
    document.getElementById('dashboardSection').classList.add('hidden');
    document.getElementById('searchSection').classList.remove('hidden');
}

// Fonction globale pour être appelée depuis HTML
window.searchCompany = searchCompany;

// ========================
// NOUVELLES FONCTIONNALITÉS
// ========================

// Quick Search functionality (homepage)
function handleQuickSearch() {
    const query = quickSearchInput.value.trim();
    if (query.length < 1) {
        showError('Veuillez saisir au moins un caractère.');
        return;
    }
    
    // Direct search - switch to search view and perform search
    showSearchSection();
    searchInput.value = query;
    handleSearch();
}

// Populate sector/country matrix
function populateMatrix() {
    const matrixBody = document.getElementById('matrixTableBody');
    if (!matrixBody) return;

    // Get all sectors from extended database
    const sectorsByCountry = {};
    const allSectors = new Set();
    
    Object.keys(EUROPEAN_STOCKS_EXTENDED).forEach(countryCode => {
        const country = EUROPEAN_STOCKS_EXTENDED[countryCode];
        sectorsByCountry[countryCode] = {};
        
        country.companies.forEach(company => {
            allSectors.add(company.sector);
            
            if (!sectorsByCountry[countryCode][company.sector]) {
                sectorsByCountry[countryCode][company.sector] = [];
            }
            sectorsByCountry[countryCode][company.sector].push(company);
        });
    });

    // Clear existing content
    matrixBody.innerHTML = '';

    // Create rows for each sector
    Array.from(allSectors).sort().forEach(sector => {
        const row = document.createElement('tr');
        
        // Sector name cell
        const sectorCell = document.createElement('td');
        sectorCell.className = 'border border-gray-300 px-4 py-3 font-medium text-gray-800 bg-gray-50';
        sectorCell.innerHTML = `<i class="fas fa-tag mr-2 text-blue-600"></i>${sector}`;
        row.appendChild(sectorCell);

        // Country cells
        ['FR', 'DE', 'ES', 'IT', 'NL', 'BE'].forEach(countryCode => {
            const cell = document.createElement('td');
            cell.className = 'border border-gray-300 px-2 py-2 text-center text-xs';
            
            const companies = sectorsByCountry[countryCode] && sectorsByCountry[countryCode][sector] 
                ? sectorsByCountry[countryCode][sector] : [];
            
            if (companies.length > 0) {
                const companyButtons = companies.map(company => {
                    const currency = EUROPEAN_STOCKS_EXTENDED[countryCode].currency;
                    return `<button onclick="searchCompany('${company.symbol}')" 
                            class="bg-blue-100 hover:bg-blue-200 text-blue-800 px-2 py-1 m-1 rounded text-xs transition-colors"
                            title="${company.name} (${currency})">
                            ${company.name.split(' ')[0]}
                        </button>`;
                }).join('');
                cell.innerHTML = companyButtons;
            } else {
                cell.innerHTML = '<span class="text-gray-400">-</span>';
            }
            
            row.appendChild(cell);
        });

        matrixBody.appendChild(row);
    });
}

// Add quick search suggestions
if (quickSearchInput) {
    quickSearchInput.addEventListener('input', debounce(handleQuickSearchSuggestions, 200));
}

function handleQuickSearchSuggestions() {
    const query = quickSearchInput.value.trim();
    
    if (query.length < 2) {
        quickSearchSuggestions.classList.add('hidden');
        return;
    }

    // Search in extended database
    const results = searchExtendedStocks(query);
    
    if (results.length === 0) {
        quickSearchSuggestions.classList.add('hidden');
        return;
    }

    // Display suggestions
    quickSearchSuggestions.innerHTML = results.slice(0, 8).map(stock => `
        <div class="px-4 py-3 hover:bg-blue-50 cursor-pointer border-b border-gray-100" 
             onclick="selectQuickStock('${stock.symbol}')">
            <div class="flex items-center justify-between">
                <div>
                    <span class="font-medium text-gray-900">${stock.name}</span>
                    <span class="ml-2 text-sm text-gray-600">${stock.symbol}</span>
                </div>
                <div class="text-right">
                    <div class="text-sm text-gray-600">${stock.flag} ${stock.country}</div>
                    <div class="text-xs text-blue-600">${stock.index}</div>
                </div>
            </div>
        </div>
    `).join('');
    
    quickSearchSuggestions.classList.remove('hidden');
}

function selectQuickStock(symbol) {
    quickSearchInput.value = symbol;
    quickSearchSuggestions.classList.add('hidden');
    handleQuickSearch();
}

// Add matrix filter functionality
document.addEventListener('DOMContentLoaded', function() {
    // Matrix filter buttons
    const matrixFilterButtons = document.querySelectorAll('.matrix-filter-btn');
    matrixFilterButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            // Update button states
            matrixFilterButtons.forEach(b => {
                b.className = b.className.replace('bg-blue-500 text-white', 'bg-gray-100 text-gray-700');
            });
            this.className = this.className.replace('bg-gray-100 text-gray-700', 'bg-blue-500 text-white');
            
            // Filter matrix (for now, just repopulate - can be enhanced for actual filtering)
            populateMatrix();
        });
    });

    // Quick access buttons
    const quickButtons = [
        { id: 'quickCAC40', action: () => showQuickStocksList('FR') },
        { id: 'quickDAX30', action: () => showQuickStocksList('DE') },
        { id: 'quickIBEX35', action: () => showQuickStocksList('ES') },
        { id: 'quickFTSE100', action: () => showQuickStocksList('IT') },
        { id: 'quickAEX25', action: () => showQuickStocksList('NL') }
    ];

    quickButtons.forEach(({ id, action }) => {
        const btn = document.getElementById(id);
        if (btn) {
            btn.addEventListener('click', action);
        }
    });

    // Populate matrix on load
    setTimeout(populateMatrix, 100);
});

function showQuickStocksList(countryCode) {
    const countryData = getStocksByCountry(countryCode);
    if (!countryData) return;

    // Create suggestions list
    quickSearchSuggestions.innerHTML = countryData.companies.slice(0, 10).map(company => `
        <div class="px-4 py-3 hover:bg-blue-50 cursor-pointer border-b border-gray-100" 
             onclick="selectQuickStock('${company.symbol}')">
            <div class="flex items-center justify-between">
                <div>
                    <span class="font-medium text-gray-900">${company.name}</span>
                    <span class="ml-2 text-sm text-gray-600">${company.symbol}</span>
                </div>
                <div class="text-right">
                    <div class="text-sm text-gray-600">${countryData.flag} ${countryData.country}</div>
                    <div class="text-xs text-blue-600">${company.sector}</div>
                </div>
            </div>
        </div>
    `).join('');
    
    quickSearchSuggestions.classList.remove('hidden');
}

// Close quick suggestions when clicking outside
document.addEventListener('click', function(e) {
    if (quickSearchInput && quickSearchSuggestions && 
        !quickSearchInput.contains(e.target) && 
        !quickSearchSuggestions.contains(e.target)) {
        quickSearchSuggestions.classList.add('hidden');
    }
});

// Update indices chart to show longer period (since 1995)
function loadIndicesChart() {
    const ctx = document.getElementById('indicesChart');
    if (!ctx) return;

    // Major indices with longer historical perspective
    const indicesData = [
        { name: 'S&P 500', symbol: '^GSPC', color: '#3B82F6' },
        { name: 'CAC 40', symbol: '^FCHI', color: '#10B981' },
        { name: 'DAX 30', symbol: '^GDAXI', color: '#F59E0B' },
        { name: 'FTSE 100', symbol: '^FTSE', color: '#8B5CF6' },
        { name: 'Nikkei 225', symbol: '^N225', color: '#EF4444' }
    ];

    // Note: For demo purposes, we'll create sample data
    // In production, you'd fetch real historical data from 1995
    const startYear = 1995;
    const currentYear = new Date().getFullYear();
    const years = [];
    
    for (let year = startYear; year <= currentYear; year++) {
        years.push(year.toString());
    }

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: years,
            datasets: indicesData.map(index => ({
                label: index.name,
                data: generateSamplePerformanceData(years.length),
                borderColor: index.color,
                backgroundColor: index.color + '20',
                fill: false,
                tension: 0.1
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Performance des Indices Principaux (1995-2025)',
                    color: '#ffffff'
                },
                legend: {
                    position: 'top',
                    labels: {
                        color: '#b0b0b0'
                    }
                }
            },
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Année',
                        color: '#b0b0b0'
                    },
                    grid: {
                        color: '#404040'
                    },
                    ticks: {
                        color: '#b0b0b0'
                    }
                },
                y: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Performance Relative (%)',
                        color: '#b0b0b0'
                    },
                    grid: {
                        color: '#404040'
                    },
                    ticks: {
                        color: '#b0b0b0'
                    }
                }
            }
        }
    });
}

function generateSamplePerformanceData(length) {
    const data = [];
    let value = 100; // Start at 100%
    
    for (let i = 0; i < length; i++) {
        // Simulate market growth with volatility
        const growth = (Math.random() - 0.3) * 20; // -6% to +14% yearly
        value *= (1 + growth / 100);
        data.push(Math.round(value * 100) / 100);
    }
    
    return data;
}

// Run API test
testAPI();

// Extension pour intégrer les métriques avancées dans le workflow existant
function integrateAdvancedMetrics() {
    // Cette fonction est appelée quand des données de stock sont chargées
    if (typeof calculateAdvancedMetrics === 'function') {
        setTimeout(() => {
            calculateAdvancedMetrics();
        }, 1000); // Délai pour s'assurer que les données sont chargées
    }
}

// Hook into existing search functionality to trigger advanced metrics
const originalHandleSearch = handleSearch;
if (typeof handleSearch === 'function') {
    window.handleSearch = function() {
        originalHandleSearch();
        
        // Déclencher le calcul des métriques avancées après un délai
        setTimeout(() => {
            integrateAdvancedMetrics();
        }, 2000);
    };
}

// Hook into existing quick search functionality  
const originalHandleQuickSearch = handleQuickSearch;
if (typeof handleQuickSearch === 'function') {
    window.handleQuickSearch = function() {
        originalHandleQuickSearch();
        
        // Déclencher le calcul des métriques avancées après un délai
        setTimeout(() => {
            integrateAdvancedMetrics();
        }, 2000);
    };
}