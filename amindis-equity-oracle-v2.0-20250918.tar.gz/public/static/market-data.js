// Données des indices boursiers mondiaux
const MARKET_INDICES = {
    // Indices américains
    US: {
        '^GSPC': { name: 'S&P 500', fullName: 'Standard & Poor\'s 500', country: 'États-Unis' },
        '^DJI': { name: 'Dow Jones', fullName: 'Dow Jones Industrial Average', country: 'États-Unis' },
        '^IXIC': { name: 'NASDAQ', fullName: 'NASDAQ Composite', country: 'États-Unis' },
        '^RUT': { name: 'Russell 2000', fullName: 'Russell 2000 Index', country: 'États-Unis' }
    },
    // Indices européens
    EU: {
        '^FCHI': { name: 'CAC 40', fullName: 'CAC 40 Index', country: 'France' },
        '^GDAXI': { name: 'DAX', fullName: 'DAX Performance Index', country: 'Allemagne' },
        '^FTSE': { name: 'FTSE 100', fullName: 'Financial Times Stock Exchange 100', country: 'Royaume-Uni' },
        '^AEX': { name: 'AEX', fullName: 'Amsterdam Exchange Index', country: 'Pays-Bas' }
    },
    // Indices asiatiques
    ASIA: {
        '^N225': { name: 'Nikkei 225', fullName: 'Nikkei Stock Average', country: 'Japon' },
        '^HSI': { name: 'Hang Seng', fullName: 'Hang Seng Index', country: 'Hong Kong' },
        '^SSEC': { name: 'Shanghai', fullName: 'Shanghai Composite Index', country: 'Chine' },
        '^KS11': { name: 'KOSPI', fullName: 'Korea Stock Price Index', country: 'Corée du Sud' }
    }
};

// Matrice pays/secteurs avec classification des entreprises européennes
const COUNTRY_SECTOR_MATRIX = {
    'France': {
        'Luxe & Mode': [
            { symbol: 'MC.PA', name: 'LVMH', fullName: 'LVMH Moët Hennessy Louis Vuitton SE' },
            { symbol: 'KER.PA', name: 'Kering', fullName: 'Kering SA' },
            { symbol: 'RMS.PA', name: 'Hermès', fullName: 'Hermès International SCA' }
        ],
        'Cosmétiques': [
            { symbol: 'OR.PA', name: 'L\'Oréal', fullName: 'L\'Oréal SA' }
        ],
        'Banque & Finance': [
            { symbol: 'BNP.PA', name: 'BNP Paribas', fullName: 'BNP Paribas SA' },
            { symbol: 'ACA.PA', name: 'Crédit Agricole', fullName: 'Crédit Agricole SA' },
            { symbol: 'GLE.PA', name: 'Société Générale', fullName: 'Société Générale SA' }
        ],
        'Énergie': [
            { symbol: 'FP.PA', name: 'TotalEnergies', fullName: 'TotalEnergies SE' },
            { symbol: 'ENGI.PA', name: 'ENGIE', fullName: 'ENGIE SA' }
        ],
        'Aéronautique & Défense': [
            { symbol: 'AIR.PA', name: 'Airbus', fullName: 'Airbus SE' },
            { symbol: 'SAF.PA', name: 'Safran', fullName: 'Safran SA' },
            { symbol: 'HO.PA', name: 'Thales', fullName: 'Thales SA' }
        ],
        'Pharmacie & Santé': [
            { symbol: 'SAN.PA', name: 'Sanofi', fullName: 'Sanofi SA' }
        ],
        'Automobile': [
            { symbol: 'RNO.PA', name: 'Renault', fullName: 'Renault SA' },
            { symbol: 'STLA.PA', name: 'Stellantis', fullName: 'Stellantis NV' }
        ],
        'Distribution': [
            { symbol: 'CA.PA', name: 'Carrefour', fullName: 'Carrefour SA' }
        ],
        'Technologie': [
            { symbol: 'DAST.PA', name: 'Dassault Systèmes', fullName: 'Dassault Systèmes SE' },
            { symbol: 'CAP.PA', name: 'Capgemini', fullName: 'Capgemini SE' }
        ]
    },
    'Allemagne': {
        'Technologie': [
            { symbol: 'SAP.DE', name: 'SAP', fullName: 'SAP SE' },
            { symbol: 'IFX.DE', name: 'Infineon', fullName: 'Infineon Technologies AG' }
        ],
        'Automobile': [
            { symbol: 'BMW.DE', name: 'BMW', fullName: 'Bayerische Motoren Werke AG' },
            { symbol: 'DAI.DE', name: 'Mercedes-Benz', fullName: 'Mercedes-Benz Group AG' },
            { symbol: 'VOW3.DE', name: 'Volkswagen', fullName: 'Volkswagen AG' }
        ],
        'Industrie': [
            { symbol: 'SIE.DE', name: 'Siemens', fullName: 'Siemens AG' },
            { symbol: 'CON.DE', name: 'Continental', fullName: 'Continental AG' }
        ],
        'Chimie': [
            { symbol: 'BAS.DE', name: 'BASF', fullName: 'BASF SE' },
            { symbol: 'BAYN.DE', name: 'Bayer', fullName: 'Bayer AG' }
        ],
        'Assurance': [
            { symbol: 'ALV.DE', name: 'Allianz', fullName: 'Allianz SE' },
            { symbol: 'MUV2.DE', name: 'Munich Re', fullName: 'Münchener Rückversicherungs-Gesellschaft AG' }
        ],
        'Banque': [
            { symbol: 'DBK.DE', name: 'Deutsche Bank', fullName: 'Deutsche Bank AG' }
        ],
        'Énergie': [
            { symbol: 'RWE.DE', name: 'RWE', fullName: 'RWE AG' },
            { symbol: 'EOAN.DE', name: 'E.ON', fullName: 'E.ON SE' }
        ],
        'Biens de consommation': [
            { symbol: 'ADS.DE', name: 'Adidas', fullName: 'adidas AG' },
            { symbol: 'BEI.DE', name: 'Beiersdorf', fullName: 'Beiersdorf AG' }
        ]
    },
    'États-Unis': {
        'Technologie': [
            { symbol: 'AAPL', name: 'Apple', fullName: 'Apple Inc.' },
            { symbol: 'MSFT', name: 'Microsoft', fullName: 'Microsoft Corporation' },
            { symbol: 'GOOGL', name: 'Alphabet', fullName: 'Alphabet Inc.' },
            { symbol: 'NVDA', name: 'NVIDIA', fullName: 'NVIDIA Corporation' },
            { symbol: 'META', name: 'Meta', fullName: 'Meta Platforms Inc.' }
        ],
        'E-commerce': [
            { symbol: 'AMZN', name: 'Amazon', fullName: 'Amazon.com Inc.' }
        ],
        'Automobile': [
            { symbol: 'TSLA', name: 'Tesla', fullName: 'Tesla Inc.' }
        ],
        'Finance': [
            { symbol: 'JPM', name: 'JPMorgan Chase', fullName: 'JPMorgan Chase & Co.' },
            { symbol: 'BAC', name: 'Bank of America', fullName: 'Bank of America Corporation' }
        ]
    }
};

// Fonction pour obtenir tous les indices par région
function getIndicesByRegion(region) {
    return MARKET_INDICES[region] || {};
}

// Fonction pour obtenir toutes les entreprises par pays et secteur
function getCompaniesByCountryAndSector(country, sector = null) {
    if (!COUNTRY_SECTOR_MATRIX[country]) return [];
    
    if (sector) {
        return COUNTRY_SECTOR_MATRIX[country][sector] || [];
    }
    
    // Retourner toutes les entreprises du pays
    const allCompanies = [];
    Object.values(COUNTRY_SECTOR_MATRIX[country]).forEach(sectorCompanies => {
        allCompanies.push(...sectorCompanies);
    });
    return allCompanies;
}

// Fonction pour obtenir tous les secteurs d'un pays
function getSectorsByCountry(country) {
    return Object.keys(COUNTRY_SECTOR_MATRIX[country] || {});
}

// Fonction pour obtenir tous les pays disponibles
function getAllCountries() {
    return Object.keys(COUNTRY_SECTOR_MATRIX);
}

// Fonction pour rechercher une entreprise dans la matrice
function findCompanyInMatrix(symbol) {
    for (const country of getAllCountries()) {
        for (const sector of getSectorsByCountry(country)) {
            const companies = getCompaniesByCountryAndSector(country, sector);
            const company = companies.find(c => c.symbol.toLowerCase() === symbol.toLowerCase());
            if (company) {
                return { ...company, country, sector };
            }
        }
    }
    return null;
}

// Export pour utilisation dans d'autres scripts
if (typeof window !== 'undefined') {
    window.MARKET_INDICES = MARKET_INDICES;
    window.COUNTRY_SECTOR_MATRIX = COUNTRY_SECTOR_MATRIX;
    window.getIndicesByRegion = getIndicesByRegion;
    window.getCompaniesByCountryAndSector = getCompaniesByCountryAndSector;
    window.getSectorsByCountry = getSectorsByCountry;
    window.getAllCountries = getAllCountries;
    window.findCompanyInMatrix = findCompanyInMatrix;
}