// Base de données des actions européennes
const EUROPEAN_STOCKS = {
  CAC40: [
    { symbol: 'AC.PA', name: 'Accor', fullName: 'Accor SA', exchange: 'Euronext Paris' },
    { symbol: 'AIR.PA', name: 'Airbus', fullName: 'Airbus SE', exchange: 'Euronext Paris' },
    { symbol: 'AI.PA', name: 'Air Liquide', fullName: 'L\'Air Liquide SA', exchange: 'Euronext Paris' },
    { symbol: 'MT.PA', name: 'ArcelorMittal', fullName: 'ArcelorMittal SA', exchange: 'Euronext Paris' },
    { symbol: 'ATO.PA', name: 'Atos', fullName: 'Atos SE', exchange: 'Euronext Paris' },
    { symbol: 'CS.PA', name: 'AXA', fullName: 'AXA SA', exchange: 'Euronext Paris' },
    { symbol: 'BNP.PA', name: 'BNP Paribas', fullName: 'BNP Paribas SA', exchange: 'Euronext Paris' },
    { symbol: 'EN.PA', name: 'Bouygues', fullName: 'Bouygues SA', exchange: 'Euronext Paris' },
    { symbol: 'CAP.PA', name: 'Capgemini', fullName: 'Capgemini SE', exchange: 'Euronext Paris' },
    { symbol: 'CA.PA', name: 'Carrefour', fullName: 'Carrefour SA', exchange: 'Euronext Paris' },
    { symbol: 'ACA.PA', name: 'Crédit Agricole', fullName: 'Crédit Agricole SA', exchange: 'Euronext Paris' },
    { symbol: 'BN.PA', name: 'Danone', fullName: 'Danone SA', exchange: 'Euronext Paris' },
    { symbol: 'DAST.PA', name: 'Dassault Systèmes', fullName: 'Dassault Systèmes SE', exchange: 'Euronext Paris' },
    { symbol: 'ENGI.PA', name: 'ENGIE', fullName: 'ENGIE SA', exchange: 'Euronext Paris' },
    { symbol: 'EL.PA', name: 'EssilorLuxottica', fullName: 'EssilorLuxottica SA', exchange: 'Euronext Paris' },
    { symbol: 'RMS.PA', name: 'Hermès', fullName: 'Hermès International SCA', exchange: 'Euronext Paris' },
    { symbol: 'KER.PA', name: 'Kering', fullName: 'Kering SA', exchange: 'Euronext Paris' },
    { symbol: 'LG.PA', name: 'Lafarge Holcim', fullName: 'LafargeHolcim Ltd', exchange: 'Euronext Paris' },
    { symbol: 'LR.PA', name: 'Legrand', fullName: 'Legrand SA', exchange: 'Euronext Paris' },
    { symbol: 'MC.PA', name: 'LVMH', fullName: 'LVMH Moët Hennessy Louis Vuitton SE', exchange: 'Euronext Paris' },
    { symbol: 'ML.PA', name: 'Michelin', fullName: 'Compagnie Générale des Établissements Michelin SCA', exchange: 'Euronext Paris' },
    { symbol: 'OR.PA', name: 'L\'Oréal', fullName: 'L\'Oréal SA', exchange: 'Euronext Paris' },
    { symbol: 'ORA.PA', name: 'Orange', fullName: 'Orange SA', exchange: 'Euronext Paris' },
    { symbol: 'RI.PA', name: 'Pernod Ricard', fullName: 'Pernod Ricard SA', exchange: 'Euronext Paris' },
    { symbol: 'UG.PA', name: 'Peugeot', fullName: 'Peugeot SA', exchange: 'Euronext Paris' },
    { symbol: 'PUB.PA', name: 'Publicis', fullName: 'Publicis Groupe SA', exchange: 'Euronext Paris' },
    { symbol: 'RNO.PA', name: 'Renault', fullName: 'Renault SA', exchange: 'Euronext Paris' },
    { symbol: 'SAF.PA', name: 'Safran', fullName: 'Safran SA', exchange: 'Euronext Paris' },
    { symbol: 'SAN.PA', name: 'Sanofi', fullName: 'Sanofi SA', exchange: 'Euronext Paris' },
    { symbol: 'SU.PA', name: 'Schneider Electric', fullName: 'Schneider Electric SE', exchange: 'Euronext Paris' },
    { symbol: 'GLE.PA', name: 'Société Générale', fullName: 'Société Générale SA', exchange: 'Euronext Paris' },
    { symbol: 'SOLB.PA', name: 'Solvay', fullName: 'Solvay SA', exchange: 'Euronext Paris' },
    { symbol: 'STLA.PA', name: 'Stellantis', fullName: 'Stellantis NV', exchange: 'Euronext Paris' },
    { symbol: 'STM.PA', name: 'STMicroelectronics', fullName: 'STMicroelectronics NV', exchange: 'Euronext Paris' },
    { symbol: 'TEP.PA', name: 'Teleperformance', fullName: 'Teleperformance SE', exchange: 'Euronext Paris' },
    { symbol: 'HO.PA', name: 'Thales', fullName: 'Thales SA', exchange: 'Euronext Paris' },
    { symbol: 'FP.PA', name: 'TotalEnergies', fullName: 'TotalEnergies SE', exchange: 'Euronext Paris' },
    { symbol: 'URW.PA', name: 'Unibail-Rodamco-Westfield', fullName: 'Unibail-Rodamco-Westfield SE', exchange: 'Euronext Paris' },
    { symbol: 'VIE.PA', name: 'Veolia', fullName: 'Veolia Environnement SA', exchange: 'Euronext Paris' },
    { symbol: 'DG.PA', name: 'Vinci', fullName: 'Vinci SA', exchange: 'Euronext Paris' },
    { symbol: 'VIV.PA', name: 'Vivendi', fullName: 'Vivendi SE', exchange: 'Euronext Paris' },
    { symbol: 'WLN.PA', name: 'Worldline', fullName: 'Worldline SA', exchange: 'Euronext Paris' }
  ],
  DAX30: [
    { symbol: 'ADS.DE', name: 'Adidas', fullName: 'adidas AG', exchange: 'XETRA' },
    { symbol: 'ALV.DE', name: 'Allianz', fullName: 'Allianz SE', exchange: 'XETRA' },
    { symbol: 'BAS.DE', name: 'BASF', fullName: 'BASF SE', exchange: 'XETRA' },
    { symbol: 'BAYN.DE', name: 'Bayer', fullName: 'Bayer AG', exchange: 'XETRA' },
    { symbol: 'BEI.DE', name: 'Beiersdorf', fullName: 'Beiersdorf AG', exchange: 'XETRA' },
    { symbol: 'BMW.DE', name: 'BMW', fullName: 'Bayerische Motoren Werke AG', exchange: 'XETRA' },
    { symbol: 'CON.DE', name: 'Continental', fullName: 'Continental AG', exchange: 'XETRA' },
    { symbol: 'DAI.DE', name: 'Mercedes-Benz', fullName: 'Mercedes-Benz Group AG', exchange: 'XETRA' },
    { symbol: 'DB1.DE', name: 'Deutsche Börse', fullName: 'Deutsche Börse AG', exchange: 'XETRA' },
    { symbol: 'DBK.DE', name: 'Deutsche Bank', fullName: 'Deutsche Bank AG', exchange: 'XETRA' },
    { symbol: 'DPW.DE', name: 'Deutsche Post', fullName: 'Deutsche Post AG', exchange: 'XETRA' },
    { symbol: 'DTE.DE', name: 'Deutsche Telekom', fullName: 'Deutsche Telekom AG', exchange: 'XETRA' },
    { symbol: 'EOAN.DE', name: 'E.ON', fullName: 'E.ON SE', exchange: 'XETRA' },
    { symbol: 'FRE.DE', name: 'Fresenius', fullName: 'Fresenius SE & Co. KGaA', exchange: 'XETRA' },
    { symbol: 'FME.DE', name: 'Fresenius Medical Care', fullName: 'Fresenius Medical Care AG & Co. KGaA', exchange: 'XETRA' },
    { symbol: 'HEI.DE', name: 'Heidelberg Cement', fullName: 'HeidelbergCement AG', exchange: 'XETRA' },
    { symbol: 'HEN3.DE', name: 'Henkel', fullName: 'Henkel AG & Co. KGaA', exchange: 'XETRA' },
    { symbol: 'IFX.DE', name: 'Infineon', fullName: 'Infineon Technologies AG', exchange: 'XETRA' },
    { symbol: 'LIN.DE', name: 'Linde', fullName: 'Linde plc', exchange: 'XETRA' },
    { symbol: 'MRK.DE', name: 'Merck KGaA', fullName: 'Merck KGaA', exchange: 'XETRA' },
    { symbol: 'MTX.DE', name: 'MTU Aero Engines', fullName: 'MTU Aero Engines AG', exchange: 'XETRA' },
    { symbol: 'MUV2.DE', name: 'Munich Re', fullName: 'Münchener Rückversicherungs-Gesellschaft AG', exchange: 'XETRA' },
    { symbol: 'RWE.DE', name: 'RWE', fullName: 'RWE AG', exchange: 'XETRA' },
    { symbol: 'SAP.DE', name: 'SAP', fullName: 'SAP SE', exchange: 'XETRA' },
    { symbol: 'SIE.DE', name: 'Siemens', fullName: 'Siemens AG', exchange: 'XETRA' },
    { symbol: 'SHL.DE', name: 'Siemens Healthineers', fullName: 'Siemens Healthineers AG', exchange: 'XETRA' },
    { symbol: 'VNA.DE', name: 'Vonovia', fullName: 'Vonovia SE', exchange: 'XETRA' },
    { symbol: 'VOW3.DE', name: 'Volkswagen', fullName: 'Volkswagen AG', exchange: 'XETRA' },
    { symbol: 'WDI.DE', name: 'Wirecard', fullName: 'Wirecard AG', exchange: 'XETRA' },
    { symbol: 'ZAL.DE', name: 'Zalando', fullName: 'Zalando SE', exchange: 'XETRA' }
  ]
};

// Fonction pour obtenir toutes les actions européennes
function getAllEuropeanStocks() {
  return [...EUROPEAN_STOCKS.CAC40, ...EUROPEAN_STOCKS.DAX30];
}

// Fonction pour rechercher dans les actions européennes
function searchEuropeanStocks(query) {
  if (!query || query.length < 1) return [];
  
  const searchTerm = query.toLowerCase();
  const allStocks = getAllEuropeanStocks();
  
  return allStocks.filter(stock => {
    return stock.symbol.toLowerCase().includes(searchTerm) ||
           stock.name.toLowerCase().includes(searchTerm) ||
           stock.fullName.toLowerCase().includes(searchTerm);
  });
}

// Fonction pour obtenir une action par symbole
function getStockBySymbol(symbol) {
  const allStocks = getAllEuropeanStocks();
  return allStocks.find(stock => stock.symbol.toLowerCase() === symbol.toLowerCase());
}

// Fonction pour détecter la devise selon le symbole
function detectCurrencyFromSymbol(symbol) {
  if (!symbol) return 'USD';
  
  const upperSymbol = symbol.toUpperCase();
  
  // Actions européennes
  if (upperSymbol.includes('.PA')) return 'EUR'; // France - Euronext Paris
  if (upperSymbol.includes('.DE')) return 'EUR'; // Allemagne - XETRA
  if (upperSymbol.includes('.MI')) return 'EUR'; // Italie - Borsa Italiana
  if (upperSymbol.includes('.AS')) return 'EUR'; // Pays-Bas - Euronext Amsterdam
  if (upperSymbol.includes('.BR')) return 'EUR'; // Belgique - Euronext Brussels
  if (upperSymbol.includes('.LS')) return 'EUR'; // Portugal - Euronext Lisbon
  
  // Actions britanniques
  if (upperSymbol.includes('.L') || upperSymbol.includes('.LON')) return 'GBP';
  
  // Actions suisses
  if (upperSymbol.includes('.SW') || upperSymbol.includes('.VX')) return 'CHF';
  
  // Actions canadiennes
  if (upperSymbol.includes('.TO') || upperSymbol.includes('.V')) return 'CAD';
  
  // Actions japonaises
  if (upperSymbol.includes('.T') || upperSymbol.includes('.TYO')) return 'JPY';
  
  // Actions hong-kongaises
  if (upperSymbol.includes('.HK')) return 'HKD';
  
  // Actions australiennes
  if (upperSymbol.includes('.AX')) return 'AUD';
  
  // Par défaut, actions américaines
  return 'USD';
}

// Fonction pour obtenir le symbole de devise selon le code
function getCurrencySymbol(currency) {
  const symbols = {
    'EUR': '€',
    'USD': '$',
    'GBP': '£',
    'CHF': 'CHF',
    'CAD': 'C$',
    'JPY': '¥',
    'HKD': 'HK$',
    'AUD': 'A$'
  };
  return symbols[currency] || currency;
}

// Export pour utilisation dans d'autres scripts
if (typeof window !== 'undefined') {
  window.EUROPEAN_STOCKS = EUROPEAN_STOCKS;
  window.getAllEuropeanStocks = getAllEuropeanStocks;
  window.searchEuropeanStocks = searchEuropeanStocks;
  window.getStockBySymbol = getStockBySymbol;
  window.detectCurrencyFromSymbol = detectCurrencyFromSymbol;
  window.getCurrencySymbol = getCurrencySymbol;
}