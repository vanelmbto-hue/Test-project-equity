// Moteur d'analyse financière avancée
// Calculs : Volatilité, Return Total, Corrélation, Tracking Error, Sharpe Ratio

// Classification sectorielle officielle STOXX Europe basée sur ICB (Industry Classification Benchmark)
const STOXX_SECTORS = {
    // 11 Industries ICB -> 20 Supersectors -> 45 Sectors STOXX
    'technology': {
        name: 'Technology',
        benchmark: 'SX8P.DE',
        color: '#00FF7F'
    },
    'telecommunications': {
        name: 'Telecommunications',
        benchmark: 'SXKP.DE',
        color: '#9370DB'
    },
    'healthcare': {
        name: 'Health Care',
        benchmark: 'SXDP.DE',
        color: '#FF6347'
    },
    'financial_services': {
        name: 'Financial Services',
        benchmark: 'SXFP.DE',
        color: '#191970'
    },
    'banks': {
        name: 'Banks',
        benchmark: 'SX7P.DE',
        color: '#4169E1'
    },
    'insurance': {
        name: 'Insurance',
        benchmark: 'SXIP.DE',
        color: '#DC143C'
    },
    'real_estate': {
        name: 'Real Estate',
        benchmark: 'SX86P.DE',
        color: '#D2691E'
    },
    'automobiles': {
        name: 'Automobiles & Parts',
        benchmark: 'SXAP.DE',
        color: '#B22222'
    },
    'food_beverage': {
        name: 'Food, Beverage & Tobacco',
        benchmark: 'SX3P.DE',
        color: '#228B22'
    },
    'personal_household': {
        name: 'Personal Care, Drug & Grocery Stores',
        benchmark: 'SXQP.DE',
        color: '#DA70D6'
    },
    'retail': {
        name: 'Retail',
        benchmark: 'SXRP.DE',
        color: '#FF8C00'
    },
    'media': {
        name: 'Media',
        benchmark: 'SXMP.DE',
        color: '#4B0082'
    },
    'travel_leisure': {
        name: 'Travel & Leisure',
        benchmark: 'SXTP.DE',
        color: '#00CED1'
    },
    'construction_materials': {
        name: 'Construction & Materials',
        benchmark: 'SX4P.DE',
        color: '#8B4513'
    },
    'industrial_goods': {
        name: 'Industrial Goods & Services',
        benchmark: 'SXNP.DE',
        color: '#1C4E80'
    },
    'basic_materials': {
        name: 'Basic Resources',
        benchmark: 'SXPP.DE',
        color: '#8B5A3C'
    },
    'chemicals': {
        name: 'Chemicals',
        benchmark: 'SX4P.DE',
        color: '#556B2F'
    },
    'energy': {
        name: 'Energy',
        benchmark: 'SXEP.DE',
        color: '#2C5F41'
    },
    'oil_gas': {
        name: 'Oil & Gas',
        benchmark: 'SXEP.DE',
        color: '#2F4F4F'
    },
    'utilities': {
        name: 'Utilities',
        benchmark: 'SX6P.DE',
        color: '#32CD32'
    }
};

class FinancialAnalytics {
    constructor() {
        this.riskFreeRate = 0.03; // Taux sans risque 3% (EUR) - aligné avec la littérature
        this.academicCalculator = null; // Sera initialisé à la demande
    }

    // Initialisation différée du calculateur académique
    getAcademicCalculator() {
        if (!this.academicCalculator && typeof AcademicFinancialCalculator !== 'undefined') {
            this.academicCalculator = new AcademicFinancialCalculator();
        }
        return this.academicCalculator;
    }

    // Méthodes compatibles avec l'ancien API mais utilisant les calculs académiques

    // Calcul de la volatilité annualisée (méthode académique)
    calculateVolatility(prices, period = 252) {
        if (!prices || prices.length < 2) return null;
        
        const calculator = this.getAcademicCalculator();
        if (!calculator) return null;
        
        const returns = calculator.calculateLogReturns(prices);
        return calculator.calculateAnnualizedVolatility(returns, 'daily');
    }

    // Calcul du rendement total annualisé (méthode académique)
    calculateTotalReturn(startPrice, endPrice, tradingDays) {
        if (!startPrice || !endPrice || tradingDays <= 0) return null;
        
        const calculator = this.getAcademicCalculator();
        if (!calculator) return null;
        
        return calculator.calculateAnnualizedReturn(startPrice, endPrice, tradingDays);
    }

    // Calcul des rendements (maintenant logarithmiques pour plus de précision)
    calculateReturns(prices) {
        const calculator = this.getAcademicCalculator();
        if (!calculator) {
            // Fallback vers l'ancienne méthode si le calculateur académique n'est pas disponible
            const returns = [];
            for (let i = 1; i < prices.length; i++) {
                if (prices[i] && prices[i - 1]) {
                    returns.push((prices[i] - prices[i - 1]) / prices[i - 1]);
                }
            }
            return returns;
        }
        return calculator.calculateLogReturns(prices);
    }

    // Calcul de la corrélation entre deux séries (méthode académique)
    calculateCorrelation(returns1, returns2) {
        const calculator = this.getAcademicCalculator();
        return calculator ? calculator.calculateCorrelation(returns1, returns2) : null;
    }

    // Calcul du tracking error (méthode académique)
    calculateTrackingError(assetReturns, benchmarkReturns) {
        const calculator = this.getAcademicCalculator();
        return calculator ? calculator.calculateTrackingError(assetReturns, benchmarkReturns, 'daily') : null;
    }

    // Calcul du ratio de Sharpe (méthode académique)
    calculateSharpeRatio(returns, riskFreeRate = null) {
        const calculator = this.getAcademicCalculator();
        return calculator ? calculator.calculateSharpeRatio(returns, 'daily') : null;
    }

    // Calcul du Beta (méthode académique CAPM)
    calculateBeta(assetReturns, marketReturns) {
        const calculator = this.getAcademicCalculator();
        return calculator ? calculator.calculateBeta(assetReturns, marketReturns) : null;
    }

    // Calcul de l'Alpha de Jensen (méthode académique)
    calculateAlpha(assetReturns, marketReturns, riskFreeRate = null) {
        const calculator = this.getAcademicCalculator();
        return calculator ? calculator.calculateAlpha(assetReturns, marketReturns, 'daily') : null;
    }

    // Calcul du Maximum Drawdown (méthode académique)
    calculateMaxDrawdown(prices) {
        const calculator = this.getAcademicCalculator();
        return calculator ? calculator.calculateMaxDrawdown(prices) : null;
    }

    // Analyse complète pour un titre (méthode académique)
    async analyzeStock(stockData, benchmarkData = null, sectorBenchmarkData = null) {
        // Préparer les données de prix
        const prices = stockData.map(item => parseFloat(item.close)).filter(p => !isNaN(p) && p > 0);
        
        // Préparer les données de benchmark si disponibles
        let marketPrices = null, sectorPrices = null;
        
        if (benchmarkData && benchmarkData.length > 0) {
            marketPrices = benchmarkData.map(item => parseFloat(item.close)).filter(p => !isNaN(p) && p > 0);
        }
        
        if (sectorBenchmarkData && sectorBenchmarkData.length > 0) {
            sectorPrices = sectorBenchmarkData.map(item => parseFloat(item.close)).filter(p => !isNaN(p) && p > 0);
        }
        
        // Calculer toutes les métriques académiques
        const calculator = this.getAcademicCalculator();
        const metrics = calculator ? calculator.calculateAllMetrics(prices, marketPrices, sectorPrices, 'daily') : this.getEmptyMetrics();
        
        // Formater pour compatibilité avec l'ancienne API
        const analysis = {
            // Métriques de base
            volatility_5y: metrics.volatility5Y,
            total_return_5y: metrics.totalReturn5Y,
            sharpe_ratio: metrics.sharpeRatio,
            max_drawdown: metrics.maxDrawdown,
            
            // Métriques vs benchmarks
            correlation_national: metrics.correlationMarket,
            correlation_sector: metrics.correlationSector,
            tracking_error_national: metrics.trackingErrorMarket,
            tracking_error_sector: metrics.trackingErrorSector,
            beta_national: metrics.beta,
            beta_sector: null, // Beta vs secteur non calculé dans la nouvelle version
            alpha_national: metrics.alpha,
            alpha_sector: null, // Alpha vs secteur non calculé dans la nouvelle version
            
            // Métriques académiques supplémentaires
            calmar_ratio: metrics.calmarRatio,
            information_ratio_national: metrics.informationRatioMarket,
            information_ratio_sector: metrics.informationRatioSector,
            
            // Informations sur la période
            analysis_period: metrics.tradingDays / 252, // Années
            data_points: metrics.dataPoints,
            start_date: stockData.length > 0 ? stockData[stockData.length - 1].date : null,
            end_date: stockData.length > 0 ? stockData[0].date : null,
            
            // Métadonnées sur la qualité des calculs
            calculation_method: 'academic',
            frequency: metrics.frequency,
            risk_free_rate: calculator ? calculator.riskFreeRate : this.riskFreeRate
        };
        
        return analysis;
    }

    // Métriques vides en cas d'erreur
    getEmptyMetrics() {
        return {
            volatility5Y: null,
            totalReturn5Y: null,
            sharpeRatio: null,
            maxDrawdown: null,
            calmarRatio: null,
            beta: null,
            alpha: null,
            correlationMarket: null,
            trackingErrorMarket: null,
            informationRatioMarket: null,
            correlationSector: null,
            trackingErrorSector: null,
            informationRatioSector: null,
            dataPoints: 0,
            tradingDays: 0,
            frequency: 'daily'
        };
    }
}

// Fonction utilitaire pour formater les métriques
function formatMetric(value, type = 'percentage', decimals = 2) {
    if (value === null || value === undefined || isNaN(value)) {
        return 'N/A';
    }
    
    switch (type) {
        case 'percentage':
            return `${value.toFixed(decimals)}%`;
        case 'ratio':
            return value.toFixed(decimals);
        case 'currency':
            return `${value.toFixed(decimals)}`;
        default:
            return value.toFixed(decimals);
    }
}

// Fonction pour interpréter le niveau de risque
function getRiskLevel(volatility) {
    if (volatility === null) return { level: 'N/A', color: 'gray' };
    
    if (volatility < 15) return { level: 'Faible', color: 'green' };
    if (volatility < 25) return { level: 'Modéré', color: 'yellow' };
    if (volatility < 40) return { level: 'Élevé', color: 'orange' };
    return { level: 'Très Élevé', color: 'red' };
}

// Fonction pour interpréter la corrélation
function getCorrelationLevel(correlation) {
    if (correlation === null) return { level: 'N/A', color: 'gray' };
    
    const absCorr = Math.abs(correlation);
    if (absCorr < 0.3) return { level: 'Faible', color: 'red' };
    if (absCorr < 0.7) return { level: 'Modérée', color: 'yellow' };
    return { level: 'Forte', color: 'green' };
}

// Export global
window.FinancialAnalytics = FinancialAnalytics;
window.formatMetric = formatMetric;
window.getRiskLevel = getRiskLevel;
window.getCorrelationLevel = getCorrelationLevel;
window.STOXX_SECTORS = STOXX_SECTORS;