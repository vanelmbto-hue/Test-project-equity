// Base de données complète des actions européennes - Toutes les bourses majeures
// Couverture : 15 bourses européennes avec secteurs STOXX

const EUROPEAN_STOCKS_COMPLETE = {
    // France - CAC 40
    'FR': {
        country: 'France',
        flag: '🇫🇷',
        index: 'CAC 40',
        currency: 'EUR',
        suffix: '.PA',
        benchmark: '^FCHI',
        companies: [
            { symbol: 'AC.PA', name: 'Accor', fullName: 'Accor SA', sector: 'travel_leisure' },
            { symbol: 'AIR.PA', name: 'Airbus', fullName: 'Airbus SE', sector: 'industrial_goods' },
            { symbol: 'AI.PA', name: 'Air Liquide', fullName: 'L\'Air Liquide SA', sector: 'basic_materials' },
            { symbol: 'MT.PA', name: 'ArcelorMittal', fullName: 'ArcelorMittal SA', sector: 'basic_materials' },
            { symbol: 'ATO.PA', name: 'Atos', fullName: 'Atos SE', sector: 'technology' },
            { symbol: 'CS.PA', name: 'AXA', fullName: 'AXA SA', sector: 'insurance' },
            { symbol: 'BNP.PA', name: 'BNP Paribas', fullName: 'BNP Paribas SA', sector: 'banks' },
            { symbol: 'EN.PA', name: 'Bouygues', fullName: 'Bouygues SA', sector: 'construction_materials' },
            { symbol: 'CAP.PA', name: 'Capgemini', fullName: 'Capgemini SE', sector: 'technology' },
            { symbol: 'CA.PA', name: 'Carrefour', fullName: 'Carrefour SA', sector: 'food_beverage' },
            { symbol: 'ACA.PA', name: 'Crédit Agricole', fullName: 'Crédit Agricole SA', sector: 'banks' },
            { symbol: 'BN.PA', name: 'Danone', fullName: 'Danone SA', sector: 'food_beverage' },
            { symbol: 'DAST.PA', name: 'Dassault Systèmes', fullName: 'Dassault Systèmes SE', sector: 'technology' },
            { symbol: 'ENGI.PA', name: 'ENGIE', fullName: 'ENGIE SA', sector: 'utilities' },
            { symbol: 'EL.PA', name: 'EssilorLuxottica', fullName: 'EssilorLuxottica SA', sector: 'healthcare' },
            { symbol: 'RMS.PA', name: 'Hermès', fullName: 'Hermès International SCA', sector: 'personal_household' },
            { symbol: 'KER.PA', name: 'Kering', fullName: 'Kering SA', sector: 'personal_household' },
            { symbol: 'LR.PA', name: 'Legrand', fullName: 'Legrand SA', sector: 'industrial_goods' },
            { symbol: 'MC.PA', name: 'LVMH', fullName: 'LVMH Moët Hennessy Louis Vuitton SE', sector: 'personal_household' },
            { symbol: 'ML.PA', name: 'Michelin', fullName: 'Compagnie Générale des Établissements Michelin SCA', sector: 'automobiles' },
            { symbol: 'OR.PA', name: 'L\'Oréal', fullName: 'L\'Oréal SA', sector: 'personal_household' },
            { symbol: 'ORA.PA', name: 'Orange', fullName: 'Orange SA', sector: 'telecommunications' },
            { symbol: 'RI.PA', name: 'Pernod Ricard', fullName: 'Pernod Ricard SA', sector: 'food_beverage' },
            { symbol: 'UG.PA', name: 'Peugeot', fullName: 'Peugeot SA', sector: 'automobiles' },
            { symbol: 'PUB.PA', name: 'Publicis', fullName: 'Publicis Groupe SA', sector: 'media' },
            { symbol: 'RNO.PA', name: 'Renault', fullName: 'Renault SA', sector: 'automobiles' },
            { symbol: 'SAF.PA', name: 'Safran', fullName: 'Safran SA', sector: 'industrial_goods' },
            { symbol: 'SAN.PA', name: 'Sanofi', fullName: 'Sanofi SA', sector: 'healthcare' },
            { symbol: 'SU.PA', name: 'Schneider Electric', fullName: 'Schneider Electric SE', sector: 'industrial_goods' },
            { symbol: 'GLE.PA', name: 'Société Générale', fullName: 'Société Générale SA', sector: 'banks' },
            { symbol: 'STLA.PA', name: 'Stellantis', fullName: 'Stellantis NV', sector: 'automobiles' },
            { symbol: 'STM.PA', name: 'STMicroelectronics', fullName: 'STMicroelectronics NV', sector: 'technology' },
            { symbol: 'TEP.PA', name: 'Teleperformance', fullName: 'Teleperformance SE', sector: 'telecommunications' },
            { symbol: 'HO.PA', name: 'Thales', fullName: 'Thales SA', sector: 'industrial_goods' },
            { symbol: 'FP.PA', name: 'TotalEnergies', fullName: 'TotalEnergies SE', sector: 'oil_gas' },
            { symbol: 'URW.PA', name: 'Unibail-Rodamco-Westfield', fullName: 'Unibail-Rodamco-Westfield SE', sector: 'real_estate' },
            { symbol: 'VIE.PA', name: 'Veolia', fullName: 'Veolia Environnement SA', sector: 'utilities' },
            { symbol: 'DG.PA', name: 'Vinci', fullName: 'Vinci SA', sector: 'construction_materials' },
            { symbol: 'VIV.PA', name: 'Vivendi', fullName: 'Vivendi SE', sector: 'media' },
            { symbol: 'WLN.PA', name: 'Worldline', fullName: 'Worldline SA', sector: 'financial_services' }
        ]
    },
    // Allemagne - DAX 40
    'DE': {
        country: 'Allemagne', 
        flag: '🇩🇪',
        index: 'DAX 40',
        currency: 'EUR',
        suffix: '.DE',
        benchmark: '^GDAXI',
        companies: [
            { symbol: 'ADS.DE', name: 'Adidas', fullName: 'adidas AG', sector: 'personal_household' },
            { symbol: 'ALV.DE', name: 'Allianz', fullName: 'Allianz SE', sector: 'insurance' },
            { symbol: 'BAS.DE', name: 'BASF', fullName: 'BASF SE', sector: 'basic_materials' },
            { symbol: 'BAYN.DE', name: 'Bayer', fullName: 'Bayer AG', sector: 'healthcare' },
            { symbol: 'BEI.DE', name: 'Beiersdorf', fullName: 'Beiersdorf AG', sector: 'personal_household' },
            { symbol: 'BMW.DE', name: 'BMW', fullName: 'Bayerische Motoren Werke AG', sector: 'automobiles' },
            { symbol: 'CON.DE', name: 'Continental', fullName: 'Continental AG', sector: 'automobiles' },
            { symbol: 'DAI.DE', name: 'Mercedes-Benz', fullName: 'Mercedes-Benz Group AG', sector: 'automobiles' },
            { symbol: 'DB1.DE', name: 'Deutsche Börse', fullName: 'Deutsche Börse AG', sector: 'financial_services' },
            { symbol: 'DBK.DE', name: 'Deutsche Bank', fullName: 'Deutsche Bank AG', sector: 'banks' },
            { symbol: 'DPW.DE', name: 'Deutsche Post', fullName: 'Deutsche Post AG', sector: 'industrial_goods' },
            { symbol: 'DTE.DE', name: 'Deutsche Telekom', fullName: 'Deutsche Telekom AG', sector: 'telecommunications' },
            { symbol: 'EOAN.DE', name: 'E.ON', fullName: 'E.ON SE', sector: 'utilities' },
            { symbol: 'FRE.DE', name: 'Fresenius', fullName: 'Fresenius SE & Co. KGaA', sector: 'healthcare' },
            { symbol: 'FME.DE', name: 'Fresenius Medical Care', fullName: 'Fresenius Medical Care AG & Co. KGaA', sector: 'healthcare' },
            { symbol: 'HEI.DE', name: 'Heidelberg Cement', fullName: 'HeidelbergCement AG', sector: 'construction_materials' },
            { symbol: 'HEN3.DE', name: 'Henkel', fullName: 'Henkel AG & Co. KGaA', sector: 'personal_household' },
            { symbol: 'IFX.DE', name: 'Infineon', fullName: 'Infineon Technologies AG', sector: 'technology' },
            { symbol: 'LIN.DE', name: 'Linde', fullName: 'Linde plc', sector: 'basic_materials' },
            { symbol: 'MRK.DE', name: 'Merck KGaA', fullName: 'Merck KGaA', sector: 'healthcare' },
            { symbol: 'MTX.DE', name: 'MTU Aero Engines', fullName: 'MTU Aero Engines AG', sector: 'industrial_goods' },
            { symbol: 'MUV2.DE', name: 'Munich Re', fullName: 'Münchener Rückversicherungs-Gesellschaft AG', sector: 'insurance' },
            { symbol: 'RWE.DE', name: 'RWE', fullName: 'RWE AG', sector: 'utilities' },
            { symbol: 'SAP.DE', name: 'SAP', fullName: 'SAP SE', sector: 'technology' },
            { symbol: 'SIE.DE', name: 'Siemens', fullName: 'Siemens AG', sector: 'industrial_goods' },
            { symbol: 'SHL.DE', name: 'Siemens Healthineers', fullName: 'Siemens Healthineers AG', sector: 'healthcare' },
            { symbol: 'VNA.DE', name: 'Vonovia', fullName: 'Vonovia SE', sector: 'real_estate' },
            { symbol: 'VOW3.DE', name: 'Volkswagen', fullName: 'Volkswagen AG', sector: 'automobiles' },
            { symbol: 'ZAL.DE', name: 'Zalando', fullName: 'Zalando SE', sector: 'retail' }
        ]
    },
    // Espagne - IBEX 35
    'ES': {
        country: 'Espagne',
        flag: '🇪🇸', 
        index: 'IBEX 35',
        currency: 'EUR',
        suffix: '.MC',
        benchmark: '^IBEX',
        companies: [
            { symbol: 'SAN.MC', name: 'Banco Santander', fullName: 'Banco Santander SA', sector: 'banks' },
            { symbol: 'ITX.MC', name: 'Inditex', fullName: 'Industria de Diseño Textil SA', sector: 'retail' },
            { symbol: 'BBVA.MC', name: 'BBVA', fullName: 'Banco Bilbao Vizcaya Argentaria SA', sector: 'banks' },
            { symbol: 'IBE.MC', name: 'Iberdrola', fullName: 'Iberdrola SA', sector: 'utilities' },
            { symbol: 'TEF.MC', name: 'Telefónica', fullName: 'Telefónica SA', sector: 'telecommunications' },
            { symbol: 'REP.MC', name: 'Repsol', fullName: 'Repsol SA', sector: 'oil_gas' },
            { symbol: 'AENA.MC', name: 'Aena', fullName: 'Aena SA', sector: 'industrial_goods' },
            { symbol: 'ENG.MC', name: 'Enagás', fullName: 'Enagás SA', sector: 'utilities' },
            { symbol: 'FER.MC', name: 'Ferrovial', fullName: 'Ferrovial SA', sector: 'construction_materials' },
            { symbol: 'ACS.MC', name: 'ACS', fullName: 'ACS Actividades de Construcción y Servicios SA', sector: 'construction_materials' }
        ]
    },
    // Italie - FTSE MIB 40
    'IT': {
        country: 'Italie',
        flag: '🇮🇹',
        index: 'FTSE MIB 40',
        currency: 'EUR', 
        suffix: '.MI',
        benchmark: 'FTSEMIB.MI',
        companies: [
            { symbol: 'UCG.MI', name: 'UniCredit', fullName: 'UniCredit SpA', sector: 'banks' },
            { symbol: 'ISP.MI', name: 'Intesa Sanpaolo', fullName: 'Intesa Sanpaolo SpA', sector: 'banks' },
            { symbol: 'ENI.MI', name: 'Eni', fullName: 'Eni SpA', sector: 'oil_gas' },
            { symbol: 'ENEL.MI', name: 'Enel', fullName: 'Enel SpA', sector: 'utilities' },
            { symbol: 'STM.MI', name: 'STMicroelectronics', fullName: 'STMicroelectronics NV', sector: 'technology' },
            { symbol: 'TIT.MI', name: 'Telecom Italia', fullName: 'Telecom Italia SpA', sector: 'telecommunications' },
            { symbol: 'G.MI', name: 'Assicurazioni Generali', fullName: 'Assicurazioni Generali SpA', sector: 'insurance' },
            { symbol: 'RACE.MI', name: 'Ferrari', fullName: 'Ferrari NV', sector: 'automobiles' },
            { symbol: 'CNH.MI', name: 'CNH Industrial', fullName: 'CNH Industrial NV', sector: 'industrial_goods' },
            { symbol: 'LUX.MI', name: 'Luxottica', fullName: 'Luxottica Group SpA', sector: 'personal_household' }
        ]
    },
    // Pays-Bas - AEX 25
    'NL': {
        country: 'Pays-Bas',
        flag: '🇳🇱',
        index: 'AEX 25', 
        currency: 'EUR',
        suffix: '.AS',
        benchmark: '^AEX',
        companies: [
            { symbol: 'ASML.AS', name: 'ASML Holding', fullName: 'ASML Holding NV', sector: 'technology' },
            { symbol: 'RDSA.AS', name: 'Royal Dutch Shell', fullName: 'Royal Dutch Shell plc', sector: 'oil_gas' },
            { symbol: 'UNA.AS', name: 'Unilever', fullName: 'Unilever NV', sector: 'food_beverage' },
            { symbol: 'INGA.AS', name: 'ING Group', fullName: 'ING Groep NV', sector: 'banks' },
            { symbol: 'PHIA.AS', name: 'Philips', fullName: 'Koninklijke Philips NV', sector: 'healthcare' },
            { symbol: 'ADYEN.AS', name: 'Adyen', fullName: 'Adyen NV', sector: 'financial_services' },
            { symbol: 'HEIA.AS', name: 'Heineken', fullName: 'Heineken NV', sector: 'food_beverage' },
            { symbol: 'KPN.AS', name: 'KPN', fullName: 'Koninklijke KPN NV', sector: 'telecommunications' },
            { symbol: 'NN.AS', name: 'NN Group', fullName: 'NN Group NV', sector: 'insurance' },
            { symbol: 'DSM.AS', name: 'DSM', fullName: 'Koninklijke DSM NV', sector: 'basic_materials' }
        ]
    },
    // Belgique - BEL 20
    'BE': {
        country: 'Belgique',
        flag: '🇧🇪',
        index: 'BEL 20',
        currency: 'EUR',
        suffix: '.BR', 
        benchmark: '^BFX',
        companies: [
            { symbol: 'ABI.BR', name: 'Anheuser-Busch InBev', fullName: 'Anheuser-Busch InBev SA/NV', sector: 'food_beverage' },
            { symbol: 'KBC.BR', name: 'KBC Group', fullName: 'KBC Group NV', sector: 'banks' },
            { symbol: 'UCB.BR', name: 'UCB', fullName: 'UCB SA', sector: 'healthcare' },
            { symbol: 'SOF.BR', name: 'Sofina', fullName: 'Sofina SA', sector: 'financial_services' },
            { symbol: 'AGS.BR', name: 'Ageas', fullName: 'Ageas SA/NV', sector: 'insurance' },
            { symbol: 'COLR.BR', name: 'Colruyt Group', fullName: 'Colruyt Group SA', sector: 'retail' },
            { symbol: 'UMI.BR', name: 'Umicore', fullName: 'Umicore SA', sector: 'basic_materials' },
            { symbol: 'PROX.BR', name: 'Proximus', fullName: 'Proximus SA', sector: 'telecommunications' }
        ]
    },

    // NOUVELLES BOURSES EUROPÉENNES
    
    // Royaume-Uni - FTSE 100
    'GB': {
        country: 'Royaume-Uni',
        flag: '🇬🇧',
        index: 'FTSE 100',
        currency: 'GBP',
        suffix: '.L',
        benchmark: '^FTSE',
        companies: [
            { symbol: 'SHEL.L', name: 'Shell', fullName: 'Shell plc', sector: 'oil_gas' },
            { symbol: 'AZN.L', name: 'AstraZeneca', fullName: 'AstraZeneca plc', sector: 'healthcare' },
            { symbol: 'LSEG.L', name: 'London Stock Exchange Group', fullName: 'London Stock Exchange Group plc', sector: 'financial_services' },
            { symbol: 'UU.L', name: 'Unilever', fullName: 'Unilever plc', sector: 'food_beverage' },
            { symbol: 'HSBA.L', name: 'HSBC Holdings', fullName: 'HSBC Holdings plc', sector: 'banks' },
            { symbol: 'BP.L', name: 'BP', fullName: 'BP plc', sector: 'oil_gas' },
            { symbol: 'GSK.L', name: 'GSK', fullName: 'GSK plc', sector: 'healthcare' },
            { symbol: 'VODJ.L', name: 'Vodafone Group', fullName: 'Vodafone Group plc', sector: 'telecommunications' },
            { symbol: 'BARC.L', name: 'Barclays', fullName: 'Barclays plc', sector: 'banks' },
            { symbol: 'LLOY.L', name: 'Lloyds Banking Group', fullName: 'Lloyds Banking Group plc', sector: 'banks' },
            { symbol: 'TSCO.L', name: 'Tesco', fullName: 'Tesco plc', sector: 'retail' },
            { symbol: 'RIO.L', name: 'Rio Tinto', fullName: 'Rio Tinto plc', sector: 'basic_materials' },
            { symbol: 'BT-A.L', name: 'BT Group', fullName: 'BT Group plc', sector: 'telecommunications' },
            { symbol: 'GLEN.L', name: 'Glencore', fullName: 'Glencore plc', sector: 'basic_materials' },
            { symbol: 'AAL.L', name: 'Anglo American', fullName: 'Anglo American plc', sector: 'basic_materials' },
            { symbol: 'PSON.L', name: 'Pearson', fullName: 'Pearson plc', sector: 'media' },
            { symbol: 'RR.L', name: 'Rolls-Royce Holdings', fullName: 'Rolls-Royce Holdings plc', sector: 'industrial_goods' },
            { symbol: 'IAG.L', name: 'International Airlines Group', fullName: 'International Airlines Group SA', sector: 'travel_leisure' },
            { symbol: 'AVV.L', name: 'Aviva', fullName: 'Aviva plc', sector: 'insurance' },
            { symbol: 'PRU.L', name: 'Prudential', fullName: 'Prudential plc', sector: 'insurance' }
        ]
    },

    // Suisse - SMI 20
    'CH': {
        country: 'Suisse',
        flag: '🇨🇭',
        index: 'SMI 20',
        currency: 'CHF',
        suffix: '.SW',
        benchmark: '^SSMI',
        companies: [
            { symbol: 'NESN.SW', name: 'Nestlé', fullName: 'Nestlé SA', sector: 'food_beverage' },
            { symbol: 'ROG.SW', name: 'Roche Holding', fullName: 'Roche Holding AG', sector: 'healthcare' },
            { symbol: 'NOVN.SW', name: 'Novartis', fullName: 'Novartis AG', sector: 'healthcare' },
            { symbol: 'UBS.SW', name: 'UBS Group', fullName: 'UBS Group AG', sector: 'banks' },
            { symbol: 'ABBN.SW', name: 'ABB', fullName: 'ABB Ltd', sector: 'industrial_goods' },
            { symbol: 'ZURN.SW', name: 'Zurich Insurance Group', fullName: 'Zurich Insurance Group AG', sector: 'insurance' },
            { symbol: 'LONN.SW', name: 'Lonza Group', fullName: 'Lonza Group AG', sector: 'healthcare' },
            { symbol: 'CFR.SW', name: 'Compagnie Financière Richemont', fullName: 'Compagnie Financière Richemont SA', sector: 'personal_household' },
            { symbol: 'GIVN.SW', name: 'Givaudan', fullName: 'Givaudan SA', sector: 'chemicals' },
            { symbol: 'SIKA.SW', name: 'Sika', fullName: 'Sika AG', sector: 'construction_materials' },
            { symbol: 'GEBN.SW', name: 'Geberit', fullName: 'Geberit AG', sector: 'construction_materials' },
            { symbol: 'SLHN.SW', name: 'Swiss Life Holding', fullName: 'Swiss Life Holding AG', sector: 'insurance' },
            { symbol: 'PGHN.SW', name: 'Partners Group Holding', fullName: 'Partners Group Holding AG', sector: 'financial_services' },
            { symbol: 'ALC.SW', name: 'Alcon', fullName: 'Alcon Inc', sector: 'healthcare' },
            { symbol: 'STMN.SW', name: 'Straumann Holding', fullName: 'Straumann Holding AG', sector: 'healthcare' },
            { symbol: 'KNIN.SW', name: 'Kuehne + Nagel International', fullName: 'Kuehne + Nagel International AG', sector: 'industrial_goods' }
        ]
    },

    // Suède - OMX Stockholm 30
    'SE': {
        country: 'Suède',
        flag: '🇸🇪', 
        index: 'OMX Stockholm 30',
        currency: 'SEK',
        suffix: '.ST',
        benchmark: '^OMX',
        companies: [
            { symbol: 'VOLV-B.ST', name: 'Volvo', fullName: 'AB Volvo', sector: 'automobiles' },
            { symbol: 'ERIC-B.ST', name: 'Ericsson', fullName: 'Telefonaktiebolaget LM Ericsson', sector: 'technology' },
            { symbol: 'HM-B.ST', name: 'H&M', fullName: 'H & M Hennes & Mauritz AB', sector: 'retail' },
            { symbol: 'ALFA.ST', name: 'Alfa Laval', fullName: 'Alfa Laval AB', sector: 'industrial_goods' },
            { symbol: 'SEB-A.ST', name: 'SEB', fullName: 'Skandinaviska Enskilda Banken AB', sector: 'banks' },
            { symbol: 'SWED-A.ST', name: 'Swedbank', fullName: 'Swedbank AB', sector: 'banks' },
            { symbol: 'SKF-B.ST', name: 'SKF', fullName: 'SKF AB', sector: 'industrial_goods' },
            { symbol: 'SAND.ST', name: 'Sandvik', fullName: 'Sandvik AB', sector: 'industrial_goods' },
            { symbol: 'ATCO-A.ST', name: 'Atlas Copco A', fullName: 'Atlas Copco AB', sector: 'industrial_goods' },
            { symbol: 'TELIA.ST', name: 'Telia Company', fullName: 'Telia Company AB', sector: 'telecommunications' },
            { symbol: 'ESSITY-B.ST', name: 'Essity', fullName: 'Essity AB', sector: 'personal_household' },
            { symbol: 'INVE-B.ST', name: 'Investor B', fullName: 'Investor AB', sector: 'financial_services' },
            { symbol: 'KINV-B.ST', name: 'Kinnevik B', fullName: 'Kinnevik AB', sector: 'financial_services' },
            { symbol: 'SHB-A.ST', name: 'Svenska Handelsbanken A', fullName: 'Svenska Handelsbanken AB', sector: 'banks' },
            { symbol: 'HEXA-B.ST', name: 'Hexagon B', fullName: 'Hexagon AB', sector: 'technology' }
        ]
    },

    // Norvège - OBX 25  
    'NO': {
        country: 'Norvège',
        flag: '🇳🇴',
        index: 'OBX 25',
        currency: 'NOK', 
        suffix: '.OL',
        benchmark: '^OSEAX',
        companies: [
            { symbol: 'EQNR.OL', name: 'Equinor', fullName: 'Equinor ASA', sector: 'oil_gas' },
            { symbol: 'NHY.OL', name: 'Norsk Hydro', fullName: 'Norsk Hydro ASA', sector: 'basic_materials' },
            { symbol: 'TEL.OL', name: 'Telenor', fullName: 'Telenor ASA', sector: 'telecommunications' },
            { symbol: 'DNB.OL', name: 'DNB', fullName: 'DNB Bank ASA', sector: 'banks' },
            { symbol: 'MOWI.OL', name: 'Mowi', fullName: 'Mowi ASA', sector: 'food_beverage' },
            { symbol: 'YAR.OL', name: 'Yara International', fullName: 'Yara International ASA', sector: 'chemicals' },
            { symbol: 'ORK.OL', name: 'Orkla', fullName: 'Orkla ASA', sector: 'food_beverage' },
            { symbol: 'SALM.OL', name: 'Salmar', fullName: 'SalMar ASA', sector: 'food_beverage' },
            { symbol: 'REC.OL', name: 'REC Silicon', fullName: 'REC Silicon ASA', sector: 'technology' },
            { symbol: 'AKRBP.OL', name: 'Aker BP', fullName: 'Aker BP ASA', sector: 'oil_gas' },
            { symbol: 'SUBC.OL', name: 'Subsea 7', fullName: 'Subsea 7 SA', sector: 'energy' },
            { symbol: 'KAHOT.OL', name: 'Kahoot!', fullName: 'Kahoot! AS', sector: 'technology' },
            { symbol: 'AUTO.OL', name: 'AutoStore Holdings', fullName: 'AutoStore Holdings Ltd', sector: 'technology' }
        ]
    },

    // Finlande - OMX Helsinki 25
    'FI': {
        country: 'Finlande', 
        flag: '🇫🇮',
        index: 'OMX Helsinki 25',
        currency: 'EUR',
        suffix: '.HE',
        benchmark: '^OMXH25',
        companies: [
            { symbol: 'NOKIA.HE', name: 'Nokia', fullName: 'Nokia Corporation', sector: 'technology' },
            { symbol: 'KNEBV.HE', name: 'Kone', fullName: 'KONE Corporation', sector: 'industrial_goods' },
            { symbol: 'NESTE.HE', name: 'Neste', fullName: 'Neste Corporation', sector: 'oil_gas' },
            { symbol: 'UPM.HE', name: 'UPM-Kymmene', fullName: 'UPM-Kymmene Corporation', sector: 'basic_materials' },
            { symbol: 'STERV.HE', name: 'Stora Enso', fullName: 'Stora Enso Oyj', sector: 'basic_materials' },
            { symbol: 'SAMPO.HE', name: 'Sampo', fullName: 'Sampo Oyj', sector: 'insurance' },
            { symbol: 'FORTUM.HE', name: 'Fortum', fullName: 'Fortum Corporation', sector: 'utilities' },
            { symbol: 'METSO.HE', name: 'Metso Outotec', fullName: 'Metso Outotec Corporation', sector: 'industrial_goods' },
            { symbol: 'ELISA.HE', name: 'Elisa', fullName: 'Elisa Corporation', sector: 'telecommunications' },
            { symbol: 'KESKO.HE', name: 'Kesko', fullName: 'Kesko Corporation', sector: 'retail' },
            { symbol: 'WRTBV.HE', name: 'Wärtsilä', fullName: 'Wärtsilä Corporation', sector: 'industrial_goods' },
            { symbol: 'ORNBV.HE', name: 'Orion', fullName: 'Orion Corporation', sector: 'healthcare' }
        ]
    },

    // Danemark - OMX Copenhagen 20
    'DK': {
        country: 'Danemark',
        flag: '🇩🇰',
        index: 'OMX Copenhagen 20', 
        currency: 'DKK',
        suffix: '.CO',
        benchmark: '^OMXC20',
        companies: [
            { symbol: 'NOVO-B.CO', name: 'Novo Nordisk', fullName: 'Novo Nordisk A/S', sector: 'healthcare' },
            { symbol: 'MAERSK-B.CO', name: 'A.P. Møller-Mærsk', fullName: 'A.P. Møller - Mærsk A/S', sector: 'industrial_goods' },
            { symbol: 'ORSTED.CO', name: 'Ørsted', fullName: 'Ørsted A/S', sector: 'utilities' },
            { symbol: 'CARL-B.CO', name: 'Carlsberg', fullName: 'Carlsberg A/S', sector: 'food_beverage' },
            { symbol: 'DANSKE.CO', name: 'Danske Bank', fullName: 'Danske Bank A/S', sector: 'banks' },
            { symbol: 'PANDORA.CO', name: 'Pandora', fullName: 'Pandora A/S', sector: 'personal_household' },
            { symbol: 'NOVOZYMES-B.CO', name: 'Novozymes', fullName: 'Novozymes A/S', sector: 'chemicals' },
            { symbol: 'DSV.CO', name: 'DSV', fullName: 'DSV A/S', sector: 'industrial_goods' },
            { symbol: 'TRYG.CO', name: 'Tryg', fullName: 'Tryg A/S', sector: 'insurance' },
            { symbol: 'COLOPLAST-B.CO', name: 'Coloplast', fullName: 'Coloplast A/S', sector: 'healthcare' },
            { symbol: 'DEMANT.CO', name: 'Demant', fullName: 'Demant A/S', sector: 'healthcare' },
            { symbol: 'NZYM-B.CO', name: 'Novozymes B', fullName: 'Novozymes A/S', sector: 'chemicals' }
        ]
    },

    // Autriche - ATX 20
    'AT': {
        country: 'Autriche',
        flag: '🇦🇹',
        index: 'ATX 20',
        currency: 'EUR',
        suffix: '.VI', 
        benchmark: '^ATX',
        companies: [
            { symbol: 'VOEST.VI', name: 'voestalpine', fullName: 'voestalpine AG', sector: 'basic_materials' },
            { symbol: 'EBS.VI', name: 'Erste Group Bank', fullName: 'Erste Group Bank AG', sector: 'banks' },
            { symbol: 'OMV.VI', name: 'OMV', fullName: 'OMV AG', sector: 'oil_gas' },
            { symbol: 'AMS.VI', name: 'ams-OSRAM', fullName: 'ams-OSRAM AG', sector: 'technology' },
            { symbol: 'ANDR.VI', name: 'Andritz', fullName: 'Andritz AG', sector: 'industrial_goods' },
            { symbol: 'RBIV.VI', name: 'Raiffeisen Bank International', fullName: 'Raiffeisen Bank International AG', sector: 'banks' },
            { symbol: 'POST.VI', name: 'Österreichische Post', fullName: 'Österreichische Post AG', sector: 'industrial_goods' },
            { symbol: 'VIG.VI', name: 'Vienna Insurance Group', fullName: 'Vienna Insurance Group AG', sector: 'insurance' },
            { symbol: 'WIE.VI', name: 'Wienerberger', fullName: 'Wienerberger AG', sector: 'construction_materials' },
            { symbol: 'VER.VI', name: 'Verbund', fullName: 'Verbund AG', sector: 'utilities' }
        ]
    },

    // Portugal - PSI 20
    'PT': {
        country: 'Portugal',
        flag: '🇵🇹',
        index: 'PSI 20',
        currency: 'EUR',
        suffix: '.LS',
        benchmark: '^PSI20',
        companies: [
            { symbol: 'EDP.LS', name: 'EDP - Energias de Portugal', fullName: 'EDP - Energias de Portugal SA', sector: 'utilities' },
            { symbol: 'GALP.LS', name: 'Galp Energia', fullName: 'Galp Energia SGPS SA', sector: 'oil_gas' },
            { symbol: 'BCP.LS', name: 'Banco Comercial Português', fullName: 'Banco Comercial Português SA', sector: 'banks' },
            { symbol: 'EGL.LS', name: 'EGL - Enel Green Power', fullName: 'Enel Green Power SpA', sector: 'utilities' },
            { symbol: 'NOS.LS', name: 'NOS', fullName: 'NOS SGPS SA', sector: 'telecommunications' },
            { symbol: 'SEM.LS', name: 'Semapa', fullName: 'Semapa SGPS SA', sector: 'basic_materials' },
            { symbol: 'COR.LS', name: 'Corticeira Amorim', fullName: 'Corticeira Amorim SGPS SA', sector: 'basic_materials' },
            { symbol: 'JMT.LS', name: 'Jerónimo Martins', fullName: 'Jerónimo Martins SGPS SA', sector: 'retail' },
            { symbol: 'REN.LS', name: 'REN - Redes Energéticas Nacionais', fullName: 'REN - Redes Energéticas Nacionais SGPS SA', sector: 'utilities' }
        ]
    },

    // Pologne - WIG 20
    'PL': {
        country: 'Pologne', 
        flag: '🇵🇱',
        index: 'WIG 20',
        currency: 'PLN',
        suffix: '.WA',
        benchmark: '^WIG20',
        companies: [
            { symbol: 'PKO.WA', name: 'PKO Bank Polski', fullName: 'Powszechna Kasa Oszczędności Bank Polski SA', sector: 'banks' },
            { symbol: 'PEO.WA', name: 'Bank Pekao', fullName: 'Bank Pekao SA', sector: 'banks' },
            { symbol: 'PKN.WA', name: 'PKN Orlen', fullName: 'Polski Koncern Naftowy Orlen SA', sector: 'oil_gas' },
            { symbol: 'LPP.WA', name: 'LPP', fullName: 'LPP SA', sector: 'retail' },
            { symbol: 'PGE.WA', name: 'PGE Polska Grupa Energetyczna', fullName: 'Polska Grupa Energetyczna SA', sector: 'utilities' },
            { symbol: 'PZU.WA', name: 'Powszechny Zakład Ubezpieczeń', fullName: 'Powszechny Zakład Ubezpieczeń SA', sector: 'insurance' },
            { symbol: 'CDR.WA', name: 'CD Projekt', fullName: 'CD Projekt SA', sector: 'technology' },
            { symbol: 'JSW.WA', name: 'Jastrzębska Spółka Węglowa', fullName: 'Jastrzębska Spółka Węglowa SA', sector: 'basic_materials' },
            { symbol: 'LTS.WA', name: 'Grupa Lotos', fullName: 'Grupa Lotos SA', sector: 'oil_gas' },
            { symbol: 'MIL.WA', name: 'Millennium Bank', fullName: 'Bank Millennium SA', sector: 'banks' }
        ]
    }
};



// Fonction pour obtenir toutes les bourses européennes
function getAllEuropeanMarkets() {
    return Object.keys(EUROPEAN_STOCKS_COMPLETE).map(countryCode => ({
        countryCode,
        ...EUROPEAN_STOCKS_COMPLETE[countryCode],
        totalCompanies: EUROPEAN_STOCKS_COMPLETE[countryCode].companies.length
    }));
}

// Fonction pour obtenir benchmark par pays
function getNationalBenchmark(countryCode) {
    return EUROPEAN_STOCKS_COMPLETE[countryCode]?.benchmark || null;
}

// Fonction pour obtenir benchmark sectoriel STOXX
function getSectorBenchmark(sectorName) {
    // Mapping des secteurs locaux vers secteurs STOXX
    const sectorMapping = {
        'Technologie': 'Technology',
        'Pharmacie': 'Healthcare', 
        'Santé': 'Healthcare',
        'Banque': 'Financials',
        'Finance': 'Financials',
        'Énergie': 'Energy',
        'Industrie': 'Industrials',
        'Aéronautique': 'Industrials',
        'Automobile': 'Consumer_Discretionary',
        'Luxe': 'Consumer_Discretionary',
        'Textile': 'Consumer_Discretionary',
        'Distribution': 'Consumer_Discretionary',
        'Agroalimentaire': 'Consumer_Staples',
        'Boissons': 'Consumer_Staples',
        'Chimie': 'Materials',
        'Métallurgie': 'Materials',
        'Construction': 'Materials',
        'Services aux collectivités': 'Utilities',
        'Immobilier': 'Real_Estate',
        'Télécommunications': 'Telecommunications',
        'Médias': 'Telecommunications',
        'Assurance': 'Financials',
        'Transport': 'Industrials',
        'Services': 'Industrials'
    };
    
    const stoxxSector = sectorMapping[sectorName];
    return stoxxSector && window.STOXX_SECTORS ? window.STOXX_SECTORS[stoxxSector]?.benchmark : null;
}

// Fonction pour détecter devise étendue
function detectCurrencyComplete(symbol) {
    if (symbol.includes('.PA') || symbol.includes('.MC') || symbol.includes('.MI') || 
        symbol.includes('.DE') || symbol.includes('.AS') || symbol.includes('.BR') ||
        symbol.includes('.HE') || symbol.includes('.VI') || symbol.includes('.LS')) {
        return 'EUR';
    }
    if (symbol.includes('.L')) return 'GBP';
    if (symbol.includes('.SW')) return 'CHF';
    if (symbol.includes('.ST')) return 'SEK';
    if (symbol.includes('.OL')) return 'NOK';
    if (symbol.includes('.CO')) return 'DKK';
    if (symbol.includes('.WA')) return 'PLN';
    return 'USD';
}

// Export global
window.EUROPEAN_STOCKS_COMPLETE = EUROPEAN_STOCKS_COMPLETE;
window.getAllEuropeanMarkets = getAllEuropeanMarkets;
window.getNationalBenchmark = getNationalBenchmark;
window.getSectorBenchmark = getSectorBenchmark;
window.detectCurrencyComplete = detectCurrencyComplete;