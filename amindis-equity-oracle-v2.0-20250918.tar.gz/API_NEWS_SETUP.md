# Configuration des Actualités Financières en Temps Réel

## 🔑 Obtenir une Clé API Alpha Vantage (GRATUIT)

Pour avoir accès aux **vraies actualités financières** au lieu des résultats de recherche, vous devez obtenir une clé API gratuite :

### Étapes pour obtenir votre clé API :

1. **Inscription gratuite** : https://www.alphavantage.co/support/#api-key
2. **Remplir le formulaire** avec votre email
3. **Récupérer votre clé API** (format : `XXXXXXXXXXXXXXXXX`)

### Limites du plan gratuit Alpha Vantage :
- ✅ **25 requêtes par jour** 
- ✅ **5 requêtes par minute**
- ✅ Accès à l'API News & Sentiment
- ✅ Actualités en temps réel
- ✅ Analyse de sentiment

## 🛠️ Configuration dans l'Application

### Option 1 : Développement Local
```bash
# Éditez le fichier .dev.vars
echo "ALPHA_VANTAGE_API_KEY=VOTRE_VRAIE_CLE_API" > .dev.vars
```

### Option 2 : Production Cloudflare
```bash
# Utilisez wrangler pour définir la variable de production
npx wrangler pages secret put ALPHA_VANTAGE_API_KEY

# Puis entrez votre clé API quand demandé
```

## 📊 Différences avec/sans Clé API

### ❌ Sans Clé API (Actuel)
- Liens vers pages de recherche des sites financiers
- Pas d'actualités spécifiques
- Titres génériques

### ✅ Avec Clé API Alpha Vantage
- **Vraies actualités** provenant de sources financières réputées
- **Titres d'articles réels** récents (dernières 24-48h)
- **URLs directes** vers les articles originaux  
- **Analyse de sentiment** (positif/négatif/neutre)
- **Score de pertinence** pour chaque article

## 🔗 Sources d'Actualités Couvertes

Alpha Vantage agrège des actualités de :
- Reuters
- MarketWatch  
- Seeking Alpha
- Yahoo Finance
- Bloomberg
- CNBC
- Et 100+ autres sources financières

## 🚀 Test Rapide

Une fois votre clé configurée, testez avec :
```bash
curl "http://localhost:3000/api/news/AAPL"
```

Vous devriez voir de vraies actualités avec des titres comme :
```json
{
  "title": "Apple Reports Strong Q3 Earnings Beat Expectations",
  "summary": "Apple Inc. reported quarterly earnings that exceeded Wall Street expectations...",
  "source": "MarketWatch",
  "url": "https://www.marketwatch.com/story/apple-earnings-q3-2024",
  "sentiment": "Bullish",
  "relevanceScore": 0.95
}
```

## ⚠️ Important

- **Ne commitez jamais** votre clé API dans Git
- Le fichier `.dev.vars` est dans `.gitignore` 
- Pour la production, utilisez toujours `wrangler pages secret put`