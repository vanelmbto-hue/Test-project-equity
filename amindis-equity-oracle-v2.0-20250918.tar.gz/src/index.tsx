import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'

const app = new Hono()

// Enable CORS for frontend-backend communication
app.use('/api/*', cors())

// Serve static files from public directory
app.use('/static/*', serveStatic({ root: './public' }))

// Helper function to fetch stock data from Yahoo Finance
async function fetchYahooFinanceData(symbol: string, period: string = '1y'): Promise<any> {
  try {
    // Yahoo Finance API endpoint (using their historical data endpoint)
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?period1=0&period2=9999999999&interval=1d&includePrePost=true&events=div%2Csplit`
    
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    
    if (!data.chart || !data.chart.result || data.chart.result.length === 0) {
      throw new Error('No data found for this symbol')
    }

    const result = data.chart.result[0]
    const timestamps = result.timestamp
    const quotes = result.indicators.quote[0]
    
    // Convert to array of daily prices
    const historicalData = timestamps.map((timestamp: number, index: number) => ({
      date: new Date(timestamp * 1000).toISOString().split('T')[0],
      open: quotes.open[index]?.toFixed(2) || 'N/A',
      high: quotes.high[index]?.toFixed(2) || 'N/A',
      low: quotes.low[index]?.toFixed(2) || 'N/A',
      close: quotes.close[index]?.toFixed(2) || 'N/A',
      volume: quotes.volume[index] || 'N/A'
    })).filter(item => item.close !== 'N/A').reverse() // Most recent first

    return {
      symbol: result.meta.symbol,
      companyName: result.meta.symbol, // Yahoo doesn't always provide company name
      currency: result.meta.currency,
      exchangeName: result.meta.exchangeName,
      data: historicalData
    }
  } catch (error) {
    console.error('Error fetching Yahoo Finance data:', error)
    throw error
  }
}

// Helper function to search for company symbols
async function searchCompanySymbol(query: string): Promise<any> {
  try {
    // Yahoo Finance search API
    const url = `https://query2.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(query)}&newsCount=0&listsCount=0`
    
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    
    return data.quotes?.map((quote: any) => ({
      symbol: quote.symbol,
      shortname: quote.shortname || quote.longname || quote.symbol,
      longname: quote.longname || quote.shortname || quote.symbol,
      exchDisp: quote.exchDisp || 'Unknown',
      typeDisp: quote.typeDisp || 'Stock'
    })) || []
  } catch (error) {
    console.error('Error searching symbols:', error)
    return []
  }
}

// API Routes

// Search for company symbols
app.get('/api/search/:query', async (c) => {
  try {
    const query = c.req.param('query')
    
    if (!query || query.length < 2) {
      return c.json({ error: 'Query must be at least 2 characters long' }, 400)
    }

    const results = await searchCompanySymbol(query)
    
    return c.json({
      success: true,
      query,
      results: results.slice(0, 10) // Limit to 10 results
    })
  } catch (error) {
    return c.json({ 
      error: 'Failed to search companies', 
      details: error instanceof Error ? error.message : 'Unknown error' 
    }, 500)
  }
})

// Get historical stock data
app.get('/api/stock/:symbol', async (c) => {
  try {
    const symbol = c.req.param('symbol').toUpperCase()
    
    if (!symbol) {
      return c.json({ error: 'Symbol parameter is required' }, 400)
    }

    const stockData = await fetchYahooFinanceData(symbol)
    
    return c.json({
      success: true,
      symbol,
      totalDays: stockData.data.length,
      ...stockData
    })
  } catch (error) {
    return c.json({ 
      error: 'Failed to fetch stock data', 
      details: error instanceof Error ? error.message : 'Unknown error' 
    }, 500)
  }
})

// Get stock data with date range
app.get('/api/stock/:symbol/range', async (c) => {
  try {
    const symbol = c.req.param('symbol').toUpperCase()
    const startDate = c.req.query('start')
    const endDate = c.req.query('end')
    
    if (!symbol) {
      return c.json({ error: 'Symbol parameter is required' }, 400)
    }

    const stockData = await fetchYahooFinanceData(symbol)
    
    let filteredData = stockData.data
    
    if (startDate) {
      filteredData = filteredData.filter((item: any) => item.date >= startDate)
    }
    
    if (endDate) {
      filteredData = filteredData.filter((item: any) => item.date <= endDate)
    }
    
    return c.json({
      success: true,
      symbol,
      startDate,
      endDate,
      totalDays: filteredData.length,
      ...stockData,
      data: filteredData
    })
  } catch (error) {
    return c.json({ 
      error: 'Failed to fetch stock data', 
      details: error instanceof Error ? error.message : 'Unknown error' 
    }, 500)
  }
})

// API status endpoint
app.get('/api/status', (c) => {
  return c.json({
    success: true,
    message: 'Financial Data API is running',
    endpoints: {
      search: '/api/search/:query',
      stock: '/api/stock/:symbol',
      stockRange: '/api/stock/:symbol/range?start=YYYY-MM-DD&end=YYYY-MM-DD'
    },
    version: '1.0.0'
  })
})

// Main page
app.get('/', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Amindis Equity Oracle</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns@2.0.0/dist/chartjs-adapter-date-fns.bundle.min.js"></script>
        <link href="/static/style.css" rel="stylesheet">
        <script src="/static/european-stocks.js"></script>
        <script src="/static/european-stocks-extended.js"></script>
        <script src="/static/european-stocks-complete.js"></script>
        <script src="/static/financial-calculations-academic.js"></script>
        <script src="/static/financial-analytics.js"></script>
        <script src="/static/market-data.js"></script>
    </head>
    <body class="financial-theme">
        <div class="min-h-screen">
            <!-- Header -->
            <header class="bg-white shadow-lg border-b border-gray-200">
                <div class="max-w-7xl mx-auto px-4 py-6">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center space-x-3">
                            <i class="fas fa-chart-line text-3xl text-blue-600"></i>
                            <h1 class="text-3xl font-bold text-gray-800">Amindis Equity Oracle</h1>
                        </div>
                        <div class="text-sm text-gray-500">
                            <i class="fas fa-database mr-1"></i>
                            Données historiques en temps réel
                        </div>
                    </div>
                </div>
            </header>

            <!-- Navigation Buttons - Visible on all pages -->
            <nav class="bg-gray-50 border-b border-gray-200 py-4">
                <div class="max-w-7xl mx-auto px-4">
                    <div class="flex justify-center">
                        <div class="bg-white rounded-lg shadow-lg p-1 inline-flex space-x-1">
                            <button id="navHome" onclick="showHome()" class="px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors">
                                <i class="fas fa-home mr-2"></i>Accueil
                            </button>
                            <button id="navStockAnalyst" onclick="showStockAnalyst()" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-blue-100 hover:text-blue-700 transition-colors">
                                <i class="fas fa-chart-line mr-2"></i>Stock Analyst
                            </button>
                            <button class="px-4 py-2 bg-gray-100 text-gray-500 rounded-lg font-medium cursor-not-allowed" disabled>
                                <i class="fas fa-cogs mr-2"></i>En Développement
                            </button>
                            <button class="px-4 py-2 bg-gray-100 text-gray-500 rounded-lg font-medium cursor-not-allowed" disabled>
                                <i class="fas fa-tools mr-2"></i>En Développement
                            </button>
                        </div>
                    </div>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="w-full px-2 py-8">
                <!-- Dashboard Section (Page d'accueil) -->
                <div id="dashboardSection" class="space-y-8">
                    <!-- Barre de recherche principale sur l'accueil -->
                    <div class="bg-white rounded-lg shadow-lg p-6">
                        <div class="flex items-center justify-between mb-4">
                            <h2 class="text-xl font-semibold text-gray-800">
                                <i class="fas fa-search mr-3"></i>
                                Recherche Rapide d'Actions
                            </h2>
                            <button id="showAdvancedSearch" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                                <i class="fas fa-cog mr-2"></i>Recherche Avancée
                            </button>
                        </div>
                        
                        <!-- Barre de recherche simple -->
                        <div class="flex space-x-4 mb-4">
                            <div class="flex-1 relative">
                                <input 
                                    type="text" 
                                    id="quickSearchInput" 
                                    placeholder="Recherche rapide : AAPL, RNO.PA, SAP.DE..."
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                >
                                <div id="quickSearchSuggestions" class="absolute z-20 w-full bg-white border border-gray-300 rounded-lg mt-1 hidden shadow-lg max-h-60 overflow-y-auto">
                                </div>
                            </div>
                            <button 
                                id="quickSearchBtn" 
                                class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
                            >
                                <i class="fas fa-search mr-2"></i>
                                Analyser
                            </button>
                        </div>

                        <!-- Sélecteurs rapides d'indices -->
                        <div class="flex flex-wrap gap-2">
                            <button id="quickCAC40" class="px-3 py-2 bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 transition-colors text-sm">
                                <i class="fas fa-flag mr-1"></i>🇫🇷 CAC 40
                            </button>
                            <button id="quickDAX30" class="px-3 py-2 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 transition-colors text-sm">
                                <i class="fas fa-flag mr-1"></i>🇩🇪 DAX 30
                            </button>
                            <button id="quickIBEX35" class="px-3 py-2 bg-red-100 text-red-800 rounded-lg hover:bg-red-200 transition-colors text-sm">
                                <i class="fas fa-flag mr-1"></i>🇪🇸 IBEX 35
                            </button>
                            <button id="quickFTSE100" class="px-3 py-2 bg-purple-100 text-purple-800 rounded-lg hover:bg-purple-200 transition-colors text-sm">
                                <i class="fas fa-flag mr-1"></i>🇬🇧 FTSE 100
                            </button>
                            <button id="quickAEX25" class="px-3 py-2 bg-orange-100 text-orange-800 rounded-lg hover:bg-orange-200 transition-colors text-sm">
                                <i class="fas fa-flag mr-1"></i>🇳🇱 AEX 25
                            </button>
                        </div>
                    </div>
                    <!-- Indices Boursiers Mondiaux -->
                    <div class="bg-white rounded-lg shadow-lg p-6">
                        <div class="flex items-center justify-between mb-6">
                            <h2 class="text-2xl font-bold text-gray-800">
                                <i class="fas fa-globe mr-3"></i>
                                Indices Boursiers Mondiaux
                            </h2>
                            <div class="text-sm text-gray-500">
                                <i class="fas fa-sync-alt mr-1"></i>
                                Temps réel
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                            <!-- États-Unis -->
                            <div class="bg-blue-50 rounded-lg p-4">
                                <h3 class="text-lg font-semibold text-blue-800 mb-3">
                                    <i class="fas fa-flag-usa mr-2"></i>États-Unis
                                </h3>
                                <div id="usIndices" class="space-y-2">
                                    <!-- Will be populated by JavaScript -->
                                </div>
                            </div>

                            <!-- Europe -->
                            <div class="bg-green-50 rounded-lg p-4">
                                <h3 class="text-lg font-semibold text-green-800 mb-3">
                                    <i class="fas fa-flag mr-2"></i>Europe
                                </h3>
                                <div id="euIndices" class="space-y-2">
                                    <!-- Will be populated by JavaScript -->
                                </div>
                            </div>

                            <!-- Asie -->
                            <div class="bg-red-50 rounded-lg p-4">
                                <h3 class="text-lg font-semibold text-red-800 mb-3">
                                    <i class="fas fa-torii-gate mr-2"></i>Asie
                                </h3>
                                <div id="asiaIndices" class="space-y-2">
                                    <!-- Will be populated by JavaScript -->
                                </div>
                            </div>
                        </div>

                        <!-- Graphique des indices principaux -->
                        <div class="border-t pt-6">
                            <h4 class="text-lg font-semibold text-gray-800 mb-4">
                                <i class="fas fa-chart-line mr-2"></i>
                                Performance des Indices Principaux
                            </h4>
                            <div class="relative" style="height: 300px;">
                                <canvas id="indicesChart"></canvas>
                            </div>
                        </div>
                    </div>

                    <!-- Matrice Pays / Secteurs Européens -->
                    <div class="bg-white rounded-lg shadow-lg p-6">
                        <h2 class="text-2xl font-bold text-gray-800 mb-6">
                            <i class="fas fa-th-large mr-3"></i>
                            Matrice Européenne Pays / Secteurs
                        </h2>
                        
                        <!-- Sélecteurs de filtres -->
                        <div class="flex flex-wrap gap-2 mb-6">
                            <button id="matrixShowAll" class="matrix-filter-btn px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-sm font-medium">
                                <i class="fas fa-globe mr-1"></i>Toute l'Europe (15 marchés)
                            </button>
                            <button id="matrixShowFrance" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                🇫🇷 France
                            </button>
                            <button id="matrixShowGermany" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                🇩🇪 Allemagne
                            </button>
                            <button id="matrixShowSpain" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                🇪🇸 Espagne
                            </button>
                            <button id="matrixShowItaly" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                🇮🇹 Italie
                            </button>
                            <button id="matrixShowNetherlands" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                🇳🇱 Pays-Bas
                            </button>
                            <button id="matrixShowBelgium" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                🇧🇪 Belgique
                            </button>
                            <button id="matrixShowUK" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                🇬🇧 Royaume-Uni
                            </button>
                            <button id="matrixShowSwitzerland" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                🇨🇭 Suisse
                            </button>
                            <button id="matrixShowSweden" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                🇸🇪 Suède
                            </button>
                            <button id="matrixShowNorway" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                🇳🇴 Norvège
                            </button>
                            <button id="matrixShowFinland" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                🇫🇮 Finlande
                            </button>
                            <button id="matrixShowDenmark" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                🇩🇰 Danemark
                            </button>
                            <button id="matrixShowAustria" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                🇦🇹 Autriche
                            </button>
                            <button id="matrixShowPoland" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                🇵🇱 Pologne
                            </button>
                        </div>

                        <!-- Tableau matriciel -->
                        <div class="overflow-x-auto">
                            <div class="text-sm text-gray-600 mb-3">
                                <i class="fas fa-info-circle mr-1"></i>
                                Cliquez sur une entreprise pour l'analyser
                            </div>
                            <table id="sectorCountryMatrix" class="min-w-full border-collapse border border-gray-300">
                                <thead>
                                    <tr class="bg-gray-50">
                                        <th class="border border-gray-300 px-4 py-3 text-left font-semibold text-gray-800">
                                            <i class="fas fa-industry mr-2"></i>Secteur STOXX
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            🇫🇷<br><span class="text-xs">France</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            🇩🇪<br><span class="text-xs">Allemagne</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            🇪🇸<br><span class="text-xs">Espagne</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            🇮🇹<br><span class="text-xs">Italie</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            🇳🇱<br><span class="text-xs">Pays-Bas</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            🇧🇪<br><span class="text-xs">Belgique</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            🇬🇧<br><span class="text-xs">Royaume-Uni</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            🇨🇭<br><span class="text-xs">Suisse</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            🇸🇪<br><span class="text-xs">Suède</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            🇳🇴<br><span class="text-xs">Norvège</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            🇫🇮<br><span class="text-xs">Finlande</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            🇩🇰<br><span class="text-xs">Danemark</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            🇦🇹<br><span class="text-xs">Autriche</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            🇵🇱<br><span class="text-xs">Pologne</span>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody id="matrixTableBody">
                                    <!-- Will be populated by JavaScript -->
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="mt-4 text-xs text-gray-500">
                            <p><strong>Couverture :</strong> 15 marchés européens - CAC 40 🇫🇷, DAX 30 🇩🇪, IBEX 35 🇪🇸, FTSE MIB 40 🇮🇹, AEX 25 🇳🇱, BEL 20 🇧🇪, FTSE 100 🇬🇧, SMI 🇨🇭, OMX Stockholm 🇸🇪, OBX 🇳🇴, OMX Helsinki 🇫🇮, OMX Copenhagen 🇩🇰, ATX 🇦🇹, PSI 🇵🇹, WIG 🇵🇱</p>
                            <p><strong>Plus de 200 entreprises européennes</strong> avec classification sectorielle STOXX</p>
                        </div>
                    </div>
                </div>

                <!-- Search Section -->
                <div id="searchSection" class="bg-white rounded-lg shadow-lg p-6 mb-8 hidden">
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center">
                            <i class="fas fa-search text-xl text-blue-600 mr-3"></i>
                            <h2 class="text-xl font-semibold text-gray-800">Rechercher une entreprise</h2>
                        </div>
                        <button id="backToDashboard" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
                            <i class="fas fa-home mr-2"></i>Retour au tableau de bord
                        </button>
                    </div>
                    
                    <!-- Sélecteurs rapides d'indices -->
                    <div class="flex flex-wrap gap-2 mb-4">
                        <button id="showCAC40" class="px-3 py-2 bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 transition-colors text-sm">
                            <i class="fas fa-list mr-1"></i>
                            CAC 40 (40 valeurs)
                        </button>
                        <button id="showDAX30" class="px-3 py-2 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 transition-colors text-sm">
                            <i class="fas fa-list mr-1"></i>
                            DAX 30 (30 valeurs)
                        </button>
                        <button id="showAllEuropean" class="px-3 py-2 bg-purple-100 text-purple-800 rounded-lg hover:bg-purple-200 transition-colors text-sm">
                            <i class="fas fa-globe-europe mr-1"></i>
                            Toutes les valeurs (70 valeurs)
                        </button>
                        <button id="clearSelection" class="px-3 py-2 bg-gray-100 text-gray-800 rounded-lg hover:bg-gray-200 transition-colors text-sm">
                            <i class="fas fa-times mr-1"></i>
                            Effacer
                        </button>
                    </div>

                    <div class="flex space-x-4">
                        <div class="flex-1 relative">
                            <input 
                                type="text" 
                                id="searchInput" 
                                placeholder="Tapez 2-3 lettres pour voir les suggestions CAC40/DAX30, ou recherche globale..."
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            >
                            <div id="searchSuggestions" class="absolute z-20 w-full bg-white border border-gray-300 rounded-lg mt-1 hidden shadow-lg max-h-80 overflow-y-auto">
                            </div>
                        </div>
                        <button 
                            id="searchBtn" 
                            class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
                        >
                            <i class="fas fa-search mr-2"></i>
                            Rechercher
                        </button>
                    </div>

                    <!-- Date Range Filter -->
                    <div class="mt-4 flex space-x-4 items-center">
                        <label class="text-sm font-medium text-gray-700">Filtrer par période :</label>
                        <input 
                            type="date" 
                            id="startDate" 
                            class="px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                        >
                        <span class="text-gray-500">à</span>
                        <input 
                            type="date" 
                            id="endDate" 
                            class="px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                        >
                        <button 
                            id="filterBtn" 
                            class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors"
                        >
                            <i class="fas fa-filter mr-1"></i>
                            Filtrer
                        </button>
                    </div>
                </div>

                <!-- Loading State -->
                <div id="loadingState" class="hidden bg-white rounded-lg shadow-lg p-8 text-center">
                    <i class="fas fa-spinner fa-spin text-3xl text-blue-600 mb-4"></i>
                    <p class="text-gray-600">Chargement des données financières...</p>
                </div>

                <!-- Results Section -->
                <div id="resultsSection" class="hidden bg-white rounded-lg shadow-lg">
                    <!-- Company Info -->
                    <div class="p-6 border-b border-gray-200">
                        <div id="companyInfo" class="flex items-center justify-between">
                            <div>
                                <h3 id="companyName" class="text-2xl font-bold text-gray-800"></h3>
                                <p id="companyDetails" class="text-gray-600"></p>
                            </div>
                            <div class="text-right">
                                <p class="text-sm text-gray-500">Total de jours</p>
                                <p id="totalDays" class="text-2xl font-bold text-blue-600"></p>
                            </div>
                        </div>
                    </div>

                    <!-- Price Chart -->
                    <div class="p-6 border-b border-gray-200">
                        <div class="flex items-center justify-between mb-4">
                            <h4 class="text-lg font-semibold text-gray-800">
                                <i class="fas fa-chart-area mr-2"></i>
                                Évolution des prix
                            </h4>
                            <div class="text-sm text-gray-600">
                                <span id="chartPeriodInfo">Derniers 90 jours</span>
                            </div>
                        </div>

                        <!-- Sélecteurs de type de graphique -->
                        <div class="flex items-center justify-between mb-4">
                            <div class="flex gap-2">
                                <span class="text-sm font-medium text-gray-700 mr-2">Type :</span>
                                <button id="chartTypeCandlestick" class="chart-type-btn px-3 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors text-sm font-medium">
                                    <i class="fas fa-chart-bar mr-1"></i>Chandeliers
                                </button>
                                <button id="chartTypeLine" class="chart-type-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                    <i class="fas fa-chart-line mr-1"></i>Ligne
                                </button>
                                <button id="chartTypePoints" class="chart-type-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                    <i class="fas fa-circle mr-1"></i>Points
                                </button>
                            </div>
                        </div>

                        <!-- Sélecteurs de période -->
                        <div class="flex flex-wrap gap-2 mb-4">
                            <button id="period3M" class="period-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                3M
                            </button>
                            <button id="period6M" class="period-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                6M
                            </button>
                            <button id="period1Y" class="period-btn px-3 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-sm font-medium">
                                1AN
                            </button>
                            <button id="period2Y" class="period-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                2ANS
                            </button>
                            <button id="period3Y" class="period-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                3ANS
                            </button>
                            <button id="period5Y" class="period-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                5ANS
                            </button>
                            <button id="period10Y" class="period-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                10ANS
                            </button>
                            <button id="periodMax" class="period-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                <i class="fas fa-infinity mr-1"></i>MAX
                            </button>
                        </div>

                        <!-- Graphique des prix -->
                        <div class="relative mb-6" style="height: 400px;">
                            <canvas id="priceChart"></canvas>
                        </div>

                        <!-- Graphique des volumes -->
                        <div class="border-t border-gray-600 pt-4">
                            <h5 class="text-md font-semibold text-gray-300 mb-3">
                                <i class="fas fa-chart-bar mr-2"></i>
                                Volume des transactions
                            </h5>
                            <div class="relative" style="height: 150px;">
                                <canvas id="volumeChart"></canvas>
                            </div>
                        </div>
                    </div>

                    <!-- Advanced Metrics Section -->
                    <div class="p-6 border-b border-gray-200">
                        <div class="flex items-center justify-between mb-4">
                            <h4 class="text-lg font-semibold text-gray-800">
                                <i class="fas fa-calculator mr-2"></i>
                                Métriques Financières Avancées
                            </h4>
                            <div class="flex gap-2">
                                <button id="refreshMetrics" class="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                                    <i class="fas fa-sync-alt mr-1"></i>Recalculer
                                </button>
                                <button id="showBenchmarkChart" class="px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm">
                                    <i class="fas fa-chart-line mr-1"></i>Afficher Benchmarks
                                </button>
                            </div>
                        </div>

                        <!-- Metrics Grid -->
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                            <!-- Volatility Card -->
                            <div class="bg-blue-50 rounded-lg p-4">
                                <h5 class="text-sm font-semibold text-blue-800 mb-2">
                                    <i class="fas fa-chart-line mr-1"></i>Volatilité 5 ans
                                </h5>
                                <div class="text-2xl font-bold text-blue-600" id="volatility5Y">--</div>
                                <div class="text-xs text-gray-600">Annualisée</div>
                            </div>

                            <!-- Total Return Card -->
                            <div class="bg-green-50 rounded-lg p-4">
                                <h5 class="text-sm font-semibold text-green-800 mb-2">
                                    <i class="fas fa-trend-up mr-1"></i>Return Total 5 ans
                                </h5>
                                <div class="text-2xl font-bold text-green-600" id="totalReturn5Y">--</div>
                                <div class="text-xs text-gray-600">Cumulé</div>
                            </div>

                            <!-- Correlation Card -->
                            <div class="bg-purple-50 rounded-lg p-4">
                                <h5 class="text-sm font-semibold text-purple-800 mb-2">
                                    <i class="fas fa-link mr-1"></i>Corrélation Sectorielle
                                </h5>
                                <div class="text-2xl font-bold text-purple-600" id="sectorCorrelation">--</div>
                                <div class="text-xs text-gray-600" id="sectorBenchmarkName">vs Secteur</div>
                            </div>

                            <!-- Tracking Error Card -->
                            <div class="bg-orange-50 rounded-lg p-4">
                                <h5 class="text-sm font-semibold text-orange-800 mb-2">
                                    <i class="fas fa-exclamation-triangle mr-1"></i>Tracking Error
                                </h5>
                                <div class="text-2xl font-bold text-orange-600" id="trackingError">--</div>
                                <div class="text-xs text-gray-600">vs Benchmark Sectoriel</div>
                            </div>
                        </div>

                        <!-- Additional Risk Metrics -->
                        <div class="border-t pt-4">
                            <h5 class="text-md font-semibold text-gray-800 mb-3">
                                <i class="fas fa-shield-alt mr-2"></i>
                                Métriques de Risque Complémentaires
                            </h5>
                            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div class="text-center p-3 bg-gray-50 rounded-lg">
                                    <div class="text-sm text-gray-600">Sharpe Ratio</div>
                                    <div class="text-lg font-bold text-gray-800" id="sharpeRatio">--</div>
                                </div>
                                <div class="text-center p-3 bg-gray-50 rounded-lg">
                                    <div class="text-sm text-gray-600">Bêta (vs Marché)</div>
                                    <div class="text-lg font-bold text-gray-800" id="betaMarket">--</div>
                                </div>
                                <div class="text-center p-3 bg-gray-50 rounded-lg">
                                    <div class="text-sm text-gray-600">Alpha (vs Secteur)</div>
                                    <div class="text-lg font-bold text-gray-800" id="alphaSector">--</div>
                                </div>
                                <div class="text-center p-3 bg-gray-50 rounded-lg">
                                    <div class="text-sm text-gray-600">Drawdown Max</div>
                                    <div class="text-lg font-bold text-gray-800" id="maxDrawdown">--</div>
                                </div>
                            </div>
                        </div>

                        <!-- Benchmark Selection -->
                        <div class="border-t pt-4 mt-4">
                            <h5 class="text-md font-semibold text-gray-800 mb-3">
                                <i class="fas fa-compass mr-2"></i>
                                Benchmarks Disponibles
                            </h5>
                            <div class="flex flex-wrap gap-2">
                                <button id="showNationalBenchmark" class="benchmark-btn px-3 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-sm">
                                    <i class="fas fa-flag mr-1"></i>Benchmark National
                                </button>
                                <button id="showSectorBenchmark" class="benchmark-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-green-100 hover:text-green-700 transition-colors text-sm">
                                    <i class="fas fa-industry mr-1"></i>Benchmark Sectoriel
                                </button>
                                <button id="hideBenchmarks" class="benchmark-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-red-100 hover:text-red-700 transition-colors text-sm">
                                    <i class="fas fa-eye-slash mr-1"></i>Masquer Benchmarks
                                </button>
                            </div>
                            <div class="mt-2 text-xs text-gray-600">
                                <span id="benchmarkInfo">Les benchmarks permettent de comparer la performance relative de l'action.</span>
                            </div>
                        </div>
                    </div>

                    <!-- Data Table -->
                    <div class="p-6">
                        <div class="flex items-center justify-between mb-4">
                            <h4 class="text-lg font-semibold text-gray-800">
                                <i class="fas fa-table mr-2"></i>
                                Données historiques
                            </h4>
                            <div class="flex space-x-2">
                                <button id="exportBtn" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors">
                                    <i class="fas fa-download mr-1"></i>
                                    Exporter CSV
                                </button>
                                <button id="exportExcelBtn" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
                                    <i class="fas fa-file-excel mr-1"></i>
                                    Télécharger Excel
                                </button>
                                <select id="recordsPerPage" class="px-3 py-2 border border-gray-300 rounded">
                                    <option value="50">50 lignes</option>
                                    <option value="100">100 lignes</option>
                                    <option value="250">250 lignes</option>
                                    <option value="500">500 lignes</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="overflow-x-auto">
                            <table class="min-w-full table-auto border-collapse">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border">Date</th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border">Ouverture</th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border">Plus Haut</th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border">Plus Bas</th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border">Clôture</th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border">Volume</th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border">Variation %</th>
                                    </tr>
                                </thead>
                                <tbody id="dataTableBody" class="bg-white divide-y divide-gray-200">
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <div id="pagination" class="flex items-center justify-between mt-6">
                            <div class="flex items-center space-x-2">
                                <button id="prevPage" class="px-3 py-2 border border-gray-300 rounded hover:bg-gray-50">
                                    <i class="fas fa-chevron-left"></i>
                                </button>
                                <span id="pageInfo" class="text-sm text-gray-600"></span>
                                <button id="nextPage" class="px-3 py-2 border border-gray-300 rounded hover:bg-gray-50">
                                    <i class="fas fa-chevron-right"></i>
                                </button>
                            </div>
                            <div class="text-sm text-gray-600">
                                <span id="recordsInfo"></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Error State -->
                <div id="errorState" class="hidden bg-red-50 border border-red-200 rounded-lg p-6">
                    <div class="flex items-center">
                        <i class="fas fa-exclamation-triangle text-red-600 text-xl mr-3"></i>
                        <div>
                            <h3 class="text-red-800 font-semibold">Erreur</h3>
                            <p id="errorMessage" class="text-red-700"></p>
                        </div>
                    </div>
                </div>

                <!-- Stock Analyst Section -->
                <div id="stockAnalystSection" class="space-y-8 hidden">
                    <div class="max-w-7xl mx-auto">
                        <!-- Section Header -->
                        <div class="bg-white rounded-lg shadow-lg p-6 mb-8">
                            <div class="flex items-center justify-between mb-4">
                                <h2 class="text-2xl font-bold text-gray-800">
                                    <i class="fas fa-chart-line mr-3"></i>
                                    Analyse d'Actions
                                </h2>
                                <button onclick="showHome()" class="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors">
                                    <i class="fas fa-arrow-left mr-2"></i>Retour à l'accueil
                                </button>
                            </div>
                            
                            <!-- Search Section -->
                            <div class="mb-8">
                                <div class="flex space-x-4 mb-4">
                                    <div class="flex-1 relative">
                                        <input 
                                            type="text" 
                                            id="searchInput" 
                                            placeholder="Symbole de l'action (ex: AAPL, MSFT, SAP.DE, RNO.PA...)"
                                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                        >
                                        <div id="searchSuggestions" class="absolute z-20 w-full bg-white border border-gray-300 rounded-lg mt-1 hidden shadow-lg max-h-60 overflow-y-auto">
                                        </div>
                                    </div>
                                    <button 
                                        id="searchBtn" 
                                        class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
                                    >
                                        <i class="fas fa-search mr-2"></i>
                                        Analyser
                                    </button>
                                </div>
                                
                                <!-- Quick company buttons -->
                                <div class="flex flex-wrap gap-2">
                                    <button class="quick-stock-btn px-3 py-2 bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 transition-colors text-sm" data-symbol="AAPL">
                                        🍎 Apple (AAPL)
                                    </button>
                                    <button class="quick-stock-btn px-3 py-2 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 transition-colors text-sm" data-symbol="MSFT">
                                        🪟 Microsoft (MSFT)
                                    </button>
                                    <button class="quick-stock-btn px-3 py-2 bg-red-100 text-red-800 rounded-lg hover:bg-red-200 transition-colors text-sm" data-symbol="GOOGL">
                                        🔍 Google (GOOGL)
                                    </button>
                                    <button class="quick-stock-btn px-3 py-2 bg-purple-100 text-purple-800 rounded-lg hover:bg-purple-200 transition-colors text-sm" data-symbol="RNO.PA">
                                        🚗 Renault (RNO.PA)
                                    </button>
                                    <button class="quick-stock-btn px-3 py-2 bg-yellow-100 text-yellow-800 rounded-lg hover:bg-yellow-200 transition-colors text-sm" data-symbol="SAP.DE">
                                        💼 SAP (SAP.DE)
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Loading State -->
                        <div id="loadingState" class="bg-white rounded-lg shadow-lg p-8 text-center hidden">
                            <div class="flex flex-col items-center">
                                <i class="fas fa-spinner fa-spin text-4xl text-blue-600 mb-4"></i>
                                <h3 class="text-lg font-semibold text-gray-800 mb-2">Analyse en cours...</h3>
                                <p class="text-gray-600">Récupération et traitement des données financières</p>
                            </div>
                        </div>
                        
                        <!-- Error State -->
                        <div id="errorState" class="bg-white rounded-lg shadow-lg p-8 text-center hidden">
                            <div class="flex flex-col items-center">
                                <i class="fas fa-exclamation-triangle text-4xl text-red-600 mb-4"></i>
                                <h3 class="text-lg font-semibold text-gray-800 mb-2">Erreur</h3>
                                <p id="errorMessage" class="text-gray-600 mb-4"></p>
                                <button id="retrySearch" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                                    <i class="fas fa-redo mr-2"></i>Réessayer
                                </button>
                            </div>
                        </div>
                        
                        <!-- Results Section -->
                        <div id="resultsSection" class="space-y-6 hidden">
                            <div class="bg-white rounded-lg shadow-lg p-6">
                                <p class="text-gray-600 text-center">Les résultats d'analyse apparaîtront ici après la recherche.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Company Selection Modal -->
                <div id="companySelectionModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
                        <!-- Modal Header -->
                        <div class="bg-gradient-to-r from-blue-600 to-blue-700 p-6 text-white">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center space-x-3">
                                    <i class="fas fa-chart-line text-2xl"></i>
                                    <h3 class="text-2xl font-bold">Sélection d'Action</h3>
                                </div>
                                <button onclick="closeCompanyModal()" class="text-white hover:text-gray-200 transition-colors">
                                    <i class="fas fa-times text-2xl"></i>
                                </button>
                            </div>
                            <p class="mt-2 text-blue-100">Choisissez une bourse, puis une société à analyser</p>
                        </div>

                        <!-- Modal Content -->
                        <div class="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
                            <!-- Stock Exchange Selection -->
                            <div id="exchangeSelection" class="space-y-4">
                                <h4 class="text-lg font-semibold text-gray-800 mb-4">
                                    <i class="fas fa-globe mr-2"></i>Sélectionnez une Bourse
                                </h4>
                                
                                <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                                    <!-- US Market -->
                                    <button onclick="showExchangeStocks('US')" class="exchange-btn group bg-gradient-to-br from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 border border-blue-200 rounded-lg p-4 transition-all duration-200 hover:shadow-lg">
                                        <div class="text-center">
                                            <div class="text-3xl mb-2">🇺🇸</div>
                                            <div class="font-bold text-gray-800">États-Unis</div>
                                            <div class="text-xs text-gray-600 mt-1">NYSE • NASDAQ</div>
                                            <div class="text-xs text-blue-600 mt-1">20+ sociétés</div>
                                        </div>
                                    </button>

                                    <!-- France -->
                                    <button onclick="showExchangeStocks('FR')" class="exchange-btn group bg-gradient-to-br from-red-50 to-red-100 hover:from-red-100 hover:to-red-200 border border-red-200 rounded-lg p-4 transition-all duration-200 hover:shadow-lg">
                                        <div class="text-center">
                                            <div class="text-3xl mb-2">🇫🇷</div>
                                            <div class="font-bold text-gray-800">France</div>
                                            <div class="text-xs text-gray-600 mt-1">Euronext Paris</div>
                                            <div class="text-xs text-red-600 mt-1">CAC 40</div>
                                        </div>
                                    </button>

                                    <!-- Germany -->
                                    <button onclick="showExchangeStocks('DE')" class="exchange-btn group bg-gradient-to-br from-yellow-50 to-yellow-100 hover:from-yellow-100 hover:to-yellow-200 border border-yellow-200 rounded-lg p-4 transition-all duration-200 hover:shadow-lg">
                                        <div class="text-center">
                                            <div class="text-3xl mb-2">🇩🇪</div>
                                            <div class="font-bold text-gray-800">Allemagne</div>
                                            <div class="text-xs text-gray-600 mt-1">Frankfurt</div>
                                            <div class="text-xs text-yellow-600 mt-1">DAX 40</div>
                                        </div>
                                    </button>

                                    <!-- Spain -->
                                    <button onclick="showExchangeStocks('ES')" class="exchange-btn group bg-gradient-to-br from-orange-50 to-orange-100 hover:from-orange-100 hover:to-orange-200 border border-orange-200 rounded-lg p-4 transition-all duration-200 hover:shadow-lg">
                                        <div class="text-center">
                                            <div class="text-3xl mb-2">🇪🇸</div>
                                            <div class="font-bold text-gray-800">Espagne</div>
                                            <div class="text-xs text-gray-600 mt-1">BME</div>
                                            <div class="text-xs text-orange-600 mt-1">IBEX 35</div>
                                        </div>
                                    </button>

                                    <!-- Italy -->
                                    <button onclick="showExchangeStocks('IT')" class="exchange-btn group bg-gradient-to-br from-green-50 to-green-100 hover:from-green-100 hover:to-green-200 border border-green-200 rounded-lg p-4 transition-all duration-200 hover:shadow-lg">
                                        <div class="text-center">
                                            <div class="text-3xl mb-2">🇮🇹</div>
                                            <div class="font-bold text-gray-800">Italie</div>
                                            <div class="text-xs text-gray-600 mt-1">Borsa Italiana</div>
                                            <div class="text-xs text-green-600 mt-1">FTSE MIB</div>
                                        </div>
                                    </button>

                                    <!-- Netherlands -->
                                    <button onclick="showExchangeStocks('NL')" class="exchange-btn group bg-gradient-to-br from-purple-50 to-purple-100 hover:from-purple-100 hover:to-purple-200 border border-purple-200 rounded-lg p-4 transition-all duration-200 hover:shadow-lg">
                                        <div class="text-center">
                                            <div class="text-3xl mb-2">🇳🇱</div>
                                            <div class="font-bold text-gray-800">Pays-Bas</div>
                                            <div class="text-xs text-gray-600 mt-1">Euronext Amsterdam</div>
                                            <div class="text-xs text-purple-600 mt-1">AEX 25</div>
                                        </div>
                                    </button>

                                    <!-- UK -->
                                    <button onclick="showExchangeStocks('GB')" class="exchange-btn group bg-gradient-to-br from-indigo-50 to-indigo-100 hover:from-indigo-100 hover:to-indigo-200 border border-indigo-200 rounded-lg p-4 transition-all duration-200 hover:shadow-lg">
                                        <div class="text-center">
                                            <div class="text-3xl mb-2">🇬🇧</div>
                                            <div class="font-bold text-gray-800">Royaume-Uni</div>
                                            <div class="text-xs text-gray-600 mt-1">London Stock Exchange</div>
                                            <div class="text-xs text-indigo-600 mt-1">FTSE 100</div>
                                        </div>
                                    </button>

                                    <!-- Switzerland -->
                                    <button onclick="showExchangeStocks('CH')" class="exchange-btn group bg-gradient-to-br from-gray-50 to-gray-100 hover:from-gray-100 hover:to-gray-200 border border-gray-200 rounded-lg p-4 transition-all duration-200 hover:shadow-lg">
                                        <div class="text-center">
                                            <div class="text-3xl mb-2">🇨🇭</div>
                                            <div class="font-bold text-gray-800">Suisse</div>
                                            <div class="text-xs text-gray-600 mt-1">SIX Swiss</div>
                                            <div class="text-xs text-gray-600 mt-1">SMI</div>
                                        </div>
                                    </button>
                                </div>

                                <!-- Direct Search Option -->
                                <div class="border-t pt-4 mt-6">
                                    <h5 class="text-md font-semibold text-gray-800 mb-3">
                                        <i class="fas fa-search mr-2"></i>Recherche Directe
                                    </h5>
                                    <div class="flex space-x-3">
                                        <input 
                                            type="text" 
                                            id="directSearchInput" 
                                            placeholder="Tapez le symbole (ex: AAPL, RNO.PA) ou nom (ex: Apple, Renault)"
                                            class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                        >
                                        <button onclick="searchDirectSymbol()" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                                            <i class="fas fa-arrow-right"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Company Selection (Hidden by default) -->
                            <div id="companySelection" class="space-y-4 hidden">
                                <div class="flex items-center justify-between mb-4">
                                    <h4 class="text-lg font-semibold text-gray-800">
                                        <i class="fas fa-building mr-2"></i><span id="selectedExchangeTitle">Sociétés</span>
                                    </h4>
                                    <button onclick="backToExchanges()" class="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors">
                                        <i class="fas fa-arrow-left mr-1"></i>Retour
                                    </button>
                                </div>

                                <!-- Companies Grid -->
                                <div id="companiesGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-96 overflow-y-auto">
                                    <!-- Companies will be populated here -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>

            <!-- Footer -->
            <footer class="bg-white border-t border-gray-200 mt-12">
                <div class="max-w-7xl mx-auto px-4 py-6 text-center text-gray-600">
                    <p class="mb-2">
                        <i class="fas fa-info-circle mr-1"></i>
                        Données fournies par Yahoo Finance et autres sources financières
                    </p>
                    <p class="text-sm">
                        Les données peuvent avoir un délai. Utilisez à titre informatif uniquement.
                    </p>
                </div>
            </footer>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
        <script>
            // Navigation functions
            window.showHome = function() {
                const dashboard = document.getElementById('dashboardSection');
                const stockAnalyst = document.getElementById('stockAnalystSection');
                const navHome = document.getElementById('navHome');
                const navStockAnalyst = document.getElementById('navStockAnalyst');
                
                if (dashboard) {
                    dashboard.style.display = 'block';
                    dashboard.classList.remove('hidden');
                }
                if (stockAnalyst) {
                    stockAnalyst.style.display = 'none';
                    stockAnalyst.classList.add('hidden');
                }
                
                // Update navigation buttons
                if (navHome) navHome.className = 'px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors';
                if (navStockAnalyst) navStockAnalyst.className = 'px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-blue-100 hover:text-blue-700 transition-colors';
            };
            
            // Stock Analyst function with visual modal interface
            window.showStockAnalyst = function() {
                // Show the visual modal
                const modal = document.getElementById('companySelectionModal');
                const exchangeSelection = document.getElementById('exchangeSelection');
                const companySelection = document.getElementById('companySelection');
                
                if (modal) {
                    // Reset modal state
                    exchangeSelection.classList.remove('hidden');
                    companySelection.classList.add('hidden');
                    modal.classList.remove('hidden');
                    
                    // Clear direct search input
                    const directInput = document.getElementById('directSearchInput');
                    if (directInput) directInput.value = '';
                }
            };
            
            // Modal management functions
            window.closeCompanyModal = function() {
                const modal = document.getElementById('companySelectionModal');
                if (modal) {
                    modal.classList.add('hidden');
                }
            };
            
            window.backToExchanges = function() {
                const exchangeSelection = document.getElementById('exchangeSelection');
                const companySelection = document.getElementById('companySelection');
                
                if (exchangeSelection && companySelection) {
                    exchangeSelection.classList.remove('hidden');
                    companySelection.classList.add('hidden');
                }
            };
            
            // Show stocks for selected exchange
            window.showExchangeStocks = function(exchangeCode) {
                const exchangeSelection = document.getElementById('exchangeSelection');
                const companySelection = document.getElementById('companySelection');
                const companiesGrid = document.getElementById('companiesGrid');
                const exchangeTitle = document.getElementById('selectedExchangeTitle');
                
                if (!exchangeSelection || !companySelection || !companiesGrid) return;
                
                // Hide exchange selection, show company selection
                exchangeSelection.classList.add('hidden');
                companySelection.classList.remove('hidden');
                
                // Clear existing companies
                companiesGrid.innerHTML = '';
                
                let companies = [];
                let title = '';
                
                if (exchangeCode === 'US') {
                    title = '🇺🇸 Actions Américaines';
                    companies = [
                        { symbol: 'AAPL', name: 'Apple Inc.', sector: 'technology' },
                        { symbol: 'MSFT', name: 'Microsoft Corporation', sector: 'technology' },
                        { symbol: 'GOOGL', name: 'Alphabet Inc.', sector: 'technology' },
                        { symbol: 'AMZN', name: 'Amazon.com Inc.', sector: 'retail' },
                        { symbol: 'TSLA', name: 'Tesla Inc.', sector: 'automobiles' },
                        { symbol: 'NVDA', name: 'NVIDIA Corporation', sector: 'technology' },
                        { symbol: 'META', name: 'Meta Platforms Inc.', sector: 'technology' },
                        { symbol: 'NFLX', name: 'Netflix Inc.', sector: 'media' },
                        { symbol: 'ORCL', name: 'Oracle Corporation', sector: 'technology' },
                        { symbol: 'CRM', name: 'Salesforce Inc.', sector: 'technology' },
                        { symbol: 'ADBE', name: 'Adobe Inc.', sector: 'technology' },
                        { symbol: 'INTC', name: 'Intel Corporation', sector: 'technology' },
                        { symbol: 'CSCO', name: 'Cisco Systems Inc.', sector: 'technology' },
                        { symbol: 'PEP', name: 'PepsiCo Inc.', sector: 'food_beverage' },
                        { symbol: 'KO', name: 'The Coca-Cola Company', sector: 'food_beverage' },
                        { symbol: 'JNJ', name: 'Johnson & Johnson', sector: 'healthcare' },
                        { symbol: 'PG', name: 'Procter & Gamble Co.', sector: 'personal_household' },
                        { symbol: 'V', name: 'Visa Inc.', sector: 'financial_services' },
                        { symbol: 'MA', name: 'Mastercard Inc.', sector: 'financial_services' },
                        { symbol: 'DIS', name: 'The Walt Disney Company', sector: 'media' }
                    ];
                } else {
                    // European companies from database
                    if (typeof EUROPEAN_STOCKS_COMPLETE !== 'undefined' && EUROPEAN_STOCKS_COMPLETE[exchangeCode]) {
                        const country = EUROPEAN_STOCKS_COMPLETE[exchangeCode];
                        title = country.flag + ' ' + country.country;
                        companies = country.companies || [];
                    }
                }
                
                // Update title
                if (exchangeTitle) {
                    exchangeTitle.textContent = title;
                }
                
                // Create company buttons
                companies.forEach(company => {
                    const button = document.createElement('button');
                    button.className = 'company-btn bg-white border border-gray-200 hover:border-blue-300 hover:bg-blue-50 rounded-lg p-3 text-left transition-all duration-200 hover:shadow-md';
                    button.onclick = () => selectCompany(company.symbol);
                    
                    button.innerHTML = \`
                        <div class="font-semibold text-gray-800 text-sm">\${company.symbol}</div>
                        <div class="text-xs text-gray-600 mt-1">\${company.name}</div>
                        <div class="text-xs text-blue-600 mt-1">\${getSectorIcon(company.sector)} \${getSectorName(company.sector)}</div>
                    \`;
                    
                    companiesGrid.appendChild(button);
                });
                
                if (companies.length === 0) {
                    companiesGrid.innerHTML = '<p class="text-gray-500 text-center col-span-full">Aucune société trouvée pour cette bourse.</p>';
                }
            };
            
            // Select company and launch analysis
            window.selectCompany = function(symbol) {
                closeCompanyModal();
                launchAnalysis(symbol);
            };
            
            // Direct search function
            window.searchDirectSymbol = function() {
                const input = document.getElementById('directSearchInput');
                if (!input || !input.value.trim()) return;
                
                const query = input.value.trim().toUpperCase();
                closeCompanyModal();
                launchAnalysis(query);
            };
            
            // Utility functions
            function getSectorIcon(sector) {
                const icons = {
                    'technology': '💻',
                    'healthcare': '🏥',
                    'financial_services': '🏦',
                    'banks': '🏛️',
                    'insurance': '🛡️',
                    'automobiles': '🚗',
                    'food_beverage': '🍽️',
                    'retail': '🛍️',
                    'media': '📺',
                    'telecommunications': '📱',
                    'utilities': '⚡',
                    'oil_gas': '⛽',
                    'basic_materials': '🔩',
                    'industrial_goods': '🏭',
                    'real_estate': '🏢',
                    'personal_household': '👔',
                    'travel_leisure': '✈️',
                    'construction_materials': '🏗️'
                };
                return icons[sector] || '🏢';
            }
            
            function getSectorName(sector) {
                const names = {
                    'technology': 'Technologie',
                    'healthcare': 'Santé',
                    'financial_services': 'Services financiers',
                    'banks': 'Banques',
                    'insurance': 'Assurance',
                    'automobiles': 'Automobile',
                    'food_beverage': 'Alimentaire',
                    'retail': 'Commerce',
                    'media': 'Médias',
                    'telecommunications': 'Télécoms',
                    'utilities': 'Services publics',
                    'oil_gas': 'Pétrole & Gaz',
                    'basic_materials': 'Matériaux',
                    'industrial_goods': 'Industrie',
                    'real_estate': 'Immobilier',
                    'personal_household': 'Biens de consommation',
                    'travel_leisure': 'Voyages & Loisirs',
                    'construction_materials': 'Construction'
                };
                return names[sector] || 'Autre';
            }
            
            // Handle Enter key in direct search
            document.addEventListener('DOMContentLoaded', function() {
                const directInput = document.getElementById('directSearchInput');
                if (directInput) {
                    directInput.addEventListener('keypress', function(e) {
                        if (e.key === 'Enter') {
                            searchDirectSymbol();
                        }
                    });
                }
            });
            
            // Helper function to launch analysis
            window.launchAnalysis = function(symbol) {
                // Show Stock Analyst section
                const dashboard = document.getElementById('dashboardSection');
                const stockAnalyst = document.getElementById('stockAnalystSection');
                const navHome = document.getElementById('navHome');
                const navStockAnalyst = document.getElementById('navStockAnalyst');
                
                if (dashboard) {
                    dashboard.style.display = 'none';
                    dashboard.classList.add('hidden');
                }
                if (stockAnalyst) {
                    stockAnalyst.style.display = 'block';
                    stockAnalyst.classList.remove('hidden');
                }
                
                // Update navigation buttons
                if (navHome) navHome.className = 'px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-blue-100 hover:text-blue-700 transition-colors';
                if (navStockAnalyst) navStockAnalyst.className = 'px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors';
                
                // Fill search input and trigger search
                const searchInput = document.getElementById('searchInput');
                if (searchInput) {
                    searchInput.value = symbol;
                    setTimeout(function() {
                        const searchBtn = document.getElementById('searchBtn');
                        if (searchBtn) {
                            searchBtn.click();
                        }
                    }, 100);
                }
                
                console.log('Analyzing company:', symbol);
            };
            
            // Initialize navigation on page load
            setTimeout(function() {
                window.showHome(); // Show home by default
            }, 500);
        </script>
        
        <script src="/static/app.js"></script>
        <script src="/static/app-extended.js"></script>
    </body>
    </html>
  `)
})

export default app