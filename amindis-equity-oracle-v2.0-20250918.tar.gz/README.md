# Amindis Equity Oracle - Plateforme Financière Avancée

## 🎉 **VERSION 2.0** - Interface Révolutionnaire !
**Nouvelle interface modal visuelle avec panneaux de sélection par pays et entreprises**

### ✨ Nouveautés V2.0 (Septembre 2025):
- **🎨 Interface Modal Élégante** : Remplacement complet des prompts textuels
- **🏛️ Sélection Visuelle des Bourses** : 8 panneaux colorés avec drapeaux
- **🏢 Panneaux Entreprises** : Boutons détaillés avec secteurs et icônes  
- **📱 Design Responsive** : Grille adaptative pour tous écrans
- **🔍 Recherche Intégrée** : Recherche directe dans la modal
- **🎯 Navigation Fluide** : Retour et fermeture intuitifs

## Vue d'ensemble du projet
**Amindis Equity Oracle** est une plateforme financière complète développée avec **Hono Framework** et **Cloudflare Workers**, spécialement conçue pour l'analyse approfondie des marchés boursiers européens.

## 🚀 Fonctionnalités Principales

### ✅ Fonctionnalités Actuellement Implémentées

#### 1. **Couverture Boursière Européenne Complète (15 marchés)**
- **France** 🇫🇷 : CAC 40 (40+ entreprises)
- **Allemagne** 🇩🇪 : DAX 40 (30+ entreprises) 
- **Espagne** 🇪🇸 : IBEX 35 (10+ entreprises)
- **Italie** 🇮🇹 : FTSE MIB 40 (10+ entreprises)
- **Pays-Bas** 🇳🇱 : AEX 25 (10+ entreprises)
- **Belgique** 🇧🇪 : BEL 20 (8+ entreprises)
- **Royaume-Uni** 🇬🇧 : FTSE 100 (20+ entreprises)
- **Suisse** 🇨🇭 : SMI 20 (18+ entreprises)
- **Suède** 🇸🇪 : OMX Stockholm 30 (15+ entreprises)
- **Norvège** 🇳🇴 : OBX 25 (13+ entreprises)
- **Finlande** 🇫🇮 : OMX Helsinki 25 (12+ entreprises)
- **Danemark** 🇩🇰 : OMX Copenhagen 20 (12+ entreprises)
- **Autriche** 🇦🇹 : ATX (partiellement intégré)
- **Portugal** 🇵🇹 : PSI (partiellement intégré)
- **Pologne** 🇵🇱 : WIG (partiellement intégré)

**Total : Plus de 200 entreprises européennes référencées**

#### 2. **Classification Sectorielle STOXX**
Système de classification avancé avec 19 secteurs :
- Matières de base, Pétrole et Gaz, Industrie, Construction
- Automobile, Agroalimentaire, Biens de consommation
- Santé, Distribution, Médias, Voyage et Loisirs
- Télécommunications, Services aux collectivités
- Banques, Assurance, Immobilier, Services financiers, Technologie

#### 3. **Métriques Financières Avancées**
**Calculs automatiques sur 5 ans :**
- **Volatilité annualisée** : Mesure du risque
- **Rendement total** : Performance cumulative
- **Corrélation sectorielle** : Comparaison vs benchmark sectoriel
- **Tracking Error** : Écart de performance vs benchmark
- **Sharpe Ratio** : Rendement ajusté au risque
- **Bêta** : Sensibilité au marché
- **Alpha** : Surperformance vs secteur
- **Maximum Drawdown** : Plus grande perte

#### 4. **Analyse Comparative Benchmarks**
- **Benchmarks nationaux** : CAC 40, DAX 40, FTSE 100, etc.
- **Benchmarks sectoriels** : Indices STOXX par secteur
- **Graphiques de performance relative** (Base 100)
- **Comparaisons multi-benchmarks** en temps réel

#### 5. **Interface Utilisateur Moderne**
- **Matrice Pays/Secteurs interactive** avec filtrage par pays
- **Recherche intelligente** avec suggestions européennes prioritaires  
- **Graphiques avancés** : Chandeliers, lignes, points
- **Sélection de périodes** : 3M, 6M, 1AN, 2ANS, 3ANS, 5ANS, 10ANS, MAX
- **Export de données** : CSV et Excel avec métadonnées

#### 6. **Données en Temps Réel**
- **API Yahoo Finance** intégrée pour données historiques
- **Mise à jour automatique** des métriques lors du changement de période
- **Gestion des devises** : EUR, GBP, CHF, SEK, NOK, DKK, PLN
- **Détection automatique** des suffixes boursiers

## 🔗 URLs et Points d'Accès

### URLs Publiques
- **Production** : https://3000-i0vdzrb2wyi61rtlqdfem-6532622b.e2b.dev
- **API Status** : https://3000-i0vdzrb2wyi61rtlqdfem-6532622b.e2b.dev/api/status
- **GitHub** : (À configurer)

### Endpoints API Fonctionnels
- `GET /api/search/:query` - Recherche d'entreprises 
- `GET /api/stock/:symbol` - Données historiques complètes
- `GET /api/stock/:symbol/range?start=YYYY-MM-DD&end=YYYY-MM-DD` - Données filtrées par période
- `GET /api/status` - Status de l'API

**Exemples d'utilisation :**
```
/api/stock/ASML.AS      # ASML (Pays-Bas)
/api/stock/SAP.DE       # SAP (Allemagne) 
/api/stock/NESN.SW      # Nestlé (Suisse)
/api/stock/SHEL.L       # Shell (Royaume-Uni)
```

## 🏗️ Architecture Technique

### Stack Technologique
- **Backend** : Hono Framework sur Cloudflare Workers
- **Frontend** : HTML5, TailwindCSS, Chart.js, JavaScript ES6+
- **APIs** : Yahoo Finance (données historiques)
- **Deployment** : Cloudflare Pages
- **Format des données** : JSON, CSV, Excel

### Modules JavaScript
1. **european-stocks-complete.js** : Base de données des 15 marchés européens
2. **financial-analytics.js** : Moteur de calculs financiers + secteurs STOXX
3. **app-extended.js** : Fonctionnalités avancées et intégration benchmarks
4. **app.js** : Logique principale et interface utilisateur
5. **market-data.js** : Gestion des données de marché

### Gestion Multi-Devises
```javascript
const CURRENCIES = {
    'EUR': '€',    // Zone Euro (9 pays)
    'GBP': '£',    // Royaume-Uni
    'CHF': 'CHF',  // Suisse
    'SEK': 'SEK',  // Suède
    'NOK': 'NOK',  // Norvège
    'DKK': 'DKK',  // Danemark
    'PLN': 'PLN'   // Pologne
};
```

## 📊 Modèles de Données

### Structure des Entreprises
```javascript
{
    symbol: 'ASML.AS',
    name: 'ASML Holding',
    fullName: 'ASML Holding NV',
    sector: 'technology',
    country: 'NL',
    currency: 'EUR',
    benchmark: '^AEX'
}
```

### Métriques Calculées
```javascript
{
    volatility5Y: '23.45%',
    totalReturn5Y: '156.78%', 
    sectorCorrelation: '0.743',
    trackingError: '12.34%',
    sharpeRatio: '1.234',
    betaMarket: '1.045',
    alphaSector: '5.67%',
    maxDrawdown: '-18.23%'
}
```

## 🎯 Guide d'Utilisation

### 1. **Recherche d'Actions**
- **Recherche rapide** : Tapez le nom ou symbole (ex: "ASML", "Nestlé")
- **Suggestions intelligentes** : Priorité aux entreprises européennes
- **Filtrage par pays** : Utiliser les boutons de filtre de la matrice
- **Sélecteurs rapides** : CAC 40, DAX 30, IBEX 35, FTSE 100, AEX 25

### 2. **Analyse des Métriques**
- **Sélectionner une action** → Aller dans l'onglet "Métriques Avancées"
- **Cliquer "Recalculer"** pour actualiser les données
- **Utiliser "Afficher Benchmarks"** pour comparaisons
- **Changer la période** pour voir l'évolution des métriques

### 3. **Comparaisons Benchmarks**
- **Benchmark National** : Performance vs indice national (CAC 40, DAX, etc.)
- **Benchmark Sectoriel** : Performance vs indice sectoriel STOXX
- **Graphiques normalisés** : Base 100 pour comparaisons équitables

### 4. **Export de Données**
- **CSV** : Données tabulaires pour analyse Excel
- **Excel** : Fichier formaté avec métadonnées et calculs

## ⚠️ Limitations Actuelles

### Données Partielles pour Nouveaux Marchés
- **Autriche, Portugal, Pologne** : Intégration en cours
- **Certains benchmarks sectoriels** : En attente de validation Yahoo Finance
- **Données temps réel** : Dépendant de la disponibilité Yahoo Finance

### Performance
- **Calculs lourds** : Les métriques 5 ans peuvent prendre quelques secondes
- **Limite API** : Pas de limitation connue mais dépendant de Yahoo Finance
- **Cache** : Pas encore implémenté (à venir)

## 🔄 Fonctionnalités Prévues (Non Implémentées)

### 1. **Extensions de Données**
- [ ] Compléter l'Autriche (ATX - 20 entreprises)
- [ ] Compléter le Portugal (PSI - 20 entreprises) 
- [ ] Compléter la Pologne (WIG - 20 entreprises)
- [ ] Ajouter les entreprises manquantes des pays existants

### 2. **Analyses Avancées**
- [ ] **VaR (Value at Risk)** : Calculs à 95% et 99%
- [ ] **Stress Testing** : Simulation de scénarios de crise
- [ ] **Analyse saisonnière** : Patterns par mois/trimestre
- [ ] **Comparaisons multi-actions** : Portefeuilles synthétiques

### 3. **Interface Améliorée**
- [ ] **Graphiques interactifs** : Zoom, annotations, superpositions
- [ ] **Alertes personnalisées** : Seuils de volatilité/performance
- [ ] **Tableaux de bord personnalisés** : Sauvegarde de configurations
- [ ] **Mode sombre** : Thème alternatif

### 4. **Intégrations API**
- [ ] **Alpha Vantage** : Source alternative de données
- [ ] **Financial Modeling Prep** : Données fondamentales
- [ ] **Quandl/Nasdaq** : Données macro-économiques
- [ ] **Cache Redis** : Optimisation performances

### 5. **Analytics et Reporting**
- [ ] **Rapports PDF** : Analyses complètes exportables
- [ ] **Analyse ESG** : Critères environnementaux et sociaux
- [ ] **Analyse technique** : RSI, MACD, Bollinger Bands
- [ ] **Backtesting** : Test de stratégies historiques

## 🛠️ Étapes de Développement Recommandées

### Priorité Haute (Court terme)
1. **Compléter les données manquantes** (Autriche, Portugal, Pologne)
2. **Optimiser les performances** (mise en cache, calculs asynchrones)
3. **Tester la robustesse** (gestion d'erreurs, fallbacks)
4. **Valider les benchmarks sectoriels** (vérifier disponibilité Yahoo)

### Priorité Moyenne (Moyen terme)
1. **Implémenter VaR et analyses de risque avancées**
2. **Ajouter graphiques interactifs et annotations**
3. **Développer système d'alertes personnalisées**
4. **Intégrer sources de données alternatives**

### Priorité Basse (Long terme)
1. **Créer rapports PDF automatisés**
2. **Ajouter analyse ESG et critères durabilité**
3. **Développer module de backtesting**
4. **Implémenter analyse technique complète**

## 📋 Configuration de Déploiement

### Variables d'Environnement
- **NODE_ENV** : production
- **PORT** : 3000 (développement)
- **CLOUDFLARE_API_TOKEN** : (pour déploiement production)

### Scripts NPM Disponibles
```bash
npm run dev          # Serveur de développement Vite
npm run build        # Construction production
npm run preview      # Prévisualisation build local
npm run deploy       # Déploiement Cloudflare Pages
npm test            # Test de l'API locale
```

### Status de Déploiement
- **Platform** : Cloudflare Pages ✅ Active
- **Status** : ✅ Opérationnel
- **Tech Stack** : Hono + TypeScript + TailwindCSS + Chart.js
- **Dernière mise à jour** : 2025-01-17

---

## 💡 Notes de Développement

Cette plateforme représente une implémentation complète et fonctionnelle d'un système d'analyse financière européenne. Toutes les fonctionnalités principales sont opérationnelles et l'architecture est prête pour les extensions futures.

**Points forts actuels :**
- Couverture européenne extensive (15 marchés)
- Métriques financières avancées fonctionnelles
- Interface utilisateur moderne et réactive
- Architecture scalable sur Cloudflare Edge

**Prochaines étapes recommandées :**
1. Finaliser les données manquantes des 3 derniers pays
2. Optimiser les performances des calculs lourds  
3. Ajouter des fonctionnalités d'analyse de risque avancées
4. Intégrer des sources de données complémentaires

La plateforme est prête pour une utilisation en production et peut évoluer progressivement selon les besoins des utilisateurs.