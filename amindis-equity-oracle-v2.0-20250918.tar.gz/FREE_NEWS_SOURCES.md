# 🆓 Sources Gratuites d'Actualités Financières

## 📊 Sources Intégrées (100% Gratuites)

### 🔥 **Option 1 : Finnhub API (RECOMMANDÉ)**
- ✅ **60 requêtes par minute** gratuites
- ✅ **Actualités par entreprise** avec détails
- ✅ **Données structurées** (titre, résumé, source, URL)
- ✅ **Sources professionnelles** (Reuters, Bloomberg, MarketWatch...)

**Inscription :** https://finnhub.io/register
```bash
# Configuration dans .dev.vars
FINNHUB_API_KEY=votre_cle_gratuite_ici
```

### 📰 **Option 2 : RSS Feeds (Aucune Inscription)**
Sources RSS intégrées automatiquement :
- **MarketWatch** : `https://feeds.marketwatch.com/marketwatch/topstories/`
- **Yahoo Finance** : `https://feeds.finance.yahoo.com/rss/2.0/headline`
- **CNBC** : `https://www.cnbc.com/id/100003114/device/rss/rss.html`

## 🔄 **Système Multi-Sources Intelligent**

### Ordre de Priorité Automatique :
1. **Finnhub API** (si clé configurée) → Actualités spécifiques à l'entreprise
2. **RSS Feeds** → Actualités générales filtrées par nom d'entreprise
3. **Pages de Recherche** → Liens directs vers sources fiables

### Avantages :
- ✅ **Zero abonnement payant** requis
- ✅ **Redondance** : plusieurs sources de secours
- ✅ **Actualités réelles** avec titres authentiques
- ✅ **Sources crédibles** uniquement

## 🚀 **Fonctionnalités Disponibles**

### Avec Finnhub API :
```json
{
  "title": "Apple Reports Q4 Earnings Beat Estimates",
  "summary": "Apple Inc. exceeded Wall Street expectations...",
  "source": "Reuters",
  "url": "https://www.reuters.com/technology/apple-q4-earnings...",
  "publishedAt": "2025-09-17T15:30:00.000Z",
  "isRealNews": true
}
```

### Avec RSS Feeds :
```json
{
  "title": "Tech Stocks Rally After Strong Earnings",
  "summary": "Technology companies showed robust performance...",
  "source": "MarketWatch",
  "url": "https://www.marketwatch.com/story/tech-stocks-rally...",
  "publishedAt": "2025-09-17T14:25:00.000Z",
  "fromRSS": true,
  "isRealNews": true
}
```

## 📋 **Configuration Rapide**

### 1. Finnhub (Recommandé)
```bash
# 1. Créer un compte : https://finnhub.io/register
# 2. Copier votre API key
# 3. Configurer dans l'application :

echo "FINNHUB_API_KEY=votre_cle_ici" >> .dev.vars

# Production Cloudflare :
npx wrangler pages secret put FINNHUB_API_KEY
```

### 2. RSS Only (Aucune Configuration)
Les RSS feeds fonctionnent automatiquement sans configuration !

## 🔍 **Sources RSS Disponibles par Catégorie**

### 📈 **Marchés Généraux**
- MarketWatch Top Stories
- Yahoo Finance Headlines  
- CNBC Business News
- Reuters Business
- Bloomberg Markets

### 🏢 **Par Secteur**
- Tech : `https://feeds.marketwatch.com/marketwatch/StockstoWatch/`
- Energy : `https://www.cnbc.com/id/19854910/device/rss/rss.html`
- Healthcare : RSS feeds sectoriels disponibles

### 🌍 **Géographique**
- US Markets : Tous les RSS ci-dessus
- Europe : Reuters Europe, Financial Times
- Asie : Nikkei, Bloomberg Asia

## ⚡ **Performance**

### Vitesse Typique :
- **Finnhub API** : ~200-500ms par requête
- **RSS Feeds** : ~100-300ms par feed
- **Mise en cache** : Résultats cachés 5-15 minutes

### Limites Connues :
- **Finnhub gratuit** : 60 req/min (largement suffisant)
- **RSS** : Pas de limite, mais courtoisie recommandée
- **Pas de rate limiting** sur les RSS publics

## 📱 **Interface Utilisateur**

### Indicateurs Visuels :
- 🟢 **Vraie actualité** : Badge vert "Real News"
- 📰 **RSS Feed** : Icône RSS
- 🔍 **Recherche** : Icône loupe pour les liens de secours

### Informations Affichées :
- **Titre** d'article authentique
- **Résumé** de l'article
- **Source** (Reuters, MarketWatch, etc.)
- **Date** de publication
- **Lien direct** vers l'article original

## 🎯 **Recommandations**

### Pour Usage Personnel/Test :
1. Utiliser **RSS feeds seulement** (aucune configuration)
2. Activation automatique, actualités filtrées par entreprise

### Pour Usage Professionnel :
1. S'inscrire à **Finnhub gratuit** (5 minutes)
2. Configurer la clé API
3. Bénéficier d'actualités spécifiques et structurées

### Éviter :
- ❌ APIs payantes pour un projet de test
- ❌ Web scraping de sites protégés
- ❌ Violation des conditions d'utilisation

## 🔗 **Liens Utiles**

- **Inscription Finnhub** : https://finnhub.io/register
- **Documentation Finnhub** : https://finnhub.io/docs/api
- **RSS MarketWatch** : https://www.marketwatch.com/rss/
- **Flux Yahoo Finance** : Multiple feeds disponibles
- **CNBC RSS** : https://www.cnbc.com/rss-feeds/

---

**✅ Résultat :** Actualités financières 100% authentiques sans aucun coût ! 🎉