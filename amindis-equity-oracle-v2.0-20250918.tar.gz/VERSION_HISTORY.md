# Amindis Equity Oracle - Version History

## Version 2.0 (18 septembre 2025) 🎉
**INTERFACE RÉVOLUTIONNAIRE - Modal Visuelle**

### ✨ Nouvelles Fonctionnalités Majeures:
- **🎨 Interface Modal Visuelle** : Remplace les prompts textuels par une belle interface
- **🏛️ Panneau des Bourses** : 8 bourses européennes + US avec drapeaux et couleurs
- **🏢 Panneau des Entreprises** : Boutons détaillés avec secteurs et icônes
- **📱 Design Responsive** : Grille adaptative pour tous les écrans
- **🔍 Recherche Intégrée** : Recherche directe dans la modal
- **🎯 Navigation Fluide** : Boutons retour et fermeture élégants

### 🌍 Bourses Disponibles:
- 🇺🇸 États-Unis (NYSE • NASDAQ) - 20+ sociétés principales
- 🇫🇷 France (Euronext Paris) - CAC 40 complet
- 🇩🇪 Allemagne (Frankfurt) - DAX 40 complet  
- 🇪🇸 Espagne (BME) - IBEX 35 complet
- 🇮🇹 Italie (Borsa Italiana) - FTSE MIB complet
- 🇳🇱 Pays-Bas (Euronext Amsterdam) - AEX 25 complet
- 🇬🇧 Royaume-Uni (London Stock Exchange) - FTSE 100 complet
- 🇨🇭 Suisse (SIX Swiss) - SMI complet

### 💡 Améliorations UX:
- Effets hover et animations CSS fluides
- Couleurs thématiques par pays
- Icônes sectorielles (💻 Tech, 🏥 Santé, 🏦 Banques, etc.)
- Support clavier complet
- Modal responsive avec scroll automatique

---

## Version 1.x (Historique)
- Interface dashboard de base
- Recherche par prompts textuels
- Base de données européenne
- Calculs financiers académiques
- Export Excel avec formules
