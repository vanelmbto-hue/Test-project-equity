var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// node_modules/unenv/dist/runtime/_internal/utils.mjs
// @__NO_SIDE_EFFECTS__
function createNotImplementedError(name) {
  return new Error(`[unenv] ${name} is not implemented yet!`);
}
__name(createNotImplementedError, "createNotImplementedError");
// @__NO_SIDE_EFFECTS__
function notImplemented(name) {
  const fn = /* @__PURE__ */ __name(() => {
    throw /* @__PURE__ */ createNotImplementedError(name);
  }, "fn");
  return Object.assign(fn, { __unenv__: true });
}
__name(notImplemented, "notImplemented");
// @__NO_SIDE_EFFECTS__
function notImplementedClass(name) {
  return class {
    __unenv__ = true;
    constructor() {
      throw new Error(`[unenv] ${name} is not implemented yet!`);
    }
  };
}
__name(notImplementedClass, "notImplementedClass");

// node_modules/unenv/dist/runtime/node/internal/perf_hooks/performance.mjs
var _timeOrigin = globalThis.performance?.timeOrigin ?? Date.now();
var _performanceNow = globalThis.performance?.now ? globalThis.performance.now.bind(globalThis.performance) : () => Date.now() - _timeOrigin;
var nodeTiming = {
  name: "node",
  entryType: "node",
  startTime: 0,
  duration: 0,
  nodeStart: 0,
  v8Start: 0,
  bootstrapComplete: 0,
  environment: 0,
  loopStart: 0,
  loopExit: 0,
  idleTime: 0,
  uvMetricsInfo: {
    loopCount: 0,
    events: 0,
    eventsWaiting: 0
  },
  detail: void 0,
  toJSON() {
    return this;
  }
};
var PerformanceEntry = class {
  static {
    __name(this, "PerformanceEntry");
  }
  __unenv__ = true;
  detail;
  entryType = "event";
  name;
  startTime;
  constructor(name, options) {
    this.name = name;
    this.startTime = options?.startTime || _performanceNow();
    this.detail = options?.detail;
  }
  get duration() {
    return _performanceNow() - this.startTime;
  }
  toJSON() {
    return {
      name: this.name,
      entryType: this.entryType,
      startTime: this.startTime,
      duration: this.duration,
      detail: this.detail
    };
  }
};
var PerformanceMark = class PerformanceMark2 extends PerformanceEntry {
  static {
    __name(this, "PerformanceMark");
  }
  entryType = "mark";
  constructor() {
    super(...arguments);
  }
  get duration() {
    return 0;
  }
};
var PerformanceMeasure = class extends PerformanceEntry {
  static {
    __name(this, "PerformanceMeasure");
  }
  entryType = "measure";
};
var PerformanceResourceTiming = class extends PerformanceEntry {
  static {
    __name(this, "PerformanceResourceTiming");
  }
  entryType = "resource";
  serverTiming = [];
  connectEnd = 0;
  connectStart = 0;
  decodedBodySize = 0;
  domainLookupEnd = 0;
  domainLookupStart = 0;
  encodedBodySize = 0;
  fetchStart = 0;
  initiatorType = "";
  name = "";
  nextHopProtocol = "";
  redirectEnd = 0;
  redirectStart = 0;
  requestStart = 0;
  responseEnd = 0;
  responseStart = 0;
  secureConnectionStart = 0;
  startTime = 0;
  transferSize = 0;
  workerStart = 0;
  responseStatus = 0;
};
var PerformanceObserverEntryList = class {
  static {
    __name(this, "PerformanceObserverEntryList");
  }
  __unenv__ = true;
  getEntries() {
    return [];
  }
  getEntriesByName(_name, _type) {
    return [];
  }
  getEntriesByType(type) {
    return [];
  }
};
var Performance = class {
  static {
    __name(this, "Performance");
  }
  __unenv__ = true;
  timeOrigin = _timeOrigin;
  eventCounts = /* @__PURE__ */ new Map();
  _entries = [];
  _resourceTimingBufferSize = 0;
  navigation = void 0;
  timing = void 0;
  timerify(_fn, _options) {
    throw createNotImplementedError("Performance.timerify");
  }
  get nodeTiming() {
    return nodeTiming;
  }
  eventLoopUtilization() {
    return {};
  }
  markResourceTiming() {
    return new PerformanceResourceTiming("");
  }
  onresourcetimingbufferfull = null;
  now() {
    if (this.timeOrigin === _timeOrigin) {
      return _performanceNow();
    }
    return Date.now() - this.timeOrigin;
  }
  clearMarks(markName) {
    this._entries = markName ? this._entries.filter((e) => e.name !== markName) : this._entries.filter((e) => e.entryType !== "mark");
  }
  clearMeasures(measureName) {
    this._entries = measureName ? this._entries.filter((e) => e.name !== measureName) : this._entries.filter((e) => e.entryType !== "measure");
  }
  clearResourceTimings() {
    this._entries = this._entries.filter((e) => e.entryType !== "resource" || e.entryType !== "navigation");
  }
  getEntries() {
    return this._entries;
  }
  getEntriesByName(name, type) {
    return this._entries.filter((e) => e.name === name && (!type || e.entryType === type));
  }
  getEntriesByType(type) {
    return this._entries.filter((e) => e.entryType === type);
  }
  mark(name, options) {
    const entry = new PerformanceMark(name, options);
    this._entries.push(entry);
    return entry;
  }
  measure(measureName, startOrMeasureOptions, endMark) {
    let start;
    let end;
    if (typeof startOrMeasureOptions === "string") {
      start = this.getEntriesByName(startOrMeasureOptions, "mark")[0]?.startTime;
      end = this.getEntriesByName(endMark, "mark")[0]?.startTime;
    } else {
      start = Number.parseFloat(startOrMeasureOptions?.start) || this.now();
      end = Number.parseFloat(startOrMeasureOptions?.end) || this.now();
    }
    const entry = new PerformanceMeasure(measureName, {
      startTime: start,
      detail: {
        start,
        end
      }
    });
    this._entries.push(entry);
    return entry;
  }
  setResourceTimingBufferSize(maxSize) {
    this._resourceTimingBufferSize = maxSize;
  }
  addEventListener(type, listener, options) {
    throw createNotImplementedError("Performance.addEventListener");
  }
  removeEventListener(type, listener, options) {
    throw createNotImplementedError("Performance.removeEventListener");
  }
  dispatchEvent(event) {
    throw createNotImplementedError("Performance.dispatchEvent");
  }
  toJSON() {
    return this;
  }
};
var PerformanceObserver = class {
  static {
    __name(this, "PerformanceObserver");
  }
  __unenv__ = true;
  static supportedEntryTypes = [];
  _callback = null;
  constructor(callback) {
    this._callback = callback;
  }
  takeRecords() {
    return [];
  }
  disconnect() {
    throw createNotImplementedError("PerformanceObserver.disconnect");
  }
  observe(options) {
    throw createNotImplementedError("PerformanceObserver.observe");
  }
  bind(fn) {
    return fn;
  }
  runInAsyncScope(fn, thisArg, ...args) {
    return fn.call(thisArg, ...args);
  }
  asyncId() {
    return 0;
  }
  triggerAsyncId() {
    return 0;
  }
  emitDestroy() {
    return this;
  }
};
var performance = globalThis.performance && "addEventListener" in globalThis.performance ? globalThis.performance : new Performance();

// node_modules/@cloudflare/unenv-preset/dist/runtime/polyfill/performance.mjs
globalThis.performance = performance;
globalThis.Performance = Performance;
globalThis.PerformanceEntry = PerformanceEntry;
globalThis.PerformanceMark = PerformanceMark;
globalThis.PerformanceMeasure = PerformanceMeasure;
globalThis.PerformanceObserver = PerformanceObserver;
globalThis.PerformanceObserverEntryList = PerformanceObserverEntryList;
globalThis.PerformanceResourceTiming = PerformanceResourceTiming;

// node_modules/unenv/dist/runtime/node/console.mjs
import { Writable } from "node:stream";

// node_modules/unenv/dist/runtime/mock/noop.mjs
var noop_default = Object.assign(() => {
}, { __unenv__: true });

// node_modules/unenv/dist/runtime/node/console.mjs
var _console = globalThis.console;
var _ignoreErrors = true;
var _stderr = new Writable();
var _stdout = new Writable();
var log = _console?.log ?? noop_default;
var info = _console?.info ?? log;
var trace = _console?.trace ?? info;
var debug = _console?.debug ?? log;
var table = _console?.table ?? log;
var error = _console?.error ?? log;
var warn = _console?.warn ?? error;
var createTask = _console?.createTask ?? /* @__PURE__ */ notImplemented("console.createTask");
var clear = _console?.clear ?? noop_default;
var count = _console?.count ?? noop_default;
var countReset = _console?.countReset ?? noop_default;
var dir = _console?.dir ?? noop_default;
var dirxml = _console?.dirxml ?? noop_default;
var group = _console?.group ?? noop_default;
var groupEnd = _console?.groupEnd ?? noop_default;
var groupCollapsed = _console?.groupCollapsed ?? noop_default;
var profile = _console?.profile ?? noop_default;
var profileEnd = _console?.profileEnd ?? noop_default;
var time = _console?.time ?? noop_default;
var timeEnd = _console?.timeEnd ?? noop_default;
var timeLog = _console?.timeLog ?? noop_default;
var timeStamp = _console?.timeStamp ?? noop_default;
var Console = _console?.Console ?? /* @__PURE__ */ notImplementedClass("console.Console");
var _times = /* @__PURE__ */ new Map();
var _stdoutErrorHandler = noop_default;
var _stderrErrorHandler = noop_default;

// node_modules/@cloudflare/unenv-preset/dist/runtime/node/console.mjs
var workerdConsole = globalThis["console"];
var {
  assert,
  clear: clear2,
  // @ts-expect-error undocumented public API
  context,
  count: count2,
  countReset: countReset2,
  // @ts-expect-error undocumented public API
  createTask: createTask2,
  debug: debug2,
  dir: dir2,
  dirxml: dirxml2,
  error: error2,
  group: group2,
  groupCollapsed: groupCollapsed2,
  groupEnd: groupEnd2,
  info: info2,
  log: log2,
  profile: profile2,
  profileEnd: profileEnd2,
  table: table2,
  time: time2,
  timeEnd: timeEnd2,
  timeLog: timeLog2,
  timeStamp: timeStamp2,
  trace: trace2,
  warn: warn2
} = workerdConsole;
Object.assign(workerdConsole, {
  Console,
  _ignoreErrors,
  _stderr,
  _stderrErrorHandler,
  _stdout,
  _stdoutErrorHandler,
  _times
});
var console_default = workerdConsole;

// node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-console
globalThis.console = console_default;

// node_modules/unenv/dist/runtime/node/internal/process/hrtime.mjs
var hrtime = /* @__PURE__ */ Object.assign(/* @__PURE__ */ __name(function hrtime2(startTime) {
  const now = Date.now();
  const seconds = Math.trunc(now / 1e3);
  const nanos = now % 1e3 * 1e6;
  if (startTime) {
    let diffSeconds = seconds - startTime[0];
    let diffNanos = nanos - startTime[0];
    if (diffNanos < 0) {
      diffSeconds = diffSeconds - 1;
      diffNanos = 1e9 + diffNanos;
    }
    return [diffSeconds, diffNanos];
  }
  return [seconds, nanos];
}, "hrtime"), { bigint: /* @__PURE__ */ __name(function bigint() {
  return BigInt(Date.now() * 1e6);
}, "bigint") });

// node_modules/unenv/dist/runtime/node/internal/process/process.mjs
import { EventEmitter } from "node:events";

// node_modules/unenv/dist/runtime/node/internal/tty/read-stream.mjs
var ReadStream = class {
  static {
    __name(this, "ReadStream");
  }
  fd;
  isRaw = false;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  setRawMode(mode) {
    this.isRaw = mode;
    return this;
  }
};

// node_modules/unenv/dist/runtime/node/internal/tty/write-stream.mjs
var WriteStream = class {
  static {
    __name(this, "WriteStream");
  }
  fd;
  columns = 80;
  rows = 24;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  clearLine(dir4, callback) {
    callback && callback();
    return false;
  }
  clearScreenDown(callback) {
    callback && callback();
    return false;
  }
  cursorTo(x, y, callback) {
    callback && typeof callback === "function" && callback();
    return false;
  }
  moveCursor(dx, dy, callback) {
    callback && callback();
    return false;
  }
  getColorDepth(env3) {
    return 1;
  }
  hasColors(count4, env3) {
    return false;
  }
  getWindowSize() {
    return [this.columns, this.rows];
  }
  write(str, encoding, cb) {
    if (str instanceof Uint8Array) {
      str = new TextDecoder().decode(str);
    }
    try {
      console.log(str);
    } catch {
    }
    cb && typeof cb === "function" && cb();
    return false;
  }
};

// node_modules/unenv/dist/runtime/node/internal/process/node-version.mjs
var NODE_VERSION = "22.14.0";

// node_modules/unenv/dist/runtime/node/internal/process/process.mjs
var Process = class _Process2 extends EventEmitter {
  static {
    __name(this, "Process");
  }
  env;
  hrtime;
  nextTick;
  constructor(impl) {
    super();
    this.env = impl.env;
    this.hrtime = impl.hrtime;
    this.nextTick = impl.nextTick;
    for (const prop of [...Object.getOwnPropertyNames(_Process2.prototype), ...Object.getOwnPropertyNames(EventEmitter.prototype)]) {
      const value = this[prop];
      if (typeof value === "function") {
        this[prop] = value.bind(this);
      }
    }
  }
  // --- event emitter ---
  emitWarning(warning, type, code) {
    console.warn(`${code ? `[${code}] ` : ""}${type ? `${type}: ` : ""}${warning}`);
  }
  emit(...args) {
    return super.emit(...args);
  }
  listeners(eventName) {
    return super.listeners(eventName);
  }
  // --- stdio (lazy initializers) ---
  #stdin;
  #stdout;
  #stderr;
  get stdin() {
    return this.#stdin ??= new ReadStream(0);
  }
  get stdout() {
    return this.#stdout ??= new WriteStream(1);
  }
  get stderr() {
    return this.#stderr ??= new WriteStream(2);
  }
  // --- cwd ---
  #cwd = "/";
  chdir(cwd3) {
    this.#cwd = cwd3;
  }
  cwd() {
    return this.#cwd;
  }
  // --- dummy props and getters ---
  arch = "";
  platform = "";
  argv = [];
  argv0 = "";
  execArgv = [];
  execPath = "";
  title = "";
  pid = 200;
  ppid = 100;
  get version() {
    return `v${NODE_VERSION}`;
  }
  get versions() {
    return { node: NODE_VERSION };
  }
  get allowedNodeEnvironmentFlags() {
    return /* @__PURE__ */ new Set();
  }
  get sourceMapsEnabled() {
    return false;
  }
  get debugPort() {
    return 0;
  }
  get throwDeprecation() {
    return false;
  }
  get traceDeprecation() {
    return false;
  }
  get features() {
    return {};
  }
  get release() {
    return {};
  }
  get connected() {
    return false;
  }
  get config() {
    return {};
  }
  get moduleLoadList() {
    return [];
  }
  constrainedMemory() {
    return 0;
  }
  availableMemory() {
    return 0;
  }
  uptime() {
    return 0;
  }
  resourceUsage() {
    return {};
  }
  // --- noop methods ---
  ref() {
  }
  unref() {
  }
  // --- unimplemented methods ---
  umask() {
    throw createNotImplementedError("process.umask");
  }
  getBuiltinModule() {
    return void 0;
  }
  getActiveResourcesInfo() {
    throw createNotImplementedError("process.getActiveResourcesInfo");
  }
  exit() {
    throw createNotImplementedError("process.exit");
  }
  reallyExit() {
    throw createNotImplementedError("process.reallyExit");
  }
  kill() {
    throw createNotImplementedError("process.kill");
  }
  abort() {
    throw createNotImplementedError("process.abort");
  }
  dlopen() {
    throw createNotImplementedError("process.dlopen");
  }
  setSourceMapsEnabled() {
    throw createNotImplementedError("process.setSourceMapsEnabled");
  }
  loadEnvFile() {
    throw createNotImplementedError("process.loadEnvFile");
  }
  disconnect() {
    throw createNotImplementedError("process.disconnect");
  }
  cpuUsage() {
    throw createNotImplementedError("process.cpuUsage");
  }
  setUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.setUncaughtExceptionCaptureCallback");
  }
  hasUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.hasUncaughtExceptionCaptureCallback");
  }
  initgroups() {
    throw createNotImplementedError("process.initgroups");
  }
  openStdin() {
    throw createNotImplementedError("process.openStdin");
  }
  assert() {
    throw createNotImplementedError("process.assert");
  }
  binding() {
    throw createNotImplementedError("process.binding");
  }
  // --- attached interfaces ---
  permission = { has: /* @__PURE__ */ notImplemented("process.permission.has") };
  report = {
    directory: "",
    filename: "",
    signal: "SIGUSR2",
    compact: false,
    reportOnFatalError: false,
    reportOnSignal: false,
    reportOnUncaughtException: false,
    getReport: /* @__PURE__ */ notImplemented("process.report.getReport"),
    writeReport: /* @__PURE__ */ notImplemented("process.report.writeReport")
  };
  finalization = {
    register: /* @__PURE__ */ notImplemented("process.finalization.register"),
    unregister: /* @__PURE__ */ notImplemented("process.finalization.unregister"),
    registerBeforeExit: /* @__PURE__ */ notImplemented("process.finalization.registerBeforeExit")
  };
  memoryUsage = Object.assign(() => ({
    arrayBuffers: 0,
    rss: 0,
    external: 0,
    heapTotal: 0,
    heapUsed: 0
  }), { rss: /* @__PURE__ */ __name(() => 0, "rss") });
  // --- undefined props ---
  mainModule = void 0;
  domain = void 0;
  // optional
  send = void 0;
  exitCode = void 0;
  channel = void 0;
  getegid = void 0;
  geteuid = void 0;
  getgid = void 0;
  getgroups = void 0;
  getuid = void 0;
  setegid = void 0;
  seteuid = void 0;
  setgid = void 0;
  setgroups = void 0;
  setuid = void 0;
  // internals
  _events = void 0;
  _eventsCount = void 0;
  _exiting = void 0;
  _maxListeners = void 0;
  _debugEnd = void 0;
  _debugProcess = void 0;
  _fatalException = void 0;
  _getActiveHandles = void 0;
  _getActiveRequests = void 0;
  _kill = void 0;
  _preload_modules = void 0;
  _rawDebug = void 0;
  _startProfilerIdleNotifier = void 0;
  _stopProfilerIdleNotifier = void 0;
  _tickCallback = void 0;
  _disconnect = void 0;
  _handleQueue = void 0;
  _pendingMessage = void 0;
  _channel = void 0;
  _send = void 0;
  _linkedBinding = void 0;
};

// node_modules/@cloudflare/unenv-preset/dist/runtime/node/process.mjs
var globalProcess = globalThis["process"];
var getBuiltinModule = globalProcess.getBuiltinModule;
var { exit, platform, nextTick } = getBuiltinModule(
  "node:process"
);
var unenvProcess = new Process({
  env: globalProcess.env,
  hrtime,
  nextTick
});
var {
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  hasUncaughtExceptionCaptureCallback,
  setUncaughtExceptionCaptureCallback,
  loadEnvFile,
  sourceMapsEnabled,
  arch,
  argv,
  argv0,
  chdir,
  config,
  connected,
  constrainedMemory,
  availableMemory,
  cpuUsage,
  cwd,
  debugPort,
  dlopen,
  disconnect,
  emit,
  emitWarning,
  env,
  eventNames,
  execArgv,
  execPath,
  finalization,
  features,
  getActiveResourcesInfo,
  getMaxListeners,
  hrtime: hrtime3,
  kill,
  listeners,
  listenerCount,
  memoryUsage,
  on,
  off,
  once,
  pid,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  setMaxListeners,
  setSourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  title,
  throwDeprecation,
  traceDeprecation,
  umask,
  uptime,
  version,
  versions,
  domain,
  initgroups,
  moduleLoadList,
  reallyExit,
  openStdin,
  assert: assert2,
  binding,
  send,
  exitCode,
  channel,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getuid,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setuid,
  permission,
  mainModule,
  _events,
  _eventsCount,
  _exiting,
  _maxListeners,
  _debugEnd,
  _debugProcess,
  _fatalException,
  _getActiveHandles,
  _getActiveRequests,
  _kill,
  _preload_modules,
  _rawDebug,
  _startProfilerIdleNotifier,
  _stopProfilerIdleNotifier,
  _tickCallback,
  _disconnect,
  _handleQueue,
  _pendingMessage,
  _channel,
  _send,
  _linkedBinding
} = unenvProcess;
var _process = {
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  hasUncaughtExceptionCaptureCallback,
  setUncaughtExceptionCaptureCallback,
  loadEnvFile,
  sourceMapsEnabled,
  arch,
  argv,
  argv0,
  chdir,
  config,
  connected,
  constrainedMemory,
  availableMemory,
  cpuUsage,
  cwd,
  debugPort,
  dlopen,
  disconnect,
  emit,
  emitWarning,
  env,
  eventNames,
  execArgv,
  execPath,
  exit,
  finalization,
  features,
  getBuiltinModule,
  getActiveResourcesInfo,
  getMaxListeners,
  hrtime: hrtime3,
  kill,
  listeners,
  listenerCount,
  memoryUsage,
  nextTick,
  on,
  off,
  once,
  pid,
  platform,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  setMaxListeners,
  setSourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  title,
  throwDeprecation,
  traceDeprecation,
  umask,
  uptime,
  version,
  versions,
  // @ts-expect-error old API
  domain,
  initgroups,
  moduleLoadList,
  reallyExit,
  openStdin,
  assert: assert2,
  binding,
  send,
  exitCode,
  channel,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getuid,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setuid,
  permission,
  mainModule,
  _events,
  _eventsCount,
  _exiting,
  _maxListeners,
  _debugEnd,
  _debugProcess,
  _fatalException,
  _getActiveHandles,
  _getActiveRequests,
  _kill,
  _preload_modules,
  _rawDebug,
  _startProfilerIdleNotifier,
  _stopProfilerIdleNotifier,
  _tickCallback,
  _disconnect,
  _handleQueue,
  _pendingMessage,
  _channel,
  _send,
  _linkedBinding
};
var process_default = _process;

// node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-process
globalThis.process = process_default;

// .wrangler/tmp/pages-yPbr1B/bundledWorker-0.8161420419567547.mjs
import { Writable as Writable2 } from "node:stream";
import { EventEmitter as EventEmitter2 } from "node:events";
var __defProp2 = Object.defineProperty;
var __name2 = /* @__PURE__ */ __name((target, value) => __defProp2(target, "name", { value, configurable: true }), "__name");
// @__NO_SIDE_EFFECTS__
function createNotImplementedError2(name) {
  return new Error(`[unenv] ${name} is not implemented yet!`);
}
__name(createNotImplementedError2, "createNotImplementedError");
__name2(createNotImplementedError2, "createNotImplementedError");
// @__NO_SIDE_EFFECTS__
function notImplemented2(name) {
  const fn = /* @__PURE__ */ __name2(() => {
    throw /* @__PURE__ */ createNotImplementedError2(name);
  }, "fn");
  return Object.assign(fn, { __unenv__: true });
}
__name(notImplemented2, "notImplemented");
__name2(notImplemented2, "notImplemented");
// @__NO_SIDE_EFFECTS__
function notImplementedClass2(name) {
  return class {
    __unenv__ = true;
    constructor() {
      throw new Error(`[unenv] ${name} is not implemented yet!`);
    }
  };
}
__name(notImplementedClass2, "notImplementedClass");
__name2(notImplementedClass2, "notImplementedClass");
var _timeOrigin2 = globalThis.performance?.timeOrigin ?? Date.now();
var _performanceNow2 = globalThis.performance?.now ? globalThis.performance.now.bind(globalThis.performance) : () => Date.now() - _timeOrigin2;
var nodeTiming2 = {
  name: "node",
  entryType: "node",
  startTime: 0,
  duration: 0,
  nodeStart: 0,
  v8Start: 0,
  bootstrapComplete: 0,
  environment: 0,
  loopStart: 0,
  loopExit: 0,
  idleTime: 0,
  uvMetricsInfo: {
    loopCount: 0,
    events: 0,
    eventsWaiting: 0
  },
  detail: void 0,
  toJSON() {
    return this;
  }
};
var PerformanceEntry2 = class {
  static {
    __name(this, "PerformanceEntry");
  }
  static {
    __name2(this, "PerformanceEntry");
  }
  __unenv__ = true;
  detail;
  entryType = "event";
  name;
  startTime;
  constructor(name, options) {
    this.name = name;
    this.startTime = options?.startTime || _performanceNow2();
    this.detail = options?.detail;
  }
  get duration() {
    return _performanceNow2() - this.startTime;
  }
  toJSON() {
    return {
      name: this.name,
      entryType: this.entryType,
      startTime: this.startTime,
      duration: this.duration,
      detail: this.detail
    };
  }
};
var PerformanceMark3 = class PerformanceMark22 extends PerformanceEntry2 {
  static {
    __name(this, "PerformanceMark2");
  }
  static {
    __name2(this, "PerformanceMark");
  }
  entryType = "mark";
  constructor() {
    super(...arguments);
  }
  get duration() {
    return 0;
  }
};
var PerformanceMeasure2 = class extends PerformanceEntry2 {
  static {
    __name(this, "PerformanceMeasure");
  }
  static {
    __name2(this, "PerformanceMeasure");
  }
  entryType = "measure";
};
var PerformanceResourceTiming2 = class extends PerformanceEntry2 {
  static {
    __name(this, "PerformanceResourceTiming");
  }
  static {
    __name2(this, "PerformanceResourceTiming");
  }
  entryType = "resource";
  serverTiming = [];
  connectEnd = 0;
  connectStart = 0;
  decodedBodySize = 0;
  domainLookupEnd = 0;
  domainLookupStart = 0;
  encodedBodySize = 0;
  fetchStart = 0;
  initiatorType = "";
  name = "";
  nextHopProtocol = "";
  redirectEnd = 0;
  redirectStart = 0;
  requestStart = 0;
  responseEnd = 0;
  responseStart = 0;
  secureConnectionStart = 0;
  startTime = 0;
  transferSize = 0;
  workerStart = 0;
  responseStatus = 0;
};
var PerformanceObserverEntryList2 = class {
  static {
    __name(this, "PerformanceObserverEntryList");
  }
  static {
    __name2(this, "PerformanceObserverEntryList");
  }
  __unenv__ = true;
  getEntries() {
    return [];
  }
  getEntriesByName(_name, _type) {
    return [];
  }
  getEntriesByType(type) {
    return [];
  }
};
var Performance2 = class {
  static {
    __name(this, "Performance");
  }
  static {
    __name2(this, "Performance");
  }
  __unenv__ = true;
  timeOrigin = _timeOrigin2;
  eventCounts = /* @__PURE__ */ new Map();
  _entries = [];
  _resourceTimingBufferSize = 0;
  navigation = void 0;
  timing = void 0;
  timerify(_fn, _options) {
    throw /* @__PURE__ */ createNotImplementedError2("Performance.timerify");
  }
  get nodeTiming() {
    return nodeTiming2;
  }
  eventLoopUtilization() {
    return {};
  }
  markResourceTiming() {
    return new PerformanceResourceTiming2("");
  }
  onresourcetimingbufferfull = null;
  now() {
    if (this.timeOrigin === _timeOrigin2) {
      return _performanceNow2();
    }
    return Date.now() - this.timeOrigin;
  }
  clearMarks(markName) {
    this._entries = markName ? this._entries.filter((e) => e.name !== markName) : this._entries.filter((e) => e.entryType !== "mark");
  }
  clearMeasures(measureName) {
    this._entries = measureName ? this._entries.filter((e) => e.name !== measureName) : this._entries.filter((e) => e.entryType !== "measure");
  }
  clearResourceTimings() {
    this._entries = this._entries.filter((e) => e.entryType !== "resource" || e.entryType !== "navigation");
  }
  getEntries() {
    return this._entries;
  }
  getEntriesByName(name, type) {
    return this._entries.filter((e) => e.name === name && (!type || e.entryType === type));
  }
  getEntriesByType(type) {
    return this._entries.filter((e) => e.entryType === type);
  }
  mark(name, options) {
    const entry = new PerformanceMark3(name, options);
    this._entries.push(entry);
    return entry;
  }
  measure(measureName, startOrMeasureOptions, endMark) {
    let start;
    let end;
    if (typeof startOrMeasureOptions === "string") {
      start = this.getEntriesByName(startOrMeasureOptions, "mark")[0]?.startTime;
      end = this.getEntriesByName(endMark, "mark")[0]?.startTime;
    } else {
      start = Number.parseFloat(startOrMeasureOptions?.start) || this.now();
      end = Number.parseFloat(startOrMeasureOptions?.end) || this.now();
    }
    const entry = new PerformanceMeasure2(measureName, {
      startTime: start,
      detail: {
        start,
        end
      }
    });
    this._entries.push(entry);
    return entry;
  }
  setResourceTimingBufferSize(maxSize) {
    this._resourceTimingBufferSize = maxSize;
  }
  addEventListener(type, listener, options) {
    throw /* @__PURE__ */ createNotImplementedError2("Performance.addEventListener");
  }
  removeEventListener(type, listener, options) {
    throw /* @__PURE__ */ createNotImplementedError2("Performance.removeEventListener");
  }
  dispatchEvent(event) {
    throw /* @__PURE__ */ createNotImplementedError2("Performance.dispatchEvent");
  }
  toJSON() {
    return this;
  }
};
var PerformanceObserver2 = class {
  static {
    __name(this, "PerformanceObserver");
  }
  static {
    __name2(this, "PerformanceObserver");
  }
  __unenv__ = true;
  static supportedEntryTypes = [];
  _callback = null;
  constructor(callback) {
    this._callback = callback;
  }
  takeRecords() {
    return [];
  }
  disconnect() {
    throw /* @__PURE__ */ createNotImplementedError2("PerformanceObserver.disconnect");
  }
  observe(options) {
    throw /* @__PURE__ */ createNotImplementedError2("PerformanceObserver.observe");
  }
  bind(fn) {
    return fn;
  }
  runInAsyncScope(fn, thisArg, ...args) {
    return fn.call(thisArg, ...args);
  }
  asyncId() {
    return 0;
  }
  triggerAsyncId() {
    return 0;
  }
  emitDestroy() {
    return this;
  }
};
var performance2 = globalThis.performance && "addEventListener" in globalThis.performance ? globalThis.performance : new Performance2();
globalThis.performance = performance2;
globalThis.Performance = Performance2;
globalThis.PerformanceEntry = PerformanceEntry2;
globalThis.PerformanceMark = PerformanceMark3;
globalThis.PerformanceMeasure = PerformanceMeasure2;
globalThis.PerformanceObserver = PerformanceObserver2;
globalThis.PerformanceObserverEntryList = PerformanceObserverEntryList2;
globalThis.PerformanceResourceTiming = PerformanceResourceTiming2;
var noop_default2 = Object.assign(() => {
}, { __unenv__: true });
var _console2 = globalThis.console;
var _ignoreErrors2 = true;
var _stderr2 = new Writable2();
var _stdout2 = new Writable2();
var log3 = _console2?.log ?? noop_default2;
var info3 = _console2?.info ?? log3;
var trace3 = _console2?.trace ?? info3;
var debug3 = _console2?.debug ?? log3;
var table3 = _console2?.table ?? log3;
var error3 = _console2?.error ?? log3;
var warn3 = _console2?.warn ?? error3;
var createTask3 = _console2?.createTask ?? /* @__PURE__ */ notImplemented2("console.createTask");
var clear3 = _console2?.clear ?? noop_default2;
var count3 = _console2?.count ?? noop_default2;
var countReset3 = _console2?.countReset ?? noop_default2;
var dir3 = _console2?.dir ?? noop_default2;
var dirxml3 = _console2?.dirxml ?? noop_default2;
var group3 = _console2?.group ?? noop_default2;
var groupEnd3 = _console2?.groupEnd ?? noop_default2;
var groupCollapsed3 = _console2?.groupCollapsed ?? noop_default2;
var profile3 = _console2?.profile ?? noop_default2;
var profileEnd3 = _console2?.profileEnd ?? noop_default2;
var time3 = _console2?.time ?? noop_default2;
var timeEnd3 = _console2?.timeEnd ?? noop_default2;
var timeLog3 = _console2?.timeLog ?? noop_default2;
var timeStamp3 = _console2?.timeStamp ?? noop_default2;
var Console2 = _console2?.Console ?? /* @__PURE__ */ notImplementedClass2("console.Console");
var _times2 = /* @__PURE__ */ new Map();
var _stdoutErrorHandler2 = noop_default2;
var _stderrErrorHandler2 = noop_default2;
var workerdConsole2 = globalThis["console"];
var {
  assert: assert3,
  clear: clear22,
  // @ts-expect-error undocumented public API
  context: context2,
  count: count22,
  countReset: countReset22,
  // @ts-expect-error undocumented public API
  createTask: createTask22,
  debug: debug22,
  dir: dir22,
  dirxml: dirxml22,
  error: error22,
  group: group22,
  groupCollapsed: groupCollapsed22,
  groupEnd: groupEnd22,
  info: info22,
  log: log22,
  profile: profile22,
  profileEnd: profileEnd22,
  table: table22,
  time: time22,
  timeEnd: timeEnd22,
  timeLog: timeLog22,
  timeStamp: timeStamp22,
  trace: trace22,
  warn: warn22
} = workerdConsole2;
Object.assign(workerdConsole2, {
  Console: Console2,
  _ignoreErrors: _ignoreErrors2,
  _stderr: _stderr2,
  _stderrErrorHandler: _stderrErrorHandler2,
  _stdout: _stdout2,
  _stdoutErrorHandler: _stdoutErrorHandler2,
  _times: _times2
});
var console_default2 = workerdConsole2;
globalThis.console = console_default2;
var hrtime4 = /* @__PURE__ */ Object.assign(/* @__PURE__ */ __name2(/* @__PURE__ */ __name(function hrtime22(startTime) {
  const now = Date.now();
  const seconds = Math.trunc(now / 1e3);
  const nanos = now % 1e3 * 1e6;
  if (startTime) {
    let diffSeconds = seconds - startTime[0];
    let diffNanos = nanos - startTime[0];
    if (diffNanos < 0) {
      diffSeconds = diffSeconds - 1;
      diffNanos = 1e9 + diffNanos;
    }
    return [diffSeconds, diffNanos];
  }
  return [seconds, nanos];
}, "hrtime2"), "hrtime"), { bigint: /* @__PURE__ */ __name2(/* @__PURE__ */ __name(function bigint2() {
  return BigInt(Date.now() * 1e6);
}, "bigint"), "bigint") });
var ReadStream2 = class {
  static {
    __name(this, "ReadStream");
  }
  static {
    __name2(this, "ReadStream");
  }
  fd;
  isRaw = false;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  setRawMode(mode) {
    this.isRaw = mode;
    return this;
  }
};
var WriteStream2 = class {
  static {
    __name(this, "WriteStream");
  }
  static {
    __name2(this, "WriteStream");
  }
  fd;
  columns = 80;
  rows = 24;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  clearLine(dir32, callback) {
    callback && callback();
    return false;
  }
  clearScreenDown(callback) {
    callback && callback();
    return false;
  }
  cursorTo(x, y, callback) {
    callback && typeof callback === "function" && callback();
    return false;
  }
  moveCursor(dx, dy, callback) {
    callback && callback();
    return false;
  }
  getColorDepth(env22) {
    return 1;
  }
  hasColors(count32, env22) {
    return false;
  }
  getWindowSize() {
    return [this.columns, this.rows];
  }
  write(str, encoding, cb) {
    if (str instanceof Uint8Array) {
      str = new TextDecoder().decode(str);
    }
    try {
      console.log(str);
    } catch {
    }
    cb && typeof cb === "function" && cb();
    return false;
  }
};
var NODE_VERSION2 = "22.14.0";
var Process2 = class _Process extends EventEmitter2 {
  static {
    __name(this, "_Process");
  }
  static {
    __name2(this, "Process");
  }
  env;
  hrtime;
  nextTick;
  constructor(impl) {
    super();
    this.env = impl.env;
    this.hrtime = impl.hrtime;
    this.nextTick = impl.nextTick;
    for (const prop of [...Object.getOwnPropertyNames(_Process.prototype), ...Object.getOwnPropertyNames(EventEmitter2.prototype)]) {
      const value = this[prop];
      if (typeof value === "function") {
        this[prop] = value.bind(this);
      }
    }
  }
  // --- event emitter ---
  emitWarning(warning, type, code) {
    console.warn(`${code ? `[${code}] ` : ""}${type ? `${type}: ` : ""}${warning}`);
  }
  emit(...args) {
    return super.emit(...args);
  }
  listeners(eventName) {
    return super.listeners(eventName);
  }
  // --- stdio (lazy initializers) ---
  #stdin;
  #stdout;
  #stderr;
  get stdin() {
    return this.#stdin ??= new ReadStream2(0);
  }
  get stdout() {
    return this.#stdout ??= new WriteStream2(1);
  }
  get stderr() {
    return this.#stderr ??= new WriteStream2(2);
  }
  // --- cwd ---
  #cwd = "/";
  chdir(cwd22) {
    this.#cwd = cwd22;
  }
  cwd() {
    return this.#cwd;
  }
  // --- dummy props and getters ---
  arch = "";
  platform = "";
  argv = [];
  argv0 = "";
  execArgv = [];
  execPath = "";
  title = "";
  pid = 200;
  ppid = 100;
  get version() {
    return `v${NODE_VERSION2}`;
  }
  get versions() {
    return { node: NODE_VERSION2 };
  }
  get allowedNodeEnvironmentFlags() {
    return /* @__PURE__ */ new Set();
  }
  get sourceMapsEnabled() {
    return false;
  }
  get debugPort() {
    return 0;
  }
  get throwDeprecation() {
    return false;
  }
  get traceDeprecation() {
    return false;
  }
  get features() {
    return {};
  }
  get release() {
    return {};
  }
  get connected() {
    return false;
  }
  get config() {
    return {};
  }
  get moduleLoadList() {
    return [];
  }
  constrainedMemory() {
    return 0;
  }
  availableMemory() {
    return 0;
  }
  uptime() {
    return 0;
  }
  resourceUsage() {
    return {};
  }
  // --- noop methods ---
  ref() {
  }
  unref() {
  }
  // --- unimplemented methods ---
  umask() {
    throw /* @__PURE__ */ createNotImplementedError2("process.umask");
  }
  getBuiltinModule() {
    return void 0;
  }
  getActiveResourcesInfo() {
    throw /* @__PURE__ */ createNotImplementedError2("process.getActiveResourcesInfo");
  }
  exit() {
    throw /* @__PURE__ */ createNotImplementedError2("process.exit");
  }
  reallyExit() {
    throw /* @__PURE__ */ createNotImplementedError2("process.reallyExit");
  }
  kill() {
    throw /* @__PURE__ */ createNotImplementedError2("process.kill");
  }
  abort() {
    throw /* @__PURE__ */ createNotImplementedError2("process.abort");
  }
  dlopen() {
    throw /* @__PURE__ */ createNotImplementedError2("process.dlopen");
  }
  setSourceMapsEnabled() {
    throw /* @__PURE__ */ createNotImplementedError2("process.setSourceMapsEnabled");
  }
  loadEnvFile() {
    throw /* @__PURE__ */ createNotImplementedError2("process.loadEnvFile");
  }
  disconnect() {
    throw /* @__PURE__ */ createNotImplementedError2("process.disconnect");
  }
  cpuUsage() {
    throw /* @__PURE__ */ createNotImplementedError2("process.cpuUsage");
  }
  setUncaughtExceptionCaptureCallback() {
    throw /* @__PURE__ */ createNotImplementedError2("process.setUncaughtExceptionCaptureCallback");
  }
  hasUncaughtExceptionCaptureCallback() {
    throw /* @__PURE__ */ createNotImplementedError2("process.hasUncaughtExceptionCaptureCallback");
  }
  initgroups() {
    throw /* @__PURE__ */ createNotImplementedError2("process.initgroups");
  }
  openStdin() {
    throw /* @__PURE__ */ createNotImplementedError2("process.openStdin");
  }
  assert() {
    throw /* @__PURE__ */ createNotImplementedError2("process.assert");
  }
  binding() {
    throw /* @__PURE__ */ createNotImplementedError2("process.binding");
  }
  // --- attached interfaces ---
  permission = { has: /* @__PURE__ */ notImplemented2("process.permission.has") };
  report = {
    directory: "",
    filename: "",
    signal: "SIGUSR2",
    compact: false,
    reportOnFatalError: false,
    reportOnSignal: false,
    reportOnUncaughtException: false,
    getReport: /* @__PURE__ */ notImplemented2("process.report.getReport"),
    writeReport: /* @__PURE__ */ notImplemented2("process.report.writeReport")
  };
  finalization = {
    register: /* @__PURE__ */ notImplemented2("process.finalization.register"),
    unregister: /* @__PURE__ */ notImplemented2("process.finalization.unregister"),
    registerBeforeExit: /* @__PURE__ */ notImplemented2("process.finalization.registerBeforeExit")
  };
  memoryUsage = Object.assign(() => ({
    arrayBuffers: 0,
    rss: 0,
    external: 0,
    heapTotal: 0,
    heapUsed: 0
  }), { rss: /* @__PURE__ */ __name2(() => 0, "rss") });
  // --- undefined props ---
  mainModule = void 0;
  domain = void 0;
  // optional
  send = void 0;
  exitCode = void 0;
  channel = void 0;
  getegid = void 0;
  geteuid = void 0;
  getgid = void 0;
  getgroups = void 0;
  getuid = void 0;
  setegid = void 0;
  seteuid = void 0;
  setgid = void 0;
  setgroups = void 0;
  setuid = void 0;
  // internals
  _events = void 0;
  _eventsCount = void 0;
  _exiting = void 0;
  _maxListeners = void 0;
  _debugEnd = void 0;
  _debugProcess = void 0;
  _fatalException = void 0;
  _getActiveHandles = void 0;
  _getActiveRequests = void 0;
  _kill = void 0;
  _preload_modules = void 0;
  _rawDebug = void 0;
  _startProfilerIdleNotifier = void 0;
  _stopProfilerIdleNotifier = void 0;
  _tickCallback = void 0;
  _disconnect = void 0;
  _handleQueue = void 0;
  _pendingMessage = void 0;
  _channel = void 0;
  _send = void 0;
  _linkedBinding = void 0;
};
var globalProcess2 = globalThis["process"];
var getBuiltinModule2 = globalProcess2.getBuiltinModule;
var { exit: exit2, platform: platform2, nextTick: nextTick2 } = getBuiltinModule2(
  "node:process"
);
var unenvProcess2 = new Process2({
  env: globalProcess2.env,
  hrtime: hrtime4,
  nextTick: nextTick2
});
var {
  abort: abort2,
  addListener: addListener2,
  allowedNodeEnvironmentFlags: allowedNodeEnvironmentFlags2,
  hasUncaughtExceptionCaptureCallback: hasUncaughtExceptionCaptureCallback2,
  setUncaughtExceptionCaptureCallback: setUncaughtExceptionCaptureCallback2,
  loadEnvFile: loadEnvFile2,
  sourceMapsEnabled: sourceMapsEnabled2,
  arch: arch2,
  argv: argv2,
  argv0: argv02,
  chdir: chdir2,
  config: config2,
  connected: connected2,
  constrainedMemory: constrainedMemory2,
  availableMemory: availableMemory2,
  cpuUsage: cpuUsage2,
  cwd: cwd2,
  debugPort: debugPort2,
  dlopen: dlopen2,
  disconnect: disconnect2,
  emit: emit2,
  emitWarning: emitWarning2,
  env: env2,
  eventNames: eventNames2,
  execArgv: execArgv2,
  execPath: execPath2,
  finalization: finalization2,
  features: features2,
  getActiveResourcesInfo: getActiveResourcesInfo2,
  getMaxListeners: getMaxListeners2,
  hrtime: hrtime32,
  kill: kill2,
  listeners: listeners2,
  listenerCount: listenerCount2,
  memoryUsage: memoryUsage2,
  on: on2,
  off: off2,
  once: once2,
  pid: pid2,
  ppid: ppid2,
  prependListener: prependListener2,
  prependOnceListener: prependOnceListener2,
  rawListeners: rawListeners2,
  release: release2,
  removeAllListeners: removeAllListeners2,
  removeListener: removeListener2,
  report: report2,
  resourceUsage: resourceUsage2,
  setMaxListeners: setMaxListeners2,
  setSourceMapsEnabled: setSourceMapsEnabled2,
  stderr: stderr2,
  stdin: stdin2,
  stdout: stdout2,
  title: title2,
  throwDeprecation: throwDeprecation2,
  traceDeprecation: traceDeprecation2,
  umask: umask2,
  uptime: uptime2,
  version: version2,
  versions: versions2,
  domain: domain2,
  initgroups: initgroups2,
  moduleLoadList: moduleLoadList2,
  reallyExit: reallyExit2,
  openStdin: openStdin2,
  assert: assert22,
  binding: binding2,
  send: send2,
  exitCode: exitCode2,
  channel: channel2,
  getegid: getegid2,
  geteuid: geteuid2,
  getgid: getgid2,
  getgroups: getgroups2,
  getuid: getuid2,
  setegid: setegid2,
  seteuid: seteuid2,
  setgid: setgid2,
  setgroups: setgroups2,
  setuid: setuid2,
  permission: permission2,
  mainModule: mainModule2,
  _events: _events2,
  _eventsCount: _eventsCount2,
  _exiting: _exiting2,
  _maxListeners: _maxListeners2,
  _debugEnd: _debugEnd2,
  _debugProcess: _debugProcess2,
  _fatalException: _fatalException2,
  _getActiveHandles: _getActiveHandles2,
  _getActiveRequests: _getActiveRequests2,
  _kill: _kill2,
  _preload_modules: _preload_modules2,
  _rawDebug: _rawDebug2,
  _startProfilerIdleNotifier: _startProfilerIdleNotifier2,
  _stopProfilerIdleNotifier: _stopProfilerIdleNotifier2,
  _tickCallback: _tickCallback2,
  _disconnect: _disconnect2,
  _handleQueue: _handleQueue2,
  _pendingMessage: _pendingMessage2,
  _channel: _channel2,
  _send: _send2,
  _linkedBinding: _linkedBinding2
} = unenvProcess2;
var _process2 = {
  abort: abort2,
  addListener: addListener2,
  allowedNodeEnvironmentFlags: allowedNodeEnvironmentFlags2,
  hasUncaughtExceptionCaptureCallback: hasUncaughtExceptionCaptureCallback2,
  setUncaughtExceptionCaptureCallback: setUncaughtExceptionCaptureCallback2,
  loadEnvFile: loadEnvFile2,
  sourceMapsEnabled: sourceMapsEnabled2,
  arch: arch2,
  argv: argv2,
  argv0: argv02,
  chdir: chdir2,
  config: config2,
  connected: connected2,
  constrainedMemory: constrainedMemory2,
  availableMemory: availableMemory2,
  cpuUsage: cpuUsage2,
  cwd: cwd2,
  debugPort: debugPort2,
  dlopen: dlopen2,
  disconnect: disconnect2,
  emit: emit2,
  emitWarning: emitWarning2,
  env: env2,
  eventNames: eventNames2,
  execArgv: execArgv2,
  execPath: execPath2,
  exit: exit2,
  finalization: finalization2,
  features: features2,
  getBuiltinModule: getBuiltinModule2,
  getActiveResourcesInfo: getActiveResourcesInfo2,
  getMaxListeners: getMaxListeners2,
  hrtime: hrtime32,
  kill: kill2,
  listeners: listeners2,
  listenerCount: listenerCount2,
  memoryUsage: memoryUsage2,
  nextTick: nextTick2,
  on: on2,
  off: off2,
  once: once2,
  pid: pid2,
  platform: platform2,
  ppid: ppid2,
  prependListener: prependListener2,
  prependOnceListener: prependOnceListener2,
  rawListeners: rawListeners2,
  release: release2,
  removeAllListeners: removeAllListeners2,
  removeListener: removeListener2,
  report: report2,
  resourceUsage: resourceUsage2,
  setMaxListeners: setMaxListeners2,
  setSourceMapsEnabled: setSourceMapsEnabled2,
  stderr: stderr2,
  stdin: stdin2,
  stdout: stdout2,
  title: title2,
  throwDeprecation: throwDeprecation2,
  traceDeprecation: traceDeprecation2,
  umask: umask2,
  uptime: uptime2,
  version: version2,
  versions: versions2,
  // @ts-expect-error old API
  domain: domain2,
  initgroups: initgroups2,
  moduleLoadList: moduleLoadList2,
  reallyExit: reallyExit2,
  openStdin: openStdin2,
  assert: assert22,
  binding: binding2,
  send: send2,
  exitCode: exitCode2,
  channel: channel2,
  getegid: getegid2,
  geteuid: geteuid2,
  getgid: getgid2,
  getgroups: getgroups2,
  getuid: getuid2,
  setegid: setegid2,
  seteuid: seteuid2,
  setgid: setgid2,
  setgroups: setgroups2,
  setuid: setuid2,
  permission: permission2,
  mainModule: mainModule2,
  _events: _events2,
  _eventsCount: _eventsCount2,
  _exiting: _exiting2,
  _maxListeners: _maxListeners2,
  _debugEnd: _debugEnd2,
  _debugProcess: _debugProcess2,
  _fatalException: _fatalException2,
  _getActiveHandles: _getActiveHandles2,
  _getActiveRequests: _getActiveRequests2,
  _kill: _kill2,
  _preload_modules: _preload_modules2,
  _rawDebug: _rawDebug2,
  _startProfilerIdleNotifier: _startProfilerIdleNotifier2,
  _stopProfilerIdleNotifier: _stopProfilerIdleNotifier2,
  _tickCallback: _tickCallback2,
  _disconnect: _disconnect2,
  _handleQueue: _handleQueue2,
  _pendingMessage: _pendingMessage2,
  _channel: _channel2,
  _send: _send2,
  _linkedBinding: _linkedBinding2
};
var process_default2 = _process2;
globalThis.process = process_default2;
var St = Object.defineProperty;
var Be = /* @__PURE__ */ __name2((e) => {
  throw TypeError(e);
}, "Be");
var Et = /* @__PURE__ */ __name2((e, t, s) => t in e ? St(e, t, { enumerable: true, configurable: true, writable: true, value: s }) : e[t] = s, "Et");
var p = /* @__PURE__ */ __name2((e, t, s) => Et(e, typeof t != "symbol" ? t + "" : t, s), "p");
var Te = /* @__PURE__ */ __name2((e, t, s) => t.has(e) || Be("Cannot " + s), "Te");
var i = /* @__PURE__ */ __name2((e, t, s) => (Te(e, t, "read from private field"), s ? s.call(e) : t.get(e)), "i");
var m = /* @__PURE__ */ __name2((e, t, s) => t.has(e) ? Be("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, s), "m");
var g = /* @__PURE__ */ __name2((e, t, s, r) => (Te(e, t, "write to private field"), r ? r.call(e, s) : t.set(e, s), s), "g");
var f = /* @__PURE__ */ __name2((e, t, s) => (Te(e, t, "access private method"), s), "f");
var He = /* @__PURE__ */ __name2((e, t, s, r) => ({ set _(a) {
  g(e, t, a, s);
}, get _() {
  return i(e, t, r);
} }), "He");
var Le = /* @__PURE__ */ __name2((e, t, s) => (r, a) => {
  let n = -1;
  return o(0);
  async function o(c) {
    if (c <= n) throw new Error("next() called multiple times");
    n = c;
    let l, d = false, u;
    if (e[c] ? (u = e[c][0][0], r.req.routeIndex = c) : u = c === e.length && a || void 0, u) try {
      l = await u(r, () => o(c + 1));
    } catch (h) {
      if (h instanceof Error && t) r.error = h, l = await t(h, r), d = true;
      else throw h;
    }
    else r.finalized === false && s && (l = await s(r));
    return l && (r.finalized === false || d) && (r.res = l), r;
  }
  __name(o, "o");
  __name2(o, "o");
}, "Le");
var At = Symbol();
var Ct = /* @__PURE__ */ __name2(async (e, t = /* @__PURE__ */ Object.create(null)) => {
  const { all: s = false, dot: r = false } = t, n = (e instanceof at ? e.raw.headers : e.headers).get("Content-Type");
  return n != null && n.startsWith("multipart/form-data") || n != null && n.startsWith("application/x-www-form-urlencoded") ? kt(e, { all: s, dot: r }) : {};
}, "Ct");
async function kt(e, t) {
  const s = await e.formData();
  return s ? Rt(s, t) : {};
}
__name(kt, "kt");
__name2(kt, "kt");
function Rt(e, t) {
  const s = /* @__PURE__ */ Object.create(null);
  return e.forEach((r, a) => {
    t.all || a.endsWith("[]") ? jt(s, a, r) : s[a] = r;
  }), t.dot && Object.entries(s).forEach(([r, a]) => {
    r.includes(".") && (It(s, r, a), delete s[r]);
  }), s;
}
__name(Rt, "Rt");
__name2(Rt, "Rt");
var jt = /* @__PURE__ */ __name2((e, t, s) => {
  e[t] !== void 0 ? Array.isArray(e[t]) ? e[t].push(s) : e[t] = [e[t], s] : t.endsWith("[]") ? e[t] = [s] : e[t] = s;
}, "jt");
var It = /* @__PURE__ */ __name2((e, t, s) => {
  let r = e;
  const a = t.split(".");
  a.forEach((n, o) => {
    o === a.length - 1 ? r[n] = s : ((!r[n] || typeof r[n] != "object" || Array.isArray(r[n]) || r[n] instanceof File) && (r[n] = /* @__PURE__ */ Object.create(null)), r = r[n]);
  });
}, "It");
var Ze = /* @__PURE__ */ __name2((e) => {
  const t = e.split("/");
  return t[0] === "" && t.shift(), t;
}, "Ze");
var Tt = /* @__PURE__ */ __name2((e) => {
  const { groups: t, path: s } = Pt(e), r = Ze(s);
  return Ot(r, t);
}, "Tt");
var Pt = /* @__PURE__ */ __name2((e) => {
  const t = [];
  return e = e.replace(/\{[^}]+\}/g, (s, r) => {
    const a = `@${r}`;
    return t.push([a, s]), a;
  }), { groups: t, path: e };
}, "Pt");
var Ot = /* @__PURE__ */ __name2((e, t) => {
  for (let s = t.length - 1; s >= 0; s--) {
    const [r] = t[s];
    for (let a = e.length - 1; a >= 0; a--) if (e[a].includes(r)) {
      e[a] = e[a].replace(r, t[s][1]);
      break;
    }
  }
  return e;
}, "Ot");
var Se = {};
var Dt = /* @__PURE__ */ __name2((e, t) => {
  if (e === "*") return "*";
  const s = e.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (s) {
    const r = `${e}#${t}`;
    return Se[r] || (s[2] ? Se[r] = t && t[0] !== ":" && t[0] !== "*" ? [r, s[1], new RegExp(`^${s[2]}(?=/${t})`)] : [e, s[1], new RegExp(`^${s[2]}$`)] : Se[r] = [e, s[1], true]), Se[r];
  }
  return null;
}, "Dt");
var Ne = /* @__PURE__ */ __name2((e, t) => {
  try {
    return t(e);
  } catch {
    return e.replace(/(?:%[0-9A-Fa-f]{2})+/g, (s) => {
      try {
        return t(s);
      } catch {
        return s;
      }
    });
  }
}, "Ne");
var Mt = /* @__PURE__ */ __name2((e) => Ne(e, decodeURI), "Mt");
var et = /* @__PURE__ */ __name2((e) => {
  const t = e.url, s = t.indexOf("/", t.indexOf(":") + 4);
  let r = s;
  for (; r < t.length; r++) {
    const a = t.charCodeAt(r);
    if (a === 37) {
      const n = t.indexOf("?", r), o = t.slice(s, n === -1 ? void 0 : n);
      return Mt(o.includes("%25") ? o.replace(/%25/g, "%2525") : o);
    } else if (a === 63) break;
  }
  return t.slice(s, r);
}, "et");
var Nt = /* @__PURE__ */ __name2((e) => {
  const t = et(e);
  return t.length > 1 && t.at(-1) === "/" ? t.slice(0, -1) : t;
}, "Nt");
var se = /* @__PURE__ */ __name2((e, t, ...s) => (s.length && (t = se(t, ...s)), `${(e == null ? void 0 : e[0]) === "/" ? "" : "/"}${e}${t === "/" ? "" : `${(e == null ? void 0 : e.at(-1)) === "/" ? "" : "/"}${(t == null ? void 0 : t[0]) === "/" ? t.slice(1) : t}`}`), "se");
var tt = /* @__PURE__ */ __name2((e) => {
  if (e.charCodeAt(e.length - 1) !== 63 || !e.includes(":")) return null;
  const t = e.split("/"), s = [];
  let r = "";
  return t.forEach((a) => {
    if (a !== "" && !/\:/.test(a)) r += "/" + a;
    else if (/\:/.test(a)) if (/\?/.test(a)) {
      s.length === 0 && r === "" ? s.push("/") : s.push(r);
      const n = a.replace("?", "");
      r += "/" + n, s.push(r);
    } else r += "/" + a;
  }), s.filter((a, n, o) => o.indexOf(a) === n);
}, "tt");
var Pe = /* @__PURE__ */ __name2((e) => /[%+]/.test(e) ? (e.indexOf("+") !== -1 && (e = e.replace(/\+/g, " ")), e.indexOf("%") !== -1 ? Ne(e, rt) : e) : e, "Pe");
var st = /* @__PURE__ */ __name2((e, t, s) => {
  let r;
  if (!s && t && !/[%+]/.test(t)) {
    let o = e.indexOf(`?${t}`, 8);
    for (o === -1 && (o = e.indexOf(`&${t}`, 8)); o !== -1; ) {
      const c = e.charCodeAt(o + t.length + 1);
      if (c === 61) {
        const l = o + t.length + 2, d = e.indexOf("&", l);
        return Pe(e.slice(l, d === -1 ? void 0 : d));
      } else if (c == 38 || isNaN(c)) return "";
      o = e.indexOf(`&${t}`, o + 1);
    }
    if (r = /[%+]/.test(e), !r) return;
  }
  const a = {};
  r ?? (r = /[%+]/.test(e));
  let n = e.indexOf("?", 8);
  for (; n !== -1; ) {
    const o = e.indexOf("&", n + 1);
    let c = e.indexOf("=", n);
    c > o && o !== -1 && (c = -1);
    let l = e.slice(n + 1, c === -1 ? o === -1 ? void 0 : o : c);
    if (r && (l = Pe(l)), n = o, l === "") continue;
    let d;
    c === -1 ? d = "" : (d = e.slice(c + 1, o === -1 ? void 0 : o), r && (d = Pe(d))), s ? (a[l] && Array.isArray(a[l]) || (a[l] = []), a[l].push(d)) : a[l] ?? (a[l] = d);
  }
  return t ? a[t] : a;
}, "st");
var _t = st;
var Bt = /* @__PURE__ */ __name2((e, t) => st(e, t, true), "Bt");
var rt = decodeURIComponent;
var Fe = /* @__PURE__ */ __name2((e) => Ne(e, rt), "Fe");
var ne;
var j;
var H;
var nt;
var ot;
var De;
var F;
var ze;
var at = (ze = class {
  static {
    __name(this, "ze");
  }
  static {
    __name2(this, "ze");
  }
  constructor(e, t = "/", s = [[]]) {
    m(this, H);
    p(this, "raw");
    m(this, ne);
    m(this, j);
    p(this, "routeIndex", 0);
    p(this, "path");
    p(this, "bodyCache", {});
    m(this, F, (e2) => {
      const { bodyCache: t2, raw: s2 } = this, r = t2[e2];
      if (r) return r;
      const a = Object.keys(t2)[0];
      return a ? t2[a].then((n) => (a === "json" && (n = JSON.stringify(n)), new Response(n)[e2]())) : t2[e2] = s2[e2]();
    });
    this.raw = e, this.path = t, g(this, j, s), g(this, ne, {});
  }
  param(e) {
    return e ? f(this, H, nt).call(this, e) : f(this, H, ot).call(this);
  }
  query(e) {
    return _t(this.url, e);
  }
  queries(e) {
    return Bt(this.url, e);
  }
  header(e) {
    if (e) return this.raw.headers.get(e) ?? void 0;
    const t = {};
    return this.raw.headers.forEach((s, r) => {
      t[r] = s;
    }), t;
  }
  async parseBody(e) {
    var t;
    return (t = this.bodyCache).parsedBody ?? (t.parsedBody = await Ct(this, e));
  }
  json() {
    return i(this, F).call(this, "text").then((e) => JSON.parse(e));
  }
  text() {
    return i(this, F).call(this, "text");
  }
  arrayBuffer() {
    return i(this, F).call(this, "arrayBuffer");
  }
  blob() {
    return i(this, F).call(this, "blob");
  }
  formData() {
    return i(this, F).call(this, "formData");
  }
  addValidatedData(e, t) {
    i(this, ne)[e] = t;
  }
  valid(e) {
    return i(this, ne)[e];
  }
  get url() {
    return this.raw.url;
  }
  get method() {
    return this.raw.method;
  }
  get [At]() {
    return i(this, j);
  }
  get matchedRoutes() {
    return i(this, j)[0].map(([[, e]]) => e);
  }
  get routePath() {
    return i(this, j)[0].map(([[, e]]) => e)[this.routeIndex].path;
  }
}, ne = /* @__PURE__ */ new WeakMap(), j = /* @__PURE__ */ new WeakMap(), H = /* @__PURE__ */ new WeakSet(), nt = /* @__PURE__ */ __name2(function(e) {
  const t = i(this, j)[0][this.routeIndex][1][e], s = f(this, H, De).call(this, t);
  return s ? /\%/.test(s) ? Fe(s) : s : void 0;
}, "nt"), ot = /* @__PURE__ */ __name2(function() {
  const e = {}, t = Object.keys(i(this, j)[0][this.routeIndex][1]);
  for (const s of t) {
    const r = f(this, H, De).call(this, i(this, j)[0][this.routeIndex][1][s]);
    r && typeof r == "string" && (e[s] = /\%/.test(r) ? Fe(r) : r);
  }
  return e;
}, "ot"), De = /* @__PURE__ */ __name2(function(e) {
  return i(this, j)[1] ? i(this, j)[1][e] : e;
}, "De"), F = /* @__PURE__ */ new WeakMap(), ze);
var Ht = { Stringify: 1 };
var it = /* @__PURE__ */ __name2(async (e, t, s, r, a) => {
  typeof e == "object" && !(e instanceof String) && (e instanceof Promise || (e = e.toString()), e instanceof Promise && (e = await e));
  const n = e.callbacks;
  return n != null && n.length ? (a ? a[0] += e : a = [e], Promise.all(n.map((c) => c({ phase: t, buffer: a, context: r }))).then((c) => Promise.all(c.filter(Boolean).map((l) => it(l, t, false, r, a))).then(() => a[0]))) : Promise.resolve(e);
}, "it");
var Lt = "text/plain; charset=UTF-8";
var Oe = /* @__PURE__ */ __name2((e, t) => ({ "Content-Type": e, ...t }), "Oe");
var me;
var fe;
var M;
var oe;
var N;
var R;
var xe;
var ie;
var le;
var Y;
var ye;
var ve;
var q;
var re;
var Ge;
var Ft = (Ge = class {
  static {
    __name(this, "Ge");
  }
  static {
    __name2(this, "Ge");
  }
  constructor(e, t) {
    m(this, q);
    m(this, me);
    m(this, fe);
    p(this, "env", {});
    m(this, M);
    p(this, "finalized", false);
    p(this, "error");
    m(this, oe);
    m(this, N);
    m(this, R);
    m(this, xe);
    m(this, ie);
    m(this, le);
    m(this, Y);
    m(this, ye);
    m(this, ve);
    p(this, "render", (...e2) => (i(this, ie) ?? g(this, ie, (t2) => this.html(t2)), i(this, ie).call(this, ...e2)));
    p(this, "setLayout", (e2) => g(this, xe, e2));
    p(this, "getLayout", () => i(this, xe));
    p(this, "setRenderer", (e2) => {
      g(this, ie, e2);
    });
    p(this, "header", (e2, t2, s) => {
      this.finalized && g(this, R, new Response(i(this, R).body, i(this, R)));
      const r = i(this, R) ? i(this, R).headers : i(this, Y) ?? g(this, Y, new Headers());
      t2 === void 0 ? r.delete(e2) : s != null && s.append ? r.append(e2, t2) : r.set(e2, t2);
    });
    p(this, "status", (e2) => {
      g(this, oe, e2);
    });
    p(this, "set", (e2, t2) => {
      i(this, M) ?? g(this, M, /* @__PURE__ */ new Map()), i(this, M).set(e2, t2);
    });
    p(this, "get", (e2) => i(this, M) ? i(this, M).get(e2) : void 0);
    p(this, "newResponse", (...e2) => f(this, q, re).call(this, ...e2));
    p(this, "body", (e2, t2, s) => f(this, q, re).call(this, e2, t2, s));
    p(this, "text", (e2, t2, s) => !i(this, Y) && !i(this, oe) && !t2 && !s && !this.finalized ? new Response(e2) : f(this, q, re).call(this, e2, t2, Oe(Lt, s)));
    p(this, "json", (e2, t2, s) => f(this, q, re).call(this, JSON.stringify(e2), t2, Oe("application/json", s)));
    p(this, "html", (e2, t2, s) => {
      const r = /* @__PURE__ */ __name2((a) => f(this, q, re).call(this, a, t2, Oe("text/html; charset=UTF-8", s)), "r");
      return typeof e2 == "object" ? it(e2, Ht.Stringify, false, {}).then(r) : r(e2);
    });
    p(this, "redirect", (e2, t2) => {
      const s = String(e2);
      return this.header("Location", /[^\x00-\xFF]/.test(s) ? encodeURI(s) : s), this.newResponse(null, t2 ?? 302);
    });
    p(this, "notFound", () => (i(this, le) ?? g(this, le, () => new Response()), i(this, le).call(this, this)));
    g(this, me, e), t && (g(this, N, t.executionCtx), this.env = t.env, g(this, le, t.notFoundHandler), g(this, ve, t.path), g(this, ye, t.matchResult));
  }
  get req() {
    return i(this, fe) ?? g(this, fe, new at(i(this, me), i(this, ve), i(this, ye))), i(this, fe);
  }
  get event() {
    if (i(this, N) && "respondWith" in i(this, N)) return i(this, N);
    throw Error("This context has no FetchEvent");
  }
  get executionCtx() {
    if (i(this, N)) return i(this, N);
    throw Error("This context has no ExecutionContext");
  }
  get res() {
    return i(this, R) || g(this, R, new Response(null, { headers: i(this, Y) ?? g(this, Y, new Headers()) }));
  }
  set res(e) {
    if (i(this, R) && e) {
      e = new Response(e.body, e);
      for (const [t, s] of i(this, R).headers.entries()) if (t !== "content-type") if (t === "set-cookie") {
        const r = i(this, R).headers.getSetCookie();
        e.headers.delete("set-cookie");
        for (const a of r) e.headers.append("set-cookie", a);
      } else e.headers.set(t, s);
    }
    g(this, R, e), this.finalized = true;
  }
  get var() {
    return i(this, M) ? Object.fromEntries(i(this, M)) : {};
  }
}, me = /* @__PURE__ */ new WeakMap(), fe = /* @__PURE__ */ new WeakMap(), M = /* @__PURE__ */ new WeakMap(), oe = /* @__PURE__ */ new WeakMap(), N = /* @__PURE__ */ new WeakMap(), R = /* @__PURE__ */ new WeakMap(), xe = /* @__PURE__ */ new WeakMap(), ie = /* @__PURE__ */ new WeakMap(), le = /* @__PURE__ */ new WeakMap(), Y = /* @__PURE__ */ new WeakMap(), ye = /* @__PURE__ */ new WeakMap(), ve = /* @__PURE__ */ new WeakMap(), q = /* @__PURE__ */ new WeakSet(), re = /* @__PURE__ */ __name2(function(e, t, s) {
  const r = i(this, R) ? new Headers(i(this, R).headers) : i(this, Y) ?? new Headers();
  if (typeof t == "object" && "headers" in t) {
    const n = t.headers instanceof Headers ? t.headers : new Headers(t.headers);
    for (const [o, c] of n) o.toLowerCase() === "set-cookie" ? r.append(o, c) : r.set(o, c);
  }
  if (s) for (const [n, o] of Object.entries(s)) if (typeof o == "string") r.set(n, o);
  else {
    r.delete(n);
    for (const c of o) r.append(n, c);
  }
  const a = typeof t == "number" ? t : (t == null ? void 0 : t.status) ?? i(this, oe);
  return new Response(e, { status: a, headers: r });
}, "re"), Ge);
var w = "ALL";
var qt = "all";
var $t = ["get", "post", "put", "delete", "options", "patch"];
var lt = "Can not add a route since the matcher is already built.";
var ct = class extends Error {
  static {
    __name(this, "ct");
  }
  static {
    __name2(this, "ct");
  }
};
var Ut = "__COMPOSED_HANDLER";
var zt = /* @__PURE__ */ __name2((e) => e.text("404 Not Found", 404), "zt");
var qe = /* @__PURE__ */ __name2((e, t) => {
  if ("getResponse" in e) {
    const s = e.getResponse();
    return t.newResponse(s.body, s);
  }
  return console.error(e), t.text("Internal Server Error", 500);
}, "qe");
var I;
var S;
var ut;
var T;
var V;
var Ee;
var Ae;
var Xe;
var dt = (Xe = class {
  static {
    __name(this, "Xe");
  }
  static {
    __name2(this, "Xe");
  }
  constructor(t = {}) {
    m(this, S);
    p(this, "get");
    p(this, "post");
    p(this, "put");
    p(this, "delete");
    p(this, "options");
    p(this, "patch");
    p(this, "all");
    p(this, "on");
    p(this, "use");
    p(this, "router");
    p(this, "getPath");
    p(this, "_basePath", "/");
    m(this, I, "/");
    p(this, "routes", []);
    m(this, T, zt);
    p(this, "errorHandler", qe);
    p(this, "onError", (t2) => (this.errorHandler = t2, this));
    p(this, "notFound", (t2) => (g(this, T, t2), this));
    p(this, "fetch", (t2, ...s) => f(this, S, Ae).call(this, t2, s[1], s[0], t2.method));
    p(this, "request", (t2, s, r2, a2) => t2 instanceof Request ? this.fetch(s ? new Request(t2, s) : t2, r2, a2) : (t2 = t2.toString(), this.fetch(new Request(/^https?:\/\//.test(t2) ? t2 : `http://localhost${se("/", t2)}`, s), r2, a2)));
    p(this, "fire", () => {
      addEventListener("fetch", (t2) => {
        t2.respondWith(f(this, S, Ae).call(this, t2.request, t2, void 0, t2.request.method));
      });
    });
    [...$t, qt].forEach((n) => {
      this[n] = (o, ...c) => (typeof o == "string" ? g(this, I, o) : f(this, S, V).call(this, n, i(this, I), o), c.forEach((l) => {
        f(this, S, V).call(this, n, i(this, I), l);
      }), this);
    }), this.on = (n, o, ...c) => {
      for (const l of [o].flat()) {
        g(this, I, l);
        for (const d of [n].flat()) c.map((u) => {
          f(this, S, V).call(this, d.toUpperCase(), i(this, I), u);
        });
      }
      return this;
    }, this.use = (n, ...o) => (typeof n == "string" ? g(this, I, n) : (g(this, I, "*"), o.unshift(n)), o.forEach((c) => {
      f(this, S, V).call(this, w, i(this, I), c);
    }), this);
    const { strict: r, ...a } = t;
    Object.assign(this, a), this.getPath = r ?? true ? t.getPath ?? et : Nt;
  }
  route(t, s) {
    const r = this.basePath(t);
    return s.routes.map((a) => {
      var o;
      let n;
      s.errorHandler === qe ? n = a.handler : (n = /* @__PURE__ */ __name2(async (c, l) => (await Le([], s.errorHandler)(c, () => a.handler(c, l))).res, "n"), n[Ut] = a.handler), f(o = r, S, V).call(o, a.method, a.path, n);
    }), this;
  }
  basePath(t) {
    const s = f(this, S, ut).call(this);
    return s._basePath = se(this._basePath, t), s;
  }
  mount(t, s, r) {
    let a, n;
    r && (typeof r == "function" ? n = r : (n = r.optionHandler, r.replaceRequest === false ? a = /* @__PURE__ */ __name2((l) => l, "a") : a = r.replaceRequest));
    const o = n ? (l) => {
      const d = n(l);
      return Array.isArray(d) ? d : [d];
    } : (l) => {
      let d;
      try {
        d = l.executionCtx;
      } catch {
      }
      return [l.env, d];
    };
    a || (a = (() => {
      const l = se(this._basePath, t), d = l === "/" ? 0 : l.length;
      return (u) => {
        const h = new URL(u.url);
        return h.pathname = h.pathname.slice(d) || "/", new Request(h, u);
      };
    })());
    const c = /* @__PURE__ */ __name2(async (l, d) => {
      const u = await s(a(l.req.raw), ...o(l));
      if (u) return u;
      await d();
    }, "c");
    return f(this, S, V).call(this, w, se(t, "*"), c), this;
  }
}, I = /* @__PURE__ */ new WeakMap(), S = /* @__PURE__ */ new WeakSet(), ut = /* @__PURE__ */ __name2(function() {
  const t = new dt({ router: this.router, getPath: this.getPath });
  return t.errorHandler = this.errorHandler, g(t, T, i(this, T)), t.routes = this.routes, t;
}, "ut"), T = /* @__PURE__ */ new WeakMap(), V = /* @__PURE__ */ __name2(function(t, s, r) {
  t = t.toUpperCase(), s = se(this._basePath, s);
  const a = { basePath: this._basePath, path: s, method: t, handler: r };
  this.router.add(t, s, [r, a]), this.routes.push(a);
}, "V"), Ee = /* @__PURE__ */ __name2(function(t, s) {
  if (t instanceof Error) return this.errorHandler(t, s);
  throw t;
}, "Ee"), Ae = /* @__PURE__ */ __name2(function(t, s, r, a) {
  if (a === "HEAD") return (async () => new Response(null, await f(this, S, Ae).call(this, t, s, r, "GET")))();
  const n = this.getPath(t, { env: r }), o = this.router.match(a, n), c = new Ft(t, { path: n, matchResult: o, env: r, executionCtx: s, notFoundHandler: i(this, T) });
  if (o[0].length === 1) {
    let d;
    try {
      d = o[0][0][0][0](c, async () => {
        c.res = await i(this, T).call(this, c);
      });
    } catch (u) {
      return f(this, S, Ee).call(this, u, c);
    }
    return d instanceof Promise ? d.then((u) => u || (c.finalized ? c.res : i(this, T).call(this, c))).catch((u) => f(this, S, Ee).call(this, u, c)) : d ?? i(this, T).call(this, c);
  }
  const l = Le(o[0], this.errorHandler, i(this, T));
  return (async () => {
    try {
      const d = await l(c);
      if (!d.finalized) throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");
      return d.res;
    } catch (d) {
      return f(this, S, Ee).call(this, d, c);
    }
  })();
}, "Ae"), Xe);
var ke = "[^/]+";
var pe = ".*";
var be = "(?:|/.*)";
var ae = Symbol();
var Gt = new Set(".\\+*[^]$()");
function Xt(e, t) {
  return e.length === 1 ? t.length === 1 ? e < t ? -1 : 1 : -1 : t.length === 1 || e === pe || e === be ? 1 : t === pe || t === be ? -1 : e === ke ? 1 : t === ke ? -1 : e.length === t.length ? e < t ? -1 : 1 : t.length - e.length;
}
__name(Xt, "Xt");
__name2(Xt, "Xt");
var K;
var J;
var P;
var Ve;
var Me = (Ve = class {
  static {
    __name(this, "Ve");
  }
  static {
    __name2(this, "Ve");
  }
  constructor() {
    m(this, K);
    m(this, J);
    m(this, P, /* @__PURE__ */ Object.create(null));
  }
  insert(t, s, r, a, n) {
    if (t.length === 0) {
      if (i(this, K) !== void 0) throw ae;
      if (n) return;
      g(this, K, s);
      return;
    }
    const [o, ...c] = t, l = o === "*" ? c.length === 0 ? ["", "", pe] : ["", "", ke] : o === "/*" ? ["", "", be] : o.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
    let d;
    if (l) {
      const u = l[1];
      let h = l[2] || ke;
      if (u && l[2] && (h === ".*" || (h = h.replace(/^\((?!\?:)(?=[^)]+\)$)/, "(?:"), /\((?!\?:)/.test(h)))) throw ae;
      if (d = i(this, P)[h], !d) {
        if (Object.keys(i(this, P)).some((b) => b !== pe && b !== be)) throw ae;
        if (n) return;
        d = i(this, P)[h] = new Me(), u !== "" && g(d, J, a.varIndex++);
      }
      !n && u !== "" && r.push([u, i(d, J)]);
    } else if (d = i(this, P)[o], !d) {
      if (Object.keys(i(this, P)).some((u) => u.length > 1 && u !== pe && u !== be)) throw ae;
      if (n) return;
      d = i(this, P)[o] = new Me();
    }
    d.insert(c, s, r, a, n);
  }
  buildRegExpStr() {
    const s = Object.keys(i(this, P)).sort(Xt).map((r) => {
      const a = i(this, P)[r];
      return (typeof i(a, J) == "number" ? `(${r})@${i(a, J)}` : Gt.has(r) ? `\\${r}` : r) + a.buildRegExpStr();
    });
    return typeof i(this, K) == "number" && s.unshift(`#${i(this, K)}`), s.length === 0 ? "" : s.length === 1 ? s[0] : "(?:" + s.join("|") + ")";
  }
}, K = /* @__PURE__ */ new WeakMap(), J = /* @__PURE__ */ new WeakMap(), P = /* @__PURE__ */ new WeakMap(), Ve);
var Re;
var we;
var We;
var Vt = (We = class {
  static {
    __name(this, "We");
  }
  static {
    __name2(this, "We");
  }
  constructor() {
    m(this, Re, { varIndex: 0 });
    m(this, we, new Me());
  }
  insert(e, t, s) {
    const r = [], a = [];
    for (let o = 0; ; ) {
      let c = false;
      if (e = e.replace(/\{[^}]+\}/g, (l) => {
        const d = `@\\${o}`;
        return a[o] = [d, l], o++, c = true, d;
      }), !c) break;
    }
    const n = e.match(/(?::[^\/]+)|(?:\/\*$)|./g) || [];
    for (let o = a.length - 1; o >= 0; o--) {
      const [c] = a[o];
      for (let l = n.length - 1; l >= 0; l--) if (n[l].indexOf(c) !== -1) {
        n[l] = n[l].replace(c, a[o][1]);
        break;
      }
    }
    return i(this, we).insert(n, t, r, i(this, Re), s), r;
  }
  buildRegExp() {
    let e = i(this, we).buildRegExpStr();
    if (e === "") return [/^$/, [], []];
    let t = 0;
    const s = [], r = [];
    return e = e.replace(/#(\d+)|@(\d+)|\.\*\$/g, (a, n, o) => n !== void 0 ? (s[++t] = Number(n), "$()") : (o !== void 0 && (r[Number(o)] = ++t), "")), [new RegExp(`^${e}`), s, r];
  }
}, Re = /* @__PURE__ */ new WeakMap(), we = /* @__PURE__ */ new WeakMap(), We);
var ht = [];
var Wt = [/^$/, [], /* @__PURE__ */ Object.create(null)];
var Ce = /* @__PURE__ */ Object.create(null);
function gt(e) {
  return Ce[e] ?? (Ce[e] = new RegExp(e === "*" ? "" : `^${e.replace(/\/\*$|([.\\+*[^\]$()])/g, (t, s) => s ? `\\${s}` : "(?:|/.*)")}$`));
}
__name(gt, "gt");
__name2(gt, "gt");
function Yt() {
  Ce = /* @__PURE__ */ Object.create(null);
}
__name(Yt, "Yt");
__name2(Yt, "Yt");
function Kt(e) {
  var d;
  const t = new Vt(), s = [];
  if (e.length === 0) return Wt;
  const r = e.map((u) => [!/\*|\/:/.test(u[0]), ...u]).sort(([u, h], [b, y]) => u ? 1 : b ? -1 : h.length - y.length), a = /* @__PURE__ */ Object.create(null);
  for (let u = 0, h = -1, b = r.length; u < b; u++) {
    const [y, E, x] = r[u];
    y ? a[E] = [x.map(([k]) => [k, /* @__PURE__ */ Object.create(null)]), ht] : h++;
    let v;
    try {
      v = t.insert(E, h, y);
    } catch (k) {
      throw k === ae ? new ct(E) : k;
    }
    y || (s[h] = x.map(([k, ee]) => {
      const ue = /* @__PURE__ */ Object.create(null);
      for (ee -= 1; ee >= 0; ee--) {
        const [O, je] = v[ee];
        ue[O] = je;
      }
      return [k, ue];
    }));
  }
  const [n, o, c] = t.buildRegExp();
  for (let u = 0, h = s.length; u < h; u++) for (let b = 0, y = s[u].length; b < y; b++) {
    const E = (d = s[u][b]) == null ? void 0 : d[1];
    if (!E) continue;
    const x = Object.keys(E);
    for (let v = 0, k = x.length; v < k; v++) E[x[v]] = c[E[x[v]]];
  }
  const l = [];
  for (const u in o) l[u] = s[o[u]];
  return [n, l, a];
}
__name(Kt, "Kt");
__name2(Kt, "Kt");
function te(e, t) {
  if (e) {
    for (const s of Object.keys(e).sort((r, a) => a.length - r.length)) if (gt(s).test(t)) return [...e[s]];
  }
}
__name(te, "te");
__name2(te, "te");
var $;
var U;
var de;
var pt;
var bt;
var Ye;
var Jt = (Ye = class {
  static {
    __name(this, "Ye");
  }
  static {
    __name2(this, "Ye");
  }
  constructor() {
    m(this, de);
    p(this, "name", "RegExpRouter");
    m(this, $);
    m(this, U);
    g(this, $, { [w]: /* @__PURE__ */ Object.create(null) }), g(this, U, { [w]: /* @__PURE__ */ Object.create(null) });
  }
  add(e, t, s) {
    var c;
    const r = i(this, $), a = i(this, U);
    if (!r || !a) throw new Error(lt);
    r[e] || [r, a].forEach((l) => {
      l[e] = /* @__PURE__ */ Object.create(null), Object.keys(l[w]).forEach((d) => {
        l[e][d] = [...l[w][d]];
      });
    }), t === "/*" && (t = "*");
    const n = (t.match(/\/:/g) || []).length;
    if (/\*$/.test(t)) {
      const l = gt(t);
      e === w ? Object.keys(r).forEach((d) => {
        var u;
        (u = r[d])[t] || (u[t] = te(r[d], t) || te(r[w], t) || []);
      }) : (c = r[e])[t] || (c[t] = te(r[e], t) || te(r[w], t) || []), Object.keys(r).forEach((d) => {
        (e === w || e === d) && Object.keys(r[d]).forEach((u) => {
          l.test(u) && r[d][u].push([s, n]);
        });
      }), Object.keys(a).forEach((d) => {
        (e === w || e === d) && Object.keys(a[d]).forEach((u) => l.test(u) && a[d][u].push([s, n]));
      });
      return;
    }
    const o = tt(t) || [t];
    for (let l = 0, d = o.length; l < d; l++) {
      const u = o[l];
      Object.keys(a).forEach((h) => {
        var b;
        (e === w || e === h) && ((b = a[h])[u] || (b[u] = [...te(r[h], u) || te(r[w], u) || []]), a[h][u].push([s, n - d + l + 1]));
      });
    }
  }
  match(e, t) {
    Yt();
    const s = f(this, de, pt).call(this);
    return this.match = (r, a) => {
      const n = s[r] || s[w], o = n[2][a];
      if (o) return o;
      const c = a.match(n[0]);
      if (!c) return [[], ht];
      const l = c.indexOf("", 1);
      return [n[1][l], c];
    }, this.match(e, t);
  }
}, $ = /* @__PURE__ */ new WeakMap(), U = /* @__PURE__ */ new WeakMap(), de = /* @__PURE__ */ new WeakSet(), pt = /* @__PURE__ */ __name2(function() {
  const e = /* @__PURE__ */ Object.create(null);
  return Object.keys(i(this, U)).concat(Object.keys(i(this, $))).forEach((t) => {
    e[t] || (e[t] = f(this, de, bt).call(this, t));
  }), g(this, $, g(this, U, void 0)), e;
}, "pt"), bt = /* @__PURE__ */ __name2(function(e) {
  const t = [];
  let s = e === w;
  return [i(this, $), i(this, U)].forEach((r) => {
    const a = r[e] ? Object.keys(r[e]).map((n) => [n, r[e][n]]) : [];
    a.length !== 0 ? (s || (s = true), t.push(...a)) : e !== w && t.push(...Object.keys(r[w]).map((n) => [n, r[w][n]]));
  }), s ? Kt(t) : null;
}, "bt"), Ye);
var z;
var _;
var Ke;
var Qt = (Ke = class {
  static {
    __name(this, "Ke");
  }
  static {
    __name2(this, "Ke");
  }
  constructor(e) {
    p(this, "name", "SmartRouter");
    m(this, z, []);
    m(this, _, []);
    g(this, z, e.routers);
  }
  add(e, t, s) {
    if (!i(this, _)) throw new Error(lt);
    i(this, _).push([e, t, s]);
  }
  match(e, t) {
    if (!i(this, _)) throw new Error("Fatal error");
    const s = i(this, z), r = i(this, _), a = s.length;
    let n = 0, o;
    for (; n < a; n++) {
      const c = s[n];
      try {
        for (let l = 0, d = r.length; l < d; l++) c.add(...r[l]);
        o = c.match(e, t);
      } catch (l) {
        if (l instanceof ct) continue;
        throw l;
      }
      this.match = c.match.bind(c), g(this, z, [c]), g(this, _, void 0);
      break;
    }
    if (n === a) throw new Error("Fatal error");
    return this.name = `SmartRouter + ${this.activeRouter.name}`, o;
  }
  get activeRouter() {
    if (i(this, _) || i(this, z).length !== 1) throw new Error("No active router has been determined yet.");
    return i(this, z)[0];
  }
}, z = /* @__PURE__ */ new WeakMap(), _ = /* @__PURE__ */ new WeakMap(), Ke);
var ge = /* @__PURE__ */ Object.create(null);
var G;
var C;
var Q;
var ce;
var A;
var B;
var W;
var Je;
var mt = (Je = class {
  static {
    __name(this, "Je");
  }
  static {
    __name2(this, "Je");
  }
  constructor(e, t, s) {
    m(this, B);
    m(this, G);
    m(this, C);
    m(this, Q);
    m(this, ce, 0);
    m(this, A, ge);
    if (g(this, C, s || /* @__PURE__ */ Object.create(null)), g(this, G, []), e && t) {
      const r = /* @__PURE__ */ Object.create(null);
      r[e] = { handler: t, possibleKeys: [], score: 0 }, g(this, G, [r]);
    }
    g(this, Q, []);
  }
  insert(e, t, s) {
    g(this, ce, ++He(this, ce)._);
    let r = this;
    const a = Tt(t), n = [];
    for (let o = 0, c = a.length; o < c; o++) {
      const l = a[o], d = a[o + 1], u = Dt(l, d), h = Array.isArray(u) ? u[0] : l;
      if (h in i(r, C)) {
        r = i(r, C)[h], u && n.push(u[1]);
        continue;
      }
      i(r, C)[h] = new mt(), u && (i(r, Q).push(u), n.push(u[1])), r = i(r, C)[h];
    }
    return i(r, G).push({ [e]: { handler: s, possibleKeys: n.filter((o, c, l) => l.indexOf(o) === c), score: i(this, ce) } }), r;
  }
  search(e, t) {
    var c;
    const s = [];
    g(this, A, ge);
    let a = [this];
    const n = Ze(t), o = [];
    for (let l = 0, d = n.length; l < d; l++) {
      const u = n[l], h = l === d - 1, b = [];
      for (let y = 0, E = a.length; y < E; y++) {
        const x = a[y], v = i(x, C)[u];
        v && (g(v, A, i(x, A)), h ? (i(v, C)["*"] && s.push(...f(this, B, W).call(this, i(v, C)["*"], e, i(x, A))), s.push(...f(this, B, W).call(this, v, e, i(x, A)))) : b.push(v));
        for (let k = 0, ee = i(x, Q).length; k < ee; k++) {
          const ue = i(x, Q)[k], O = i(x, A) === ge ? {} : { ...i(x, A) };
          if (ue === "*") {
            const L = i(x, C)["*"];
            L && (s.push(...f(this, B, W).call(this, L, e, i(x, A))), g(L, A, O), b.push(L));
            continue;
          }
          const [je, _e, he] = ue;
          if (!u && !(he instanceof RegExp)) continue;
          const D = i(x, C)[je], wt = n.slice(l).join("/");
          if (he instanceof RegExp) {
            const L = he.exec(wt);
            if (L) {
              if (O[_e] = L[0], s.push(...f(this, B, W).call(this, D, e, i(x, A), O)), Object.keys(i(D, C)).length) {
                g(D, A, O);
                const Ie = ((c = L[0].match(/\//)) == null ? void 0 : c.length) ?? 0;
                (o[Ie] || (o[Ie] = [])).push(D);
              }
              continue;
            }
          }
          (he === true || he.test(u)) && (O[_e] = u, h ? (s.push(...f(this, B, W).call(this, D, e, O, i(x, A))), i(D, C)["*"] && s.push(...f(this, B, W).call(this, i(D, C)["*"], e, O, i(x, A)))) : (g(D, A, O), b.push(D)));
        }
      }
      a = b.concat(o.shift() ?? []);
    }
    return s.length > 1 && s.sort((l, d) => l.score - d.score), [s.map(({ handler: l, params: d }) => [l, d])];
  }
}, G = /* @__PURE__ */ new WeakMap(), C = /* @__PURE__ */ new WeakMap(), Q = /* @__PURE__ */ new WeakMap(), ce = /* @__PURE__ */ new WeakMap(), A = /* @__PURE__ */ new WeakMap(), B = /* @__PURE__ */ new WeakSet(), W = /* @__PURE__ */ __name2(function(e, t, s, r) {
  const a = [];
  for (let n = 0, o = i(e, G).length; n < o; n++) {
    const c = i(e, G)[n], l = c[t] || c[w], d = {};
    if (l !== void 0 && (l.params = /* @__PURE__ */ Object.create(null), a.push(l), s !== ge || r && r !== ge)) for (let u = 0, h = l.possibleKeys.length; u < h; u++) {
      const b = l.possibleKeys[u], y = d[l.score];
      l.params[b] = r != null && r[b] && !y ? r[b] : s[b] ?? (r == null ? void 0 : r[b]), d[l.score] = true;
    }
  }
  return a;
}, "W"), Je);
var Z;
var Qe;
var Zt = (Qe = class {
  static {
    __name(this, "Qe");
  }
  static {
    __name2(this, "Qe");
  }
  constructor() {
    p(this, "name", "TrieRouter");
    m(this, Z);
    g(this, Z, new mt());
  }
  add(e, t, s) {
    const r = tt(t);
    if (r) {
      for (let a = 0, n = r.length; a < n; a++) i(this, Z).insert(e, r[a], s);
      return;
    }
    i(this, Z).insert(e, t, s);
  }
  match(e, t) {
    return i(this, Z).search(e, t);
  }
}, Z = /* @__PURE__ */ new WeakMap(), Qe);
var ft = class extends dt {
  static {
    __name(this, "ft");
  }
  static {
    __name2(this, "ft");
  }
  constructor(e = {}) {
    super(e), this.router = e.router ?? new Qt({ routers: [new Jt(), new Zt()] });
  }
};
var es = /* @__PURE__ */ __name2((e) => {
  const s = { ...{ origin: "*", allowMethods: ["GET", "HEAD", "PUT", "POST", "DELETE", "PATCH"], allowHeaders: [], exposeHeaders: [] }, ...e }, r = /* @__PURE__ */ ((n) => typeof n == "string" ? n === "*" ? () => n : (o) => n === o ? o : null : typeof n == "function" ? n : (o) => n.includes(o) ? o : null)(s.origin), a = ((n) => typeof n == "function" ? n : Array.isArray(n) ? () => n : () => [])(s.allowMethods);
  return async function(o, c) {
    var u;
    function l(h, b) {
      o.res.headers.set(h, b);
    }
    __name(l, "l");
    __name2(l, "l");
    const d = await r(o.req.header("origin") || "", o);
    if (d && l("Access-Control-Allow-Origin", d), s.origin !== "*") {
      const h = o.req.header("Vary");
      h ? l("Vary", h) : l("Vary", "Origin");
    }
    if (s.credentials && l("Access-Control-Allow-Credentials", "true"), (u = s.exposeHeaders) != null && u.length && l("Access-Control-Expose-Headers", s.exposeHeaders.join(",")), o.req.method === "OPTIONS") {
      s.maxAge != null && l("Access-Control-Max-Age", s.maxAge.toString());
      const h = await a(o.req.header("origin") || "", o);
      h.length && l("Access-Control-Allow-Methods", h.join(","));
      let b = s.allowHeaders;
      if (!(b != null && b.length)) {
        const y = o.req.header("Access-Control-Request-Headers");
        y && (b = y.split(/\s*,\s*/));
      }
      return b != null && b.length && (l("Access-Control-Allow-Headers", b.join(",")), o.res.headers.append("Vary", "Access-Control-Request-Headers")), o.res.headers.delete("Content-Length"), o.res.headers.delete("Content-Type"), new Response(null, { headers: o.res.headers, status: 204, statusText: "No Content" });
    }
    await c();
  };
}, "es");
var ts = /^\s*(?:text\/(?!event-stream(?:[;\s]|$))[^;\s]+|application\/(?:javascript|json|xml|xml-dtd|ecmascript|dart|postscript|rtf|tar|toml|vnd\.dart|vnd\.ms-fontobject|vnd\.ms-opentype|wasm|x-httpd-php|x-javascript|x-ns-proxy-autoconfig|x-sh|x-tar|x-virtualbox-hdd|x-virtualbox-ova|x-virtualbox-ovf|x-virtualbox-vbox|x-virtualbox-vdi|x-virtualbox-vhd|x-virtualbox-vmdk|x-www-form-urlencoded)|font\/(?:otf|ttf)|image\/(?:bmp|vnd\.adobe\.photoshop|vnd\.microsoft\.icon|vnd\.ms-dds|x-icon|x-ms-bmp)|message\/rfc822|model\/gltf-binary|x-shader\/x-fragment|x-shader\/x-vertex|[^;\s]+?\+(?:json|text|xml|yaml))(?:[;\s]|$)/i;
var $e = /* @__PURE__ */ __name2((e, t = rs) => {
  const s = /\.([a-zA-Z0-9]+?)$/, r = e.match(s);
  if (!r) return;
  let a = t[r[1]];
  return a && a.startsWith("text") && (a += "; charset=utf-8"), a;
}, "$e");
var ss = { aac: "audio/aac", avi: "video/x-msvideo", avif: "image/avif", av1: "video/av1", bin: "application/octet-stream", bmp: "image/bmp", css: "text/css", csv: "text/csv", eot: "application/vnd.ms-fontobject", epub: "application/epub+zip", gif: "image/gif", gz: "application/gzip", htm: "text/html", html: "text/html", ico: "image/x-icon", ics: "text/calendar", jpeg: "image/jpeg", jpg: "image/jpeg", js: "text/javascript", json: "application/json", jsonld: "application/ld+json", map: "application/json", mid: "audio/x-midi", midi: "audio/x-midi", mjs: "text/javascript", mp3: "audio/mpeg", mp4: "video/mp4", mpeg: "video/mpeg", oga: "audio/ogg", ogv: "video/ogg", ogx: "application/ogg", opus: "audio/opus", otf: "font/otf", pdf: "application/pdf", png: "image/png", rtf: "application/rtf", svg: "image/svg+xml", tif: "image/tiff", tiff: "image/tiff", ts: "video/mp2t", ttf: "font/ttf", txt: "text/plain", wasm: "application/wasm", webm: "video/webm", weba: "audio/webm", webmanifest: "application/manifest+json", webp: "image/webp", woff: "font/woff", woff2: "font/woff2", xhtml: "application/xhtml+xml", xml: "application/xml", zip: "application/zip", "3gp": "video/3gpp", "3g2": "video/3gpp2", gltf: "model/gltf+json", glb: "model/gltf-binary" };
var rs = ss;
var as = /* @__PURE__ */ __name2((...e) => {
  let t = e.filter((a) => a !== "").join("/");
  t = t.replace(new RegExp("(?<=\\/)\\/+", "g"), "");
  const s = t.split("/"), r = [];
  for (const a of s) a === ".." && r.length > 0 && r.at(-1) !== ".." ? r.pop() : a !== "." && r.push(a);
  return r.join("/") || ".";
}, "as");
var xt = { br: ".br", zstd: ".zst", gzip: ".gz" };
var ns = Object.keys(xt);
var os = "index.html";
var is = /* @__PURE__ */ __name2((e) => {
  const t = e.root ?? "./", s = e.path, r = e.join ?? as;
  return async (a, n) => {
    var u, h, b, y;
    if (a.finalized) return n();
    let o;
    if (e.path) o = e.path;
    else try {
      if (o = decodeURIComponent(a.req.path), /(?:^|[\/\\])\.\.(?:$|[\/\\])/.test(o)) throw new Error();
    } catch {
      return await ((u = e.onNotFound) == null ? void 0 : u.call(e, a.req.path, a)), n();
    }
    let c = r(t, !s && e.rewriteRequestPath ? e.rewriteRequestPath(o) : o);
    e.isDir && await e.isDir(c) && (c = r(c, os));
    const l = e.getContent;
    let d = await l(c, a);
    if (d instanceof Response) return a.newResponse(d.body, d);
    if (d) {
      const E = e.mimes && $e(c, e.mimes) || $e(c);
      if (a.header("Content-Type", E || "application/octet-stream"), e.precompressed && (!E || ts.test(E))) {
        const x = new Set((h = a.req.header("Accept-Encoding")) == null ? void 0 : h.split(",").map((v) => v.trim()));
        for (const v of ns) {
          if (!x.has(v)) continue;
          const k = await l(c + xt[v], a);
          if (k) {
            d = k, a.header("Content-Encoding", v), a.header("Vary", "Accept-Encoding", { append: true });
            break;
          }
        }
      }
      return await ((b = e.onFound) == null ? void 0 : b.call(e, c, a)), a.body(d);
    }
    await ((y = e.onNotFound) == null ? void 0 : y.call(e, c, a)), await n();
  };
}, "is");
var ls = /* @__PURE__ */ __name2(async (e, t) => {
  let s;
  t && t.manifest ? typeof t.manifest == "string" ? s = JSON.parse(t.manifest) : s = t.manifest : typeof __STATIC_CONTENT_MANIFEST == "string" ? s = JSON.parse(__STATIC_CONTENT_MANIFEST) : s = __STATIC_CONTENT_MANIFEST;
  let r;
  t && t.namespace ? r = t.namespace : r = __STATIC_CONTENT;
  const a = s[e] || e;
  if (!a) return null;
  const n = await r.get(a, { type: "stream" });
  return n || null;
}, "ls");
var cs = /* @__PURE__ */ __name2((e) => async function(s, r) {
  return is({ ...e, getContent: /* @__PURE__ */ __name2(async (n) => ls(n, { manifest: e.manifest, namespace: e.namespace ? e.namespace : s.env ? s.env.__STATIC_CONTENT : void 0 }), "getContent") })(s, r);
}, "cs");
var ds = /* @__PURE__ */ __name2((e) => cs(e), "ds");
var X = new ft();
X.use("/api/*", es());
X.use("/static/*", ds({ root: "./public" }));
async function yt(e, t = "1y") {
  try {
    const s = `https://query1.finance.yahoo.com/v8/finance/chart/${e}?period1=0&period2=9999999999&interval=1d&includePrePost=true&events=div%2Csplit`, r = await fetch(s, { headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" } });
    if (!r.ok) throw new Error(`HTTP error! status: ${r.status}`);
    const a = await r.json();
    if (!a.chart || !a.chart.result || a.chart.result.length === 0) throw new Error("No data found for this symbol");
    const n = a.chart.result[0], o = n.timestamp, c = n.indicators.quote[0], l = o.map((d, u) => {
      var h, b, y, E;
      return { date: new Date(d * 1e3).toISOString().split("T")[0], open: ((h = c.open[u]) == null ? void 0 : h.toFixed(2)) || "N/A", high: ((b = c.high[u]) == null ? void 0 : b.toFixed(2)) || "N/A", low: ((y = c.low[u]) == null ? void 0 : y.toFixed(2)) || "N/A", close: ((E = c.close[u]) == null ? void 0 : E.toFixed(2)) || "N/A", volume: c.volume[u] || "N/A" };
    }).filter((d) => d.close !== "N/A").reverse();
    return { symbol: n.meta.symbol, companyName: n.meta.symbol, currency: n.meta.currency, exchangeName: n.meta.exchangeName, data: l };
  } catch (s) {
    throw console.error("Error fetching Yahoo Finance data:", s), s;
  }
}
__name(yt, "yt");
__name2(yt, "yt");
async function us(e) {
  var t;
  try {
    const s = `https://query2.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(e)}&newsCount=0&listsCount=0`, r = await fetch(s, { headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" } });
    if (!r.ok) throw new Error(`HTTP error! status: ${r.status}`);
    return ((t = (await r.json()).quotes) == null ? void 0 : t.map((n) => ({ symbol: n.symbol, shortname: n.shortname || n.longname || n.symbol, longname: n.longname || n.shortname || n.symbol, exchDisp: n.exchDisp || "Unknown", typeDisp: n.typeDisp || "Stock" }))) || [];
  } catch (s) {
    return console.error("Error searching symbols:", s), [];
  }
}
__name(us, "us");
__name2(us, "us");
X.get("/api/search/:query", async (e) => {
  try {
    const t = e.req.param("query");
    if (!t || t.length < 2) return e.json({ error: "Query must be at least 2 characters long" }, 400);
    const s = await us(t);
    return e.json({ success: true, query: t, results: s.slice(0, 10) });
  } catch (t) {
    return e.json({ error: "Failed to search companies", details: t instanceof Error ? t.message : "Unknown error" }, 500);
  }
});
X.get("/api/stock/:symbol", async (e) => {
  try {
    const t = e.req.param("symbol").toUpperCase();
    if (!t) return e.json({ error: "Symbol parameter is required" }, 400);
    const s = await yt(t);
    return e.json({ success: true, symbol: t, totalDays: s.data.length, ...s });
  } catch (t) {
    return e.json({ error: "Failed to fetch stock data", details: t instanceof Error ? t.message : "Unknown error" }, 500);
  }
});
X.get("/api/stock/:symbol/range", async (e) => {
  try {
    const t = e.req.param("symbol").toUpperCase(), s = e.req.query("start"), r = e.req.query("end");
    if (!t) return e.json({ error: "Symbol parameter is required" }, 400);
    const a = await yt(t);
    let n = a.data;
    return s && (n = n.filter((o) => o.date >= s)), r && (n = n.filter((o) => o.date <= r)), e.json({ success: true, symbol: t, startDate: s, endDate: r, totalDays: n.length, ...a, data: n });
  } catch (t) {
    return e.json({ error: "Failed to fetch stock data", details: t instanceof Error ? t.message : "Unknown error" }, 500);
  }
});
X.get("/api/status", (e) => e.json({ success: true, message: "Financial Data API is running", endpoints: { search: "/api/search/:query", stock: "/api/stock/:symbol", stockRange: "/api/stock/:symbol/range?start=YYYY-MM-DD&end=YYYY-MM-DD" }, version: "1.0.0" }));
X.get("/", (e) => e.html(`
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Amindis Equity Oracle</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"><\/script>
        <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns@2.0.0/dist/chartjs-adapter-date-fns.bundle.min.js"><\/script>
        <link href="/static/style.css" rel="stylesheet">
        <script src="/static/european-stocks.js"><\/script>
        <script src="/static/european-stocks-extended.js"><\/script>
        <script src="/static/european-stocks-complete.js"><\/script>
        <script src="/static/financial-calculations-academic.js"><\/script>
        <script src="/static/financial-analytics.js"><\/script>
        <script src="/static/market-data.js"><\/script>
    </head>
    <body class="financial-theme">
        <div class="min-h-screen">
            <!-- Header -->
            <header class="bg-white shadow-lg border-b border-gray-200">
                <div class="max-w-7xl mx-auto px-4 py-6">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center space-x-3">
                            <i class="fas fa-chart-line text-3xl text-blue-600"></i>
                            <h1 class="text-3xl font-bold text-gray-800">Amindis Equity Oracle</h1>
                        </div>
                        <div class="text-sm text-gray-500">
                            <i class="fas fa-database mr-1"></i>
                            Donn\xE9es historiques en temps r\xE9el
                        </div>
                    </div>
                </div>
            </header>

            <!-- Navigation Buttons - Visible on all pages -->
            <nav class="bg-gray-50 border-b border-gray-200 py-4">
                <div class="max-w-7xl mx-auto px-4">
                    <div class="flex justify-center">
                        <div class="bg-white rounded-lg shadow-lg p-1 inline-flex space-x-1">
                            <button id="navHome" onclick="showHome()" class="px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors">
                                <i class="fas fa-home mr-2"></i>Accueil
                            </button>
                            <button id="navStockAnalyst" onclick="showStockAnalyst()" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-blue-100 hover:text-blue-700 transition-colors">
                                <i class="fas fa-chart-line mr-2"></i>Stock Analyst
                            </button>
                            <button class="px-4 py-2 bg-gray-100 text-gray-500 rounded-lg font-medium cursor-not-allowed" disabled>
                                <i class="fas fa-cogs mr-2"></i>En D\xE9veloppement
                            </button>
                            <button class="px-4 py-2 bg-gray-100 text-gray-500 rounded-lg font-medium cursor-not-allowed" disabled>
                                <i class="fas fa-tools mr-2"></i>En D\xE9veloppement
                            </button>
                        </div>
                    </div>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="w-full px-2 py-8">
                <!-- Dashboard Section (Page d'accueil) -->
                <div id="dashboardSection" class="space-y-8">
                    <!-- Barre de recherche principale sur l'accueil -->
                    <div class="bg-white rounded-lg shadow-lg p-6">
                        <div class="flex items-center justify-between mb-4">
                            <h2 class="text-xl font-semibold text-gray-800">
                                <i class="fas fa-search mr-3"></i>
                                Recherche Rapide d'Actions
                            </h2>
                            <button id="showAdvancedSearch" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                                <i class="fas fa-cog mr-2"></i>Recherche Avanc\xE9e
                            </button>
                        </div>
                        
                        <!-- Barre de recherche simple -->
                        <div class="flex space-x-4 mb-4">
                            <div class="flex-1 relative">
                                <input 
                                    type="text" 
                                    id="quickSearchInput" 
                                    placeholder="Recherche rapide : AAPL, RNO.PA, SAP.DE..."
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                >
                                <div id="quickSearchSuggestions" class="absolute z-20 w-full bg-white border border-gray-300 rounded-lg mt-1 hidden shadow-lg max-h-60 overflow-y-auto">
                                </div>
                            </div>
                            <button 
                                id="quickSearchBtn" 
                                class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
                            >
                                <i class="fas fa-search mr-2"></i>
                                Analyser
                            </button>
                        </div>

                        <!-- S\xE9lecteurs rapides d'indices -->
                        <div class="flex flex-wrap gap-2">
                            <button id="quickCAC40" class="px-3 py-2 bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 transition-colors text-sm">
                                <i class="fas fa-flag mr-1"></i>\u{1F1EB}\u{1F1F7} CAC 40
                            </button>
                            <button id="quickDAX30" class="px-3 py-2 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 transition-colors text-sm">
                                <i class="fas fa-flag mr-1"></i>\u{1F1E9}\u{1F1EA} DAX 30
                            </button>
                            <button id="quickIBEX35" class="px-3 py-2 bg-red-100 text-red-800 rounded-lg hover:bg-red-200 transition-colors text-sm">
                                <i class="fas fa-flag mr-1"></i>\u{1F1EA}\u{1F1F8} IBEX 35
                            </button>
                            <button id="quickFTSE100" class="px-3 py-2 bg-purple-100 text-purple-800 rounded-lg hover:bg-purple-200 transition-colors text-sm">
                                <i class="fas fa-flag mr-1"></i>\u{1F1EC}\u{1F1E7} FTSE 100
                            </button>
                            <button id="quickAEX25" class="px-3 py-2 bg-orange-100 text-orange-800 rounded-lg hover:bg-orange-200 transition-colors text-sm">
                                <i class="fas fa-flag mr-1"></i>\u{1F1F3}\u{1F1F1} AEX 25
                            </button>
                        </div>
                    </div>
                    <!-- Indices Boursiers Mondiaux -->
                    <div class="bg-white rounded-lg shadow-lg p-6">
                        <div class="flex items-center justify-between mb-6">
                            <h2 class="text-2xl font-bold text-gray-800">
                                <i class="fas fa-globe mr-3"></i>
                                Indices Boursiers Mondiaux
                            </h2>
                            <div class="text-sm text-gray-500">
                                <i class="fas fa-sync-alt mr-1"></i>
                                Temps r\xE9el
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                            <!-- \xC9tats-Unis -->
                            <div class="bg-blue-50 rounded-lg p-4">
                                <h3 class="text-lg font-semibold text-blue-800 mb-3">
                                    <i class="fas fa-flag-usa mr-2"></i>\xC9tats-Unis
                                </h3>
                                <div id="usIndices" class="space-y-2">
                                    <!-- Will be populated by JavaScript -->
                                </div>
                            </div>

                            <!-- Europe -->
                            <div class="bg-green-50 rounded-lg p-4">
                                <h3 class="text-lg font-semibold text-green-800 mb-3">
                                    <i class="fas fa-flag mr-2"></i>Europe
                                </h3>
                                <div id="euIndices" class="space-y-2">
                                    <!-- Will be populated by JavaScript -->
                                </div>
                            </div>

                            <!-- Asie -->
                            <div class="bg-red-50 rounded-lg p-4">
                                <h3 class="text-lg font-semibold text-red-800 mb-3">
                                    <i class="fas fa-torii-gate mr-2"></i>Asie
                                </h3>
                                <div id="asiaIndices" class="space-y-2">
                                    <!-- Will be populated by JavaScript -->
                                </div>
                            </div>
                        </div>

                        <!-- Graphique des indices principaux -->
                        <div class="border-t pt-6">
                            <h4 class="text-lg font-semibold text-gray-800 mb-4">
                                <i class="fas fa-chart-line mr-2"></i>
                                Performance des Indices Principaux
                            </h4>
                            <div class="relative" style="height: 300px;">
                                <canvas id="indicesChart"></canvas>
                            </div>
                        </div>
                    </div>

                    <!-- Matrice Pays / Secteurs Europ\xE9ens -->
                    <div class="bg-white rounded-lg shadow-lg p-6">
                        <h2 class="text-2xl font-bold text-gray-800 mb-6">
                            <i class="fas fa-th-large mr-3"></i>
                            Matrice Europ\xE9enne Pays / Secteurs
                        </h2>
                        
                        <!-- S\xE9lecteurs de filtres -->
                        <div class="flex flex-wrap gap-2 mb-6">
                            <button id="matrixShowAll" class="matrix-filter-btn px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-sm font-medium">
                                <i class="fas fa-globe mr-1"></i>Toute l'Europe (15 march\xE9s)
                            </button>
                            <button id="matrixShowFrance" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                \u{1F1EB}\u{1F1F7} France
                            </button>
                            <button id="matrixShowGermany" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                \u{1F1E9}\u{1F1EA} Allemagne
                            </button>
                            <button id="matrixShowSpain" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                \u{1F1EA}\u{1F1F8} Espagne
                            </button>
                            <button id="matrixShowItaly" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                \u{1F1EE}\u{1F1F9} Italie
                            </button>
                            <button id="matrixShowNetherlands" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                \u{1F1F3}\u{1F1F1} Pays-Bas
                            </button>
                            <button id="matrixShowBelgium" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                \u{1F1E7}\u{1F1EA} Belgique
                            </button>
                            <button id="matrixShowUK" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                \u{1F1EC}\u{1F1E7} Royaume-Uni
                            </button>
                            <button id="matrixShowSwitzerland" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                \u{1F1E8}\u{1F1ED} Suisse
                            </button>
                            <button id="matrixShowSweden" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                \u{1F1F8}\u{1F1EA} Su\xE8de
                            </button>
                            <button id="matrixShowNorway" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                \u{1F1F3}\u{1F1F4} Norv\xE8ge
                            </button>
                            <button id="matrixShowFinland" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                \u{1F1EB}\u{1F1EE} Finlande
                            </button>
                            <button id="matrixShowDenmark" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                \u{1F1E9}\u{1F1F0} Danemark
                            </button>
                            <button id="matrixShowAustria" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                \u{1F1E6}\u{1F1F9} Autriche
                            </button>
                            <button id="matrixShowPoland" class="matrix-filter-btn px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                \u{1F1F5}\u{1F1F1} Pologne
                            </button>
                        </div>

                        <!-- Tableau matriciel -->
                        <div class="overflow-x-auto">
                            <div class="text-sm text-gray-600 mb-3">
                                <i class="fas fa-info-circle mr-1"></i>
                                Cliquez sur une entreprise pour l'analyser
                            </div>
                            <table id="sectorCountryMatrix" class="min-w-full border-collapse border border-gray-300">
                                <thead>
                                    <tr class="bg-gray-50">
                                        <th class="border border-gray-300 px-4 py-3 text-left font-semibold text-gray-800">
                                            <i class="fas fa-industry mr-2"></i>Secteur STOXX
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            \u{1F1EB}\u{1F1F7}<br><span class="text-xs">France</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            \u{1F1E9}\u{1F1EA}<br><span class="text-xs">Allemagne</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            \u{1F1EA}\u{1F1F8}<br><span class="text-xs">Espagne</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            \u{1F1EE}\u{1F1F9}<br><span class="text-xs">Italie</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            \u{1F1F3}\u{1F1F1}<br><span class="text-xs">Pays-Bas</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            \u{1F1E7}\u{1F1EA}<br><span class="text-xs">Belgique</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            \u{1F1EC}\u{1F1E7}<br><span class="text-xs">Royaume-Uni</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            \u{1F1E8}\u{1F1ED}<br><span class="text-xs">Suisse</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            \u{1F1F8}\u{1F1EA}<br><span class="text-xs">Su\xE8de</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            \u{1F1F3}\u{1F1F4}<br><span class="text-xs">Norv\xE8ge</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            \u{1F1EB}\u{1F1EE}<br><span class="text-xs">Finlande</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            \u{1F1E9}\u{1F1F0}<br><span class="text-xs">Danemark</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            \u{1F1E6}\u{1F1F9}<br><span class="text-xs">Autriche</span>
                                        </th>
                                        <th class="border border-gray-300 px-3 py-3 text-center font-semibold text-gray-800 min-w-20">
                                            \u{1F1F5}\u{1F1F1}<br><span class="text-xs">Pologne</span>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody id="matrixTableBody">
                                    <!-- Will be populated by JavaScript -->
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="mt-4 text-xs text-gray-500">
                            <p><strong>Couverture :</strong> 15 march\xE9s europ\xE9ens - CAC 40 \u{1F1EB}\u{1F1F7}, DAX 30 \u{1F1E9}\u{1F1EA}, IBEX 35 \u{1F1EA}\u{1F1F8}, FTSE MIB 40 \u{1F1EE}\u{1F1F9}, AEX 25 \u{1F1F3}\u{1F1F1}, BEL 20 \u{1F1E7}\u{1F1EA}, FTSE 100 \u{1F1EC}\u{1F1E7}, SMI \u{1F1E8}\u{1F1ED}, OMX Stockholm \u{1F1F8}\u{1F1EA}, OBX \u{1F1F3}\u{1F1F4}, OMX Helsinki \u{1F1EB}\u{1F1EE}, OMX Copenhagen \u{1F1E9}\u{1F1F0}, ATX \u{1F1E6}\u{1F1F9}, PSI \u{1F1F5}\u{1F1F9}, WIG \u{1F1F5}\u{1F1F1}</p>
                            <p><strong>Plus de 200 entreprises europ\xE9ennes</strong> avec classification sectorielle STOXX</p>
                        </div>
                    </div>
                </div>

                <!-- Search Section -->
                <div id="searchSection" class="bg-white rounded-lg shadow-lg p-6 mb-8 hidden">
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center">
                            <i class="fas fa-search text-xl text-blue-600 mr-3"></i>
                            <h2 class="text-xl font-semibold text-gray-800">Rechercher une entreprise</h2>
                        </div>
                        <button id="backToDashboard" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
                            <i class="fas fa-home mr-2"></i>Retour au tableau de bord
                        </button>
                    </div>
                    
                    <!-- S\xE9lecteurs rapides d'indices -->
                    <div class="flex flex-wrap gap-2 mb-4">
                        <button id="showCAC40" class="px-3 py-2 bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 transition-colors text-sm">
                            <i class="fas fa-list mr-1"></i>
                            CAC 40 (40 valeurs)
                        </button>
                        <button id="showDAX30" class="px-3 py-2 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 transition-colors text-sm">
                            <i class="fas fa-list mr-1"></i>
                            DAX 30 (30 valeurs)
                        </button>
                        <button id="showAllEuropean" class="px-3 py-2 bg-purple-100 text-purple-800 rounded-lg hover:bg-purple-200 transition-colors text-sm">
                            <i class="fas fa-globe-europe mr-1"></i>
                            Toutes les valeurs (70 valeurs)
                        </button>
                        <button id="clearSelection" class="px-3 py-2 bg-gray-100 text-gray-800 rounded-lg hover:bg-gray-200 transition-colors text-sm">
                            <i class="fas fa-times mr-1"></i>
                            Effacer
                        </button>
                    </div>

                    <div class="flex space-x-4">
                        <div class="flex-1 relative">
                            <input 
                                type="text" 
                                id="searchInput" 
                                placeholder="Tapez 2-3 lettres pour voir les suggestions CAC40/DAX30, ou recherche globale..."
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            >
                            <div id="searchSuggestions" class="absolute z-20 w-full bg-white border border-gray-300 rounded-lg mt-1 hidden shadow-lg max-h-80 overflow-y-auto">
                            </div>
                        </div>
                        <button 
                            id="searchBtn" 
                            class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
                        >
                            <i class="fas fa-search mr-2"></i>
                            Rechercher
                        </button>
                    </div>

                    <!-- Date Range Filter -->
                    <div class="mt-4 flex space-x-4 items-center">
                        <label class="text-sm font-medium text-gray-700">Filtrer par p\xE9riode :</label>
                        <input 
                            type="date" 
                            id="startDate" 
                            class="px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                        >
                        <span class="text-gray-500">\xE0</span>
                        <input 
                            type="date" 
                            id="endDate" 
                            class="px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                        >
                        <button 
                            id="filterBtn" 
                            class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors"
                        >
                            <i class="fas fa-filter mr-1"></i>
                            Filtrer
                        </button>
                    </div>
                </div>

                <!-- Loading State -->
                <div id="loadingState" class="hidden bg-white rounded-lg shadow-lg p-8 text-center">
                    <i class="fas fa-spinner fa-spin text-3xl text-blue-600 mb-4"></i>
                    <p class="text-gray-600">Chargement des donn\xE9es financi\xE8res...</p>
                </div>

                <!-- Results Section -->
                <div id="resultsSection" class="hidden bg-white rounded-lg shadow-lg">
                    <!-- Company Info -->
                    <div class="p-6 border-b border-gray-200">
                        <div id="companyInfo" class="flex items-center justify-between">
                            <div>
                                <h3 id="companyName" class="text-2xl font-bold text-gray-800"></h3>
                                <p id="companyDetails" class="text-gray-600"></p>
                            </div>
                            <div class="text-right">
                                <p class="text-sm text-gray-500">Total de jours</p>
                                <p id="totalDays" class="text-2xl font-bold text-blue-600"></p>
                            </div>
                        </div>
                    </div>

                    <!-- Price Chart -->
                    <div class="p-6 border-b border-gray-200">
                        <div class="flex items-center justify-between mb-4">
                            <h4 class="text-lg font-semibold text-gray-800">
                                <i class="fas fa-chart-area mr-2"></i>
                                \xC9volution des prix
                            </h4>
                            <div class="text-sm text-gray-600">
                                <span id="chartPeriodInfo">Derniers 90 jours</span>
                            </div>
                        </div>

                        <!-- S\xE9lecteurs de type de graphique -->
                        <div class="flex items-center justify-between mb-4">
                            <div class="flex gap-2">
                                <span class="text-sm font-medium text-gray-700 mr-2">Type :</span>
                                <button id="chartTypeCandlestick" class="chart-type-btn px-3 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors text-sm font-medium">
                                    <i class="fas fa-chart-bar mr-1"></i>Chandeliers
                                </button>
                                <button id="chartTypeLine" class="chart-type-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                    <i class="fas fa-chart-line mr-1"></i>Ligne
                                </button>
                                <button id="chartTypePoints" class="chart-type-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                    <i class="fas fa-circle mr-1"></i>Points
                                </button>
                            </div>
                        </div>

                        <!-- S\xE9lecteurs de p\xE9riode -->
                        <div class="flex flex-wrap gap-2 mb-4">
                            <button id="period3M" class="period-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                3M
                            </button>
                            <button id="period6M" class="period-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                6M
                            </button>
                            <button id="period1Y" class="period-btn px-3 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-sm font-medium">
                                1AN
                            </button>
                            <button id="period2Y" class="period-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                2ANS
                            </button>
                            <button id="period3Y" class="period-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                3ANS
                            </button>
                            <button id="period5Y" class="period-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                5ANS
                            </button>
                            <button id="period10Y" class="period-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                10ANS
                            </button>
                            <button id="periodMax" class="period-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm font-medium">
                                <i class="fas fa-infinity mr-1"></i>MAX
                            </button>
                        </div>

                        <!-- Graphique des prix -->
                        <div class="relative mb-6" style="height: 400px;">
                            <canvas id="priceChart"></canvas>
                        </div>

                        <!-- Graphique des volumes -->
                        <div class="border-t border-gray-600 pt-4">
                            <h5 class="text-md font-semibold text-gray-300 mb-3">
                                <i class="fas fa-chart-bar mr-2"></i>
                                Volume des transactions
                            </h5>
                            <div class="relative" style="height: 150px;">
                                <canvas id="volumeChart"></canvas>
                            </div>
                        </div>
                    </div>

                    <!-- Advanced Metrics Section -->
                    <div class="p-6 border-b border-gray-200">
                        <div class="flex items-center justify-between mb-4">
                            <h4 class="text-lg font-semibold text-gray-800">
                                <i class="fas fa-calculator mr-2"></i>
                                M\xE9triques Financi\xE8res Avanc\xE9es
                            </h4>
                            <div class="flex gap-2">
                                <button id="refreshMetrics" class="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                                    <i class="fas fa-sync-alt mr-1"></i>Recalculer
                                </button>
                                <button id="showBenchmarkChart" class="px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm">
                                    <i class="fas fa-chart-line mr-1"></i>Afficher Benchmarks
                                </button>
                            </div>
                        </div>

                        <!-- Metrics Grid -->
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                            <!-- Volatility Card -->
                            <div class="bg-blue-50 rounded-lg p-4">
                                <h5 class="text-sm font-semibold text-blue-800 mb-2">
                                    <i class="fas fa-chart-line mr-1"></i>Volatilit\xE9 5 ans
                                </h5>
                                <div class="text-2xl font-bold text-blue-600" id="volatility5Y">--</div>
                                <div class="text-xs text-gray-600">Annualis\xE9e</div>
                            </div>

                            <!-- Total Return Card -->
                            <div class="bg-green-50 rounded-lg p-4">
                                <h5 class="text-sm font-semibold text-green-800 mb-2">
                                    <i class="fas fa-trend-up mr-1"></i>Return Total 5 ans
                                </h5>
                                <div class="text-2xl font-bold text-green-600" id="totalReturn5Y">--</div>
                                <div class="text-xs text-gray-600">Cumul\xE9</div>
                            </div>

                            <!-- Correlation Card -->
                            <div class="bg-purple-50 rounded-lg p-4">
                                <h5 class="text-sm font-semibold text-purple-800 mb-2">
                                    <i class="fas fa-link mr-1"></i>Corr\xE9lation Sectorielle
                                </h5>
                                <div class="text-2xl font-bold text-purple-600" id="sectorCorrelation">--</div>
                                <div class="text-xs text-gray-600" id="sectorBenchmarkName">vs Secteur</div>
                            </div>

                            <!-- Tracking Error Card -->
                            <div class="bg-orange-50 rounded-lg p-4">
                                <h5 class="text-sm font-semibold text-orange-800 mb-2">
                                    <i class="fas fa-exclamation-triangle mr-1"></i>Tracking Error
                                </h5>
                                <div class="text-2xl font-bold text-orange-600" id="trackingError">--</div>
                                <div class="text-xs text-gray-600">vs Benchmark Sectoriel</div>
                            </div>
                        </div>

                        <!-- Additional Risk Metrics -->
                        <div class="border-t pt-4">
                            <h5 class="text-md font-semibold text-gray-800 mb-3">
                                <i class="fas fa-shield-alt mr-2"></i>
                                M\xE9triques de Risque Compl\xE9mentaires
                            </h5>
                            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div class="text-center p-3 bg-gray-50 rounded-lg">
                                    <div class="text-sm text-gray-600">Sharpe Ratio</div>
                                    <div class="text-lg font-bold text-gray-800" id="sharpeRatio">--</div>
                                </div>
                                <div class="text-center p-3 bg-gray-50 rounded-lg">
                                    <div class="text-sm text-gray-600">B\xEAta (vs March\xE9)</div>
                                    <div class="text-lg font-bold text-gray-800" id="betaMarket">--</div>
                                </div>
                                <div class="text-center p-3 bg-gray-50 rounded-lg">
                                    <div class="text-sm text-gray-600">Alpha (vs Secteur)</div>
                                    <div class="text-lg font-bold text-gray-800" id="alphaSector">--</div>
                                </div>
                                <div class="text-center p-3 bg-gray-50 rounded-lg">
                                    <div class="text-sm text-gray-600">Drawdown Max</div>
                                    <div class="text-lg font-bold text-gray-800" id="maxDrawdown">--</div>
                                </div>
                            </div>
                        </div>

                        <!-- Benchmark Selection -->
                        <div class="border-t pt-4 mt-4">
                            <h5 class="text-md font-semibold text-gray-800 mb-3">
                                <i class="fas fa-compass mr-2"></i>
                                Benchmarks Disponibles
                            </h5>
                            <div class="flex flex-wrap gap-2">
                                <button id="showNationalBenchmark" class="benchmark-btn px-3 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-sm">
                                    <i class="fas fa-flag mr-1"></i>Benchmark National
                                </button>
                                <button id="showSectorBenchmark" class="benchmark-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-green-100 hover:text-green-700 transition-colors text-sm">
                                    <i class="fas fa-industry mr-1"></i>Benchmark Sectoriel
                                </button>
                                <button id="hideBenchmarks" class="benchmark-btn px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-red-100 hover:text-red-700 transition-colors text-sm">
                                    <i class="fas fa-eye-slash mr-1"></i>Masquer Benchmarks
                                </button>
                            </div>
                            <div class="mt-2 text-xs text-gray-600">
                                <span id="benchmarkInfo">Les benchmarks permettent de comparer la performance relative de l'action.</span>
                            </div>
                        </div>
                    </div>

                    <!-- Data Table -->
                    <div class="p-6">
                        <div class="flex items-center justify-between mb-4">
                            <h4 class="text-lg font-semibold text-gray-800">
                                <i class="fas fa-table mr-2"></i>
                                Donn\xE9es historiques
                            </h4>
                            <div class="flex space-x-2">
                                <button id="exportBtn" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors">
                                    <i class="fas fa-download mr-1"></i>
                                    Exporter CSV
                                </button>
                                <button id="exportExcelBtn" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
                                    <i class="fas fa-file-excel mr-1"></i>
                                    T\xE9l\xE9charger Excel
                                </button>
                                <select id="recordsPerPage" class="px-3 py-2 border border-gray-300 rounded">
                                    <option value="50">50 lignes</option>
                                    <option value="100">100 lignes</option>
                                    <option value="250">250 lignes</option>
                                    <option value="500">500 lignes</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="overflow-x-auto">
                            <table class="min-w-full table-auto border-collapse">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border">Date</th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border">Ouverture</th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border">Plus Haut</th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border">Plus Bas</th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border">Cl\xF4ture</th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border">Volume</th>
                                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border">Variation %</th>
                                    </tr>
                                </thead>
                                <tbody id="dataTableBody" class="bg-white divide-y divide-gray-200">
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <div id="pagination" class="flex items-center justify-between mt-6">
                            <div class="flex items-center space-x-2">
                                <button id="prevPage" class="px-3 py-2 border border-gray-300 rounded hover:bg-gray-50">
                                    <i class="fas fa-chevron-left"></i>
                                </button>
                                <span id="pageInfo" class="text-sm text-gray-600"></span>
                                <button id="nextPage" class="px-3 py-2 border border-gray-300 rounded hover:bg-gray-50">
                                    <i class="fas fa-chevron-right"></i>
                                </button>
                            </div>
                            <div class="text-sm text-gray-600">
                                <span id="recordsInfo"></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Error State -->
                <div id="errorState" class="hidden bg-red-50 border border-red-200 rounded-lg p-6">
                    <div class="flex items-center">
                        <i class="fas fa-exclamation-triangle text-red-600 text-xl mr-3"></i>
                        <div>
                            <h3 class="text-red-800 font-semibold">Erreur</h3>
                            <p id="errorMessage" class="text-red-700"></p>
                        </div>
                    </div>
                </div>

                <!-- Stock Analyst Section -->
                <div id="stockAnalystSection" class="space-y-8 hidden">
                    <div class="max-w-7xl mx-auto">
                        <!-- Section Header -->
                        <div class="bg-white rounded-lg shadow-lg p-6 mb-8">
                            <div class="flex items-center justify-between mb-4">
                                <h2 class="text-2xl font-bold text-gray-800">
                                    <i class="fas fa-chart-line mr-3"></i>
                                    Analyse d'Actions
                                </h2>
                                <button onclick="showHome()" class="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors">
                                    <i class="fas fa-arrow-left mr-2"></i>Retour \xE0 l'accueil
                                </button>
                            </div>
                            
                            <!-- Search Section -->
                            <div class="mb-8">
                                <div class="flex space-x-4 mb-4">
                                    <div class="flex-1 relative">
                                        <input 
                                            type="text" 
                                            id="searchInput" 
                                            placeholder="Symbole de l'action (ex: AAPL, MSFT, SAP.DE, RNO.PA...)"
                                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                        >
                                        <div id="searchSuggestions" class="absolute z-20 w-full bg-white border border-gray-300 rounded-lg mt-1 hidden shadow-lg max-h-60 overflow-y-auto">
                                        </div>
                                    </div>
                                    <button 
                                        id="searchBtn" 
                                        class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
                                    >
                                        <i class="fas fa-search mr-2"></i>
                                        Analyser
                                    </button>
                                </div>
                                
                                <!-- Quick company buttons -->
                                <div class="flex flex-wrap gap-2">
                                    <button class="quick-stock-btn px-3 py-2 bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 transition-colors text-sm" data-symbol="AAPL">
                                        \u{1F34E} Apple (AAPL)
                                    </button>
                                    <button class="quick-stock-btn px-3 py-2 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 transition-colors text-sm" data-symbol="MSFT">
                                        \u{1FA9F} Microsoft (MSFT)
                                    </button>
                                    <button class="quick-stock-btn px-3 py-2 bg-red-100 text-red-800 rounded-lg hover:bg-red-200 transition-colors text-sm" data-symbol="GOOGL">
                                        \u{1F50D} Google (GOOGL)
                                    </button>
                                    <button class="quick-stock-btn px-3 py-2 bg-purple-100 text-purple-800 rounded-lg hover:bg-purple-200 transition-colors text-sm" data-symbol="RNO.PA">
                                        \u{1F697} Renault (RNO.PA)
                                    </button>
                                    <button class="quick-stock-btn px-3 py-2 bg-yellow-100 text-yellow-800 rounded-lg hover:bg-yellow-200 transition-colors text-sm" data-symbol="SAP.DE">
                                        \u{1F4BC} SAP (SAP.DE)
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Loading State -->
                        <div id="loadingState" class="bg-white rounded-lg shadow-lg p-8 text-center hidden">
                            <div class="flex flex-col items-center">
                                <i class="fas fa-spinner fa-spin text-4xl text-blue-600 mb-4"></i>
                                <h3 class="text-lg font-semibold text-gray-800 mb-2">Analyse en cours...</h3>
                                <p class="text-gray-600">R\xE9cup\xE9ration et traitement des donn\xE9es financi\xE8res</p>
                            </div>
                        </div>
                        
                        <!-- Error State -->
                        <div id="errorState" class="bg-white rounded-lg shadow-lg p-8 text-center hidden">
                            <div class="flex flex-col items-center">
                                <i class="fas fa-exclamation-triangle text-4xl text-red-600 mb-4"></i>
                                <h3 class="text-lg font-semibold text-gray-800 mb-2">Erreur</h3>
                                <p id="errorMessage" class="text-gray-600 mb-4"></p>
                                <button id="retrySearch" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                                    <i class="fas fa-redo mr-2"></i>R\xE9essayer
                                </button>
                            </div>
                        </div>
                        
                        <!-- Results Section -->
                        <div id="resultsSection" class="space-y-6 hidden">
                            <div class="bg-white rounded-lg shadow-lg p-6">
                                <p class="text-gray-600 text-center">Les r\xE9sultats d'analyse appara\xEEtront ici apr\xE8s la recherche.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Company Selection Modal -->
                <div id="companySelectionModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
                        <!-- Modal Header -->
                        <div class="bg-gradient-to-r from-blue-600 to-blue-700 p-6 text-white">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center space-x-3">
                                    <i class="fas fa-chart-line text-2xl"></i>
                                    <h3 class="text-2xl font-bold">S\xE9lection d'Action</h3>
                                </div>
                                <button onclick="closeCompanyModal()" class="text-white hover:text-gray-200 transition-colors">
                                    <i class="fas fa-times text-2xl"></i>
                                </button>
                            </div>
                            <p class="mt-2 text-blue-100">Choisissez une bourse, puis une soci\xE9t\xE9 \xE0 analyser</p>
                        </div>

                        <!-- Modal Content -->
                        <div class="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
                            <!-- Stock Exchange Selection -->
                            <div id="exchangeSelection" class="space-y-4">
                                <h4 class="text-lg font-semibold text-gray-800 mb-4">
                                    <i class="fas fa-globe mr-2"></i>S\xE9lectionnez une Bourse
                                </h4>
                                
                                <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                                    <!-- US Market -->
                                    <button onclick="showExchangeStocks('US')" class="exchange-btn group bg-gradient-to-br from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 border border-blue-200 rounded-lg p-4 transition-all duration-200 hover:shadow-lg">
                                        <div class="text-center">
                                            <div class="text-3xl mb-2">\u{1F1FA}\u{1F1F8}</div>
                                            <div class="font-bold text-gray-800">\xC9tats-Unis</div>
                                            <div class="text-xs text-gray-600 mt-1">NYSE \u2022 NASDAQ</div>
                                            <div class="text-xs text-blue-600 mt-1">20+ soci\xE9t\xE9s</div>
                                        </div>
                                    </button>

                                    <!-- France -->
                                    <button onclick="showExchangeStocks('FR')" class="exchange-btn group bg-gradient-to-br from-red-50 to-red-100 hover:from-red-100 hover:to-red-200 border border-red-200 rounded-lg p-4 transition-all duration-200 hover:shadow-lg">
                                        <div class="text-center">
                                            <div class="text-3xl mb-2">\u{1F1EB}\u{1F1F7}</div>
                                            <div class="font-bold text-gray-800">France</div>
                                            <div class="text-xs text-gray-600 mt-1">Euronext Paris</div>
                                            <div class="text-xs text-red-600 mt-1">CAC 40</div>
                                        </div>
                                    </button>

                                    <!-- Germany -->
                                    <button onclick="showExchangeStocks('DE')" class="exchange-btn group bg-gradient-to-br from-yellow-50 to-yellow-100 hover:from-yellow-100 hover:to-yellow-200 border border-yellow-200 rounded-lg p-4 transition-all duration-200 hover:shadow-lg">
                                        <div class="text-center">
                                            <div class="text-3xl mb-2">\u{1F1E9}\u{1F1EA}</div>
                                            <div class="font-bold text-gray-800">Allemagne</div>
                                            <div class="text-xs text-gray-600 mt-1">Frankfurt</div>
                                            <div class="text-xs text-yellow-600 mt-1">DAX 40</div>
                                        </div>
                                    </button>

                                    <!-- Spain -->
                                    <button onclick="showExchangeStocks('ES')" class="exchange-btn group bg-gradient-to-br from-orange-50 to-orange-100 hover:from-orange-100 hover:to-orange-200 border border-orange-200 rounded-lg p-4 transition-all duration-200 hover:shadow-lg">
                                        <div class="text-center">
                                            <div class="text-3xl mb-2">\u{1F1EA}\u{1F1F8}</div>
                                            <div class="font-bold text-gray-800">Espagne</div>
                                            <div class="text-xs text-gray-600 mt-1">BME</div>
                                            <div class="text-xs text-orange-600 mt-1">IBEX 35</div>
                                        </div>
                                    </button>

                                    <!-- Italy -->
                                    <button onclick="showExchangeStocks('IT')" class="exchange-btn group bg-gradient-to-br from-green-50 to-green-100 hover:from-green-100 hover:to-green-200 border border-green-200 rounded-lg p-4 transition-all duration-200 hover:shadow-lg">
                                        <div class="text-center">
                                            <div class="text-3xl mb-2">\u{1F1EE}\u{1F1F9}</div>
                                            <div class="font-bold text-gray-800">Italie</div>
                                            <div class="text-xs text-gray-600 mt-1">Borsa Italiana</div>
                                            <div class="text-xs text-green-600 mt-1">FTSE MIB</div>
                                        </div>
                                    </button>

                                    <!-- Netherlands -->
                                    <button onclick="showExchangeStocks('NL')" class="exchange-btn group bg-gradient-to-br from-purple-50 to-purple-100 hover:from-purple-100 hover:to-purple-200 border border-purple-200 rounded-lg p-4 transition-all duration-200 hover:shadow-lg">
                                        <div class="text-center">
                                            <div class="text-3xl mb-2">\u{1F1F3}\u{1F1F1}</div>
                                            <div class="font-bold text-gray-800">Pays-Bas</div>
                                            <div class="text-xs text-gray-600 mt-1">Euronext Amsterdam</div>
                                            <div class="text-xs text-purple-600 mt-1">AEX 25</div>
                                        </div>
                                    </button>

                                    <!-- UK -->
                                    <button onclick="showExchangeStocks('GB')" class="exchange-btn group bg-gradient-to-br from-indigo-50 to-indigo-100 hover:from-indigo-100 hover:to-indigo-200 border border-indigo-200 rounded-lg p-4 transition-all duration-200 hover:shadow-lg">
                                        <div class="text-center">
                                            <div class="text-3xl mb-2">\u{1F1EC}\u{1F1E7}</div>
                                            <div class="font-bold text-gray-800">Royaume-Uni</div>
                                            <div class="text-xs text-gray-600 mt-1">London Stock Exchange</div>
                                            <div class="text-xs text-indigo-600 mt-1">FTSE 100</div>
                                        </div>
                                    </button>

                                    <!-- Switzerland -->
                                    <button onclick="showExchangeStocks('CH')" class="exchange-btn group bg-gradient-to-br from-gray-50 to-gray-100 hover:from-gray-100 hover:to-gray-200 border border-gray-200 rounded-lg p-4 transition-all duration-200 hover:shadow-lg">
                                        <div class="text-center">
                                            <div class="text-3xl mb-2">\u{1F1E8}\u{1F1ED}</div>
                                            <div class="font-bold text-gray-800">Suisse</div>
                                            <div class="text-xs text-gray-600 mt-1">SIX Swiss</div>
                                            <div class="text-xs text-gray-600 mt-1">SMI</div>
                                        </div>
                                    </button>
                                </div>

                                <!-- Direct Search Option -->
                                <div class="border-t pt-4 mt-6">
                                    <h5 class="text-md font-semibold text-gray-800 mb-3">
                                        <i class="fas fa-search mr-2"></i>Recherche Directe
                                    </h5>
                                    <div class="flex space-x-3">
                                        <input 
                                            type="text" 
                                            id="directSearchInput" 
                                            placeholder="Tapez le symbole (ex: AAPL, RNO.PA) ou nom (ex: Apple, Renault)"
                                            class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                        >
                                        <button onclick="searchDirectSymbol()" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                                            <i class="fas fa-arrow-right"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Company Selection (Hidden by default) -->
                            <div id="companySelection" class="space-y-4 hidden">
                                <div class="flex items-center justify-between mb-4">
                                    <h4 class="text-lg font-semibold text-gray-800">
                                        <i class="fas fa-building mr-2"></i><span id="selectedExchangeTitle">Soci\xE9t\xE9s</span>
                                    </h4>
                                    <button onclick="backToExchanges()" class="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors">
                                        <i class="fas fa-arrow-left mr-1"></i>Retour
                                    </button>
                                </div>

                                <!-- Companies Grid -->
                                <div id="companiesGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-96 overflow-y-auto">
                                    <!-- Companies will be populated here -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>

            <!-- Footer -->
            <footer class="bg-white border-t border-gray-200 mt-12">
                <div class="max-w-7xl mx-auto px-4 py-6 text-center text-gray-600">
                    <p class="mb-2">
                        <i class="fas fa-info-circle mr-1"></i>
                        Donn\xE9es fournies par Yahoo Finance et autres sources financi\xE8res
                    </p>
                    <p class="text-sm">
                        Les donn\xE9es peuvent avoir un d\xE9lai. Utilisez \xE0 titre informatif uniquement.
                    </p>
                </div>
            </footer>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"><\/script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"><\/script>
        <script>
            // Navigation functions
            window.showHome = function() {
                const dashboard = document.getElementById('dashboardSection');
                const stockAnalyst = document.getElementById('stockAnalystSection');
                const navHome = document.getElementById('navHome');
                const navStockAnalyst = document.getElementById('navStockAnalyst');
                
                if (dashboard) {
                    dashboard.style.display = 'block';
                    dashboard.classList.remove('hidden');
                }
                if (stockAnalyst) {
                    stockAnalyst.style.display = 'none';
                    stockAnalyst.classList.add('hidden');
                }
                
                // Update navigation buttons
                if (navHome) navHome.className = 'px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors';
                if (navStockAnalyst) navStockAnalyst.className = 'px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-blue-100 hover:text-blue-700 transition-colors';
            };
            
            // Stock Analyst function with visual modal interface
            window.showStockAnalyst = function() {
                // Show the visual modal
                const modal = document.getElementById('companySelectionModal');
                const exchangeSelection = document.getElementById('exchangeSelection');
                const companySelection = document.getElementById('companySelection');
                
                if (modal) {
                    // Reset modal state
                    exchangeSelection.classList.remove('hidden');
                    companySelection.classList.add('hidden');
                    modal.classList.remove('hidden');
                    
                    // Clear direct search input
                    const directInput = document.getElementById('directSearchInput');
                    if (directInput) directInput.value = '';
                }
            };
            
            // Modal management functions
            window.closeCompanyModal = function() {
                const modal = document.getElementById('companySelectionModal');
                if (modal) {
                    modal.classList.add('hidden');
                }
            };
            
            window.backToExchanges = function() {
                const exchangeSelection = document.getElementById('exchangeSelection');
                const companySelection = document.getElementById('companySelection');
                
                if (exchangeSelection && companySelection) {
                    exchangeSelection.classList.remove('hidden');
                    companySelection.classList.add('hidden');
                }
            };
            
            // Show stocks for selected exchange
            window.showExchangeStocks = function(exchangeCode) {
                const exchangeSelection = document.getElementById('exchangeSelection');
                const companySelection = document.getElementById('companySelection');
                const companiesGrid = document.getElementById('companiesGrid');
                const exchangeTitle = document.getElementById('selectedExchangeTitle');
                
                if (!exchangeSelection || !companySelection || !companiesGrid) return;
                
                // Hide exchange selection, show company selection
                exchangeSelection.classList.add('hidden');
                companySelection.classList.remove('hidden');
                
                // Clear existing companies
                companiesGrid.innerHTML = '';
                
                let companies = [];
                let title = '';
                
                if (exchangeCode === 'US') {
                    title = '\u{1F1FA}\u{1F1F8} Actions Am\xE9ricaines';
                    companies = [
                        { symbol: 'AAPL', name: 'Apple Inc.', sector: 'technology' },
                        { symbol: 'MSFT', name: 'Microsoft Corporation', sector: 'technology' },
                        { symbol: 'GOOGL', name: 'Alphabet Inc.', sector: 'technology' },
                        { symbol: 'AMZN', name: 'Amazon.com Inc.', sector: 'retail' },
                        { symbol: 'TSLA', name: 'Tesla Inc.', sector: 'automobiles' },
                        { symbol: 'NVDA', name: 'NVIDIA Corporation', sector: 'technology' },
                        { symbol: 'META', name: 'Meta Platforms Inc.', sector: 'technology' },
                        { symbol: 'NFLX', name: 'Netflix Inc.', sector: 'media' },
                        { symbol: 'ORCL', name: 'Oracle Corporation', sector: 'technology' },
                        { symbol: 'CRM', name: 'Salesforce Inc.', sector: 'technology' },
                        { symbol: 'ADBE', name: 'Adobe Inc.', sector: 'technology' },
                        { symbol: 'INTC', name: 'Intel Corporation', sector: 'technology' },
                        { symbol: 'CSCO', name: 'Cisco Systems Inc.', sector: 'technology' },
                        { symbol: 'PEP', name: 'PepsiCo Inc.', sector: 'food_beverage' },
                        { symbol: 'KO', name: 'The Coca-Cola Company', sector: 'food_beverage' },
                        { symbol: 'JNJ', name: 'Johnson & Johnson', sector: 'healthcare' },
                        { symbol: 'PG', name: 'Procter & Gamble Co.', sector: 'personal_household' },
                        { symbol: 'V', name: 'Visa Inc.', sector: 'financial_services' },
                        { symbol: 'MA', name: 'Mastercard Inc.', sector: 'financial_services' },
                        { symbol: 'DIS', name: 'The Walt Disney Company', sector: 'media' }
                    ];
                } else {
                    // European companies from database
                    if (typeof EUROPEAN_STOCKS_COMPLETE !== 'undefined' && EUROPEAN_STOCKS_COMPLETE[exchangeCode]) {
                        const country = EUROPEAN_STOCKS_COMPLETE[exchangeCode];
                        title = country.flag + ' ' + country.country;
                        companies = country.companies || [];
                    }
                }
                
                // Update title
                if (exchangeTitle) {
                    exchangeTitle.textContent = title;
                }
                
                // Create company buttons
                companies.forEach(company => {
                    const button = document.createElement('button');
                    button.className = 'company-btn bg-white border border-gray-200 hover:border-blue-300 hover:bg-blue-50 rounded-lg p-3 text-left transition-all duration-200 hover:shadow-md';
                    button.onclick = () => selectCompany(company.symbol);
                    
                    button.innerHTML = \`
                        <div class="font-semibold text-gray-800 text-sm">\${company.symbol}</div>
                        <div class="text-xs text-gray-600 mt-1">\${company.name}</div>
                        <div class="text-xs text-blue-600 mt-1">\${getSectorIcon(company.sector)} \${getSectorName(company.sector)}</div>
                    \`;
                    
                    companiesGrid.appendChild(button);
                });
                
                if (companies.length === 0) {
                    companiesGrid.innerHTML = '<p class="text-gray-500 text-center col-span-full">Aucune soci\xE9t\xE9 trouv\xE9e pour cette bourse.</p>';
                }
            };
            
            // Select company and launch analysis
            window.selectCompany = function(symbol) {
                closeCompanyModal();
                launchAnalysis(symbol);
            };
            
            // Direct search function
            window.searchDirectSymbol = function() {
                const input = document.getElementById('directSearchInput');
                if (!input || !input.value.trim()) return;
                
                const query = input.value.trim().toUpperCase();
                closeCompanyModal();
                launchAnalysis(query);
            };
            
            // Utility functions
            function getSectorIcon(sector) {
                const icons = {
                    'technology': '\u{1F4BB}',
                    'healthcare': '\u{1F3E5}',
                    'financial_services': '\u{1F3E6}',
                    'banks': '\u{1F3DB}\uFE0F',
                    'insurance': '\u{1F6E1}\uFE0F',
                    'automobiles': '\u{1F697}',
                    'food_beverage': '\u{1F37D}\uFE0F',
                    'retail': '\u{1F6CD}\uFE0F',
                    'media': '\u{1F4FA}',
                    'telecommunications': '\u{1F4F1}',
                    'utilities': '\u26A1',
                    'oil_gas': '\u26FD',
                    'basic_materials': '\u{1F529}',
                    'industrial_goods': '\u{1F3ED}',
                    'real_estate': '\u{1F3E2}',
                    'personal_household': '\u{1F454}',
                    'travel_leisure': '\u2708\uFE0F',
                    'construction_materials': '\u{1F3D7}\uFE0F'
                };
                return icons[sector] || '\u{1F3E2}';
            }
            
            function getSectorName(sector) {
                const names = {
                    'technology': 'Technologie',
                    'healthcare': 'Sant\xE9',
                    'financial_services': 'Services financiers',
                    'banks': 'Banques',
                    'insurance': 'Assurance',
                    'automobiles': 'Automobile',
                    'food_beverage': 'Alimentaire',
                    'retail': 'Commerce',
                    'media': 'M\xE9dias',
                    'telecommunications': 'T\xE9l\xE9coms',
                    'utilities': 'Services publics',
                    'oil_gas': 'P\xE9trole & Gaz',
                    'basic_materials': 'Mat\xE9riaux',
                    'industrial_goods': 'Industrie',
                    'real_estate': 'Immobilier',
                    'personal_household': 'Biens de consommation',
                    'travel_leisure': 'Voyages & Loisirs',
                    'construction_materials': 'Construction'
                };
                return names[sector] || 'Autre';
            }
            
            // Handle Enter key in direct search
            document.addEventListener('DOMContentLoaded', function() {
                const directInput = document.getElementById('directSearchInput');
                if (directInput) {
                    directInput.addEventListener('keypress', function(e) {
                        if (e.key === 'Enter') {
                            searchDirectSymbol();
                        }
                    });
                }
            });
            
            // Helper function to launch analysis
            window.launchAnalysis = function(symbol) {
                // Show Stock Analyst section
                const dashboard = document.getElementById('dashboardSection');
                const stockAnalyst = document.getElementById('stockAnalystSection');
                const navHome = document.getElementById('navHome');
                const navStockAnalyst = document.getElementById('navStockAnalyst');
                
                if (dashboard) {
                    dashboard.style.display = 'none';
                    dashboard.classList.add('hidden');
                }
                if (stockAnalyst) {
                    stockAnalyst.style.display = 'block';
                    stockAnalyst.classList.remove('hidden');
                }
                
                // Update navigation buttons
                if (navHome) navHome.className = 'px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-blue-100 hover:text-blue-700 transition-colors';
                if (navStockAnalyst) navStockAnalyst.className = 'px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors';
                
                // Fill search input and trigger search
                const searchInput = document.getElementById('searchInput');
                if (searchInput) {
                    searchInput.value = symbol;
                    setTimeout(function() {
                        const searchBtn = document.getElementById('searchBtn');
                        if (searchBtn) {
                            searchBtn.click();
                        }
                    }, 100);
                }
                
                console.log('Analyzing company:', symbol);
            };
            
            // Initialize navigation on page load
            setTimeout(function() {
                window.showHome(); // Show home by default
            }, 500);
        <\/script>
        
        <script src="/static/app.js"><\/script>
        <script src="/static/app-extended.js"><\/script>
    </body>
    </html>
  `));
var Ue = new ft();
var hs = Object.assign({ "/src/index.tsx": X });
var vt = false;
for (const [, e] of Object.entries(hs)) e && (Ue.all("*", (t) => {
  let s;
  try {
    s = t.executionCtx;
  } catch {
  }
  return e.fetch(t.req.raw, t.env, s);
}), Ue.notFound((t) => {
  let s;
  try {
    s = t.executionCtx;
  } catch {
  }
  return e.fetch(t.req.raw, t.env, s);
}), vt = true);
if (!vt) throw new Error("Can't import modules from ['/src/index.ts','/src/index.tsx','/app/server.ts']");
var drainBody = /* @__PURE__ */ __name2(async (request, env22, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env22);
  } finally {
    try {
      if (request.body !== null && !request.bodyUsed) {
        const reader = request.body.getReader();
        while (!(await reader.read()).done) {
        }
      }
    } catch (e) {
      console.error("Failed to drain the unused request body.", e);
    }
  }
}, "drainBody");
var middleware_ensure_req_body_drained_default = drainBody;
function reduceError(e) {
  return {
    name: e?.name,
    message: e?.message ?? String(e),
    stack: e?.stack,
    cause: e?.cause === void 0 ? void 0 : reduceError(e.cause)
  };
}
__name(reduceError, "reduceError");
__name2(reduceError, "reduceError");
var jsonError = /* @__PURE__ */ __name2(async (request, env22, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env22);
  } catch (e) {
    const error32 = reduceError(e);
    return Response.json(error32, {
      status: 500,
      headers: { "MF-Experimental-Error-Stack": "true" }
    });
  }
}, "jsonError");
var middleware_miniflare3_json_error_default = jsonError;
var __INTERNAL_WRANGLER_MIDDLEWARE__ = [
  middleware_ensure_req_body_drained_default,
  middleware_miniflare3_json_error_default
];
var middleware_insertion_facade_default = Ue;
var __facade_middleware__ = [];
function __facade_register__(...args) {
  __facade_middleware__.push(...args.flat());
}
__name(__facade_register__, "__facade_register__");
__name2(__facade_register__, "__facade_register__");
function __facade_invokeChain__(request, env22, ctx, dispatch, middlewareChain) {
  const [head, ...tail] = middlewareChain;
  const middlewareCtx = {
    dispatch,
    next(newRequest, newEnv) {
      return __facade_invokeChain__(newRequest, newEnv, ctx, dispatch, tail);
    }
  };
  return head(request, env22, ctx, middlewareCtx);
}
__name(__facade_invokeChain__, "__facade_invokeChain__");
__name2(__facade_invokeChain__, "__facade_invokeChain__");
function __facade_invoke__(request, env22, ctx, dispatch, finalMiddleware) {
  return __facade_invokeChain__(request, env22, ctx, dispatch, [
    ...__facade_middleware__,
    finalMiddleware
  ]);
}
__name(__facade_invoke__, "__facade_invoke__");
__name2(__facade_invoke__, "__facade_invoke__");
var __Facade_ScheduledController__ = class ___Facade_ScheduledController__ {
  static {
    __name(this, "___Facade_ScheduledController__");
  }
  constructor(scheduledTime, cron, noRetry) {
    this.scheduledTime = scheduledTime;
    this.cron = cron;
    this.#noRetry = noRetry;
  }
  static {
    __name2(this, "__Facade_ScheduledController__");
  }
  #noRetry;
  noRetry() {
    if (!(this instanceof ___Facade_ScheduledController__)) {
      throw new TypeError("Illegal invocation");
    }
    this.#noRetry();
  }
};
function wrapExportedHandler(worker) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return worker;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  const fetchDispatcher = /* @__PURE__ */ __name2(function(request, env22, ctx) {
    if (worker.fetch === void 0) {
      throw new Error("Handler does not export a fetch() function.");
    }
    return worker.fetch(request, env22, ctx);
  }, "fetchDispatcher");
  return {
    ...worker,
    fetch(request, env22, ctx) {
      const dispatcher = /* @__PURE__ */ __name2(function(type, init) {
        if (type === "scheduled" && worker.scheduled !== void 0) {
          const controller = new __Facade_ScheduledController__(
            Date.now(),
            init.cron ?? "",
            () => {
            }
          );
          return worker.scheduled(controller, env22, ctx);
        }
      }, "dispatcher");
      return __facade_invoke__(request, env22, ctx, dispatcher, fetchDispatcher);
    }
  };
}
__name(wrapExportedHandler, "wrapExportedHandler");
__name2(wrapExportedHandler, "wrapExportedHandler");
function wrapWorkerEntrypoint(klass) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return klass;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  return class extends klass {
    #fetchDispatcher = /* @__PURE__ */ __name2((request, env22, ctx) => {
      this.env = env22;
      this.ctx = ctx;
      if (super.fetch === void 0) {
        throw new Error("Entrypoint class does not define a fetch() function.");
      }
      return super.fetch(request);
    }, "#fetchDispatcher");
    #dispatcher = /* @__PURE__ */ __name2((type, init) => {
      if (type === "scheduled" && super.scheduled !== void 0) {
        const controller = new __Facade_ScheduledController__(
          Date.now(),
          init.cron ?? "",
          () => {
          }
        );
        return super.scheduled(controller);
      }
    }, "#dispatcher");
    fetch(request) {
      return __facade_invoke__(
        request,
        this.env,
        this.ctx,
        this.#dispatcher,
        this.#fetchDispatcher
      );
    }
  };
}
__name(wrapWorkerEntrypoint, "wrapWorkerEntrypoint");
__name2(wrapWorkerEntrypoint, "wrapWorkerEntrypoint");
var WRAPPED_ENTRY;
if (typeof middleware_insertion_facade_default === "object") {
  WRAPPED_ENTRY = wrapExportedHandler(middleware_insertion_facade_default);
} else if (typeof middleware_insertion_facade_default === "function") {
  WRAPPED_ENTRY = wrapWorkerEntrypoint(middleware_insertion_facade_default);
}
var middleware_loader_entry_default = WRAPPED_ENTRY;

// node_modules/wrangler/templates/pages-dev-util.ts
function isRoutingRuleMatch(pathname, routingRule) {
  if (!pathname) {
    throw new Error("Pathname is undefined.");
  }
  if (!routingRule) {
    throw new Error("Routing rule is undefined.");
  }
  const ruleRegExp = transformRoutingRuleToRegExp(routingRule);
  return pathname.match(ruleRegExp) !== null;
}
__name(isRoutingRuleMatch, "isRoutingRuleMatch");
function transformRoutingRuleToRegExp(rule) {
  let transformedRule;
  if (rule === "/" || rule === "/*") {
    transformedRule = rule;
  } else if (rule.endsWith("/*")) {
    transformedRule = `${rule.substring(0, rule.length - 2)}(/*)?`;
  } else if (rule.endsWith("/")) {
    transformedRule = `${rule.substring(0, rule.length - 1)}(/)?`;
  } else if (rule.endsWith("*")) {
    transformedRule = rule;
  } else {
    transformedRule = `${rule}(/)?`;
  }
  transformedRule = `^${transformedRule.replaceAll(/\./g, "\\.").replaceAll(/\*/g, ".*")}$`;
  return new RegExp(transformedRule);
}
__name(transformRoutingRuleToRegExp, "transformRoutingRuleToRegExp");

// .wrangler/tmp/pages-yPbr1B/ldwsi3ufds.js
var define_ROUTES_default = { version: 1, include: ["/*"], exclude: ["/static/*"] };
var routes = define_ROUTES_default;
var pages_dev_pipeline_default = {
  fetch(request, env3, context3) {
    const { pathname } = new URL(request.url);
    for (const exclude of routes.exclude) {
      if (isRoutingRuleMatch(pathname, exclude)) {
        return env3.ASSETS.fetch(request);
      }
    }
    for (const include of routes.include) {
      if (isRoutingRuleMatch(pathname, include)) {
        const workerAsHandler = middleware_loader_entry_default;
        if (workerAsHandler.fetch === void 0) {
          throw new TypeError("Entry point missing `fetch` handler");
        }
        return workerAsHandler.fetch(request, env3, context3);
      }
    }
    return env3.ASSETS.fetch(request);
  }
};

// node_modules/wrangler/templates/middleware/middleware-ensure-req-body-drained.ts
var drainBody2 = /* @__PURE__ */ __name(async (request, env3, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env3);
  } finally {
    try {
      if (request.body !== null && !request.bodyUsed) {
        const reader = request.body.getReader();
        while (!(await reader.read()).done) {
        }
      }
    } catch (e) {
      console.error("Failed to drain the unused request body.", e);
    }
  }
}, "drainBody");
var middleware_ensure_req_body_drained_default2 = drainBody2;

// node_modules/wrangler/templates/middleware/middleware-miniflare3-json-error.ts
function reduceError2(e) {
  return {
    name: e?.name,
    message: e?.message ?? String(e),
    stack: e?.stack,
    cause: e?.cause === void 0 ? void 0 : reduceError2(e.cause)
  };
}
__name(reduceError2, "reduceError");
var jsonError2 = /* @__PURE__ */ __name(async (request, env3, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env3);
  } catch (e) {
    const error4 = reduceError2(e);
    return Response.json(error4, {
      status: 500,
      headers: { "MF-Experimental-Error-Stack": "true" }
    });
  }
}, "jsonError");
var middleware_miniflare3_json_error_default2 = jsonError2;

// .wrangler/tmp/bundle-apQniz/middleware-insertion-facade.js
var __INTERNAL_WRANGLER_MIDDLEWARE__2 = [
  middleware_ensure_req_body_drained_default2,
  middleware_miniflare3_json_error_default2
];
var middleware_insertion_facade_default2 = pages_dev_pipeline_default;

// node_modules/wrangler/templates/middleware/common.ts
var __facade_middleware__2 = [];
function __facade_register__2(...args) {
  __facade_middleware__2.push(...args.flat());
}
__name(__facade_register__2, "__facade_register__");
function __facade_invokeChain__2(request, env3, ctx, dispatch, middlewareChain) {
  const [head, ...tail] = middlewareChain;
  const middlewareCtx = {
    dispatch,
    next(newRequest, newEnv) {
      return __facade_invokeChain__2(newRequest, newEnv, ctx, dispatch, tail);
    }
  };
  return head(request, env3, ctx, middlewareCtx);
}
__name(__facade_invokeChain__2, "__facade_invokeChain__");
function __facade_invoke__2(request, env3, ctx, dispatch, finalMiddleware) {
  return __facade_invokeChain__2(request, env3, ctx, dispatch, [
    ...__facade_middleware__2,
    finalMiddleware
  ]);
}
__name(__facade_invoke__2, "__facade_invoke__");

// .wrangler/tmp/bundle-apQniz/middleware-loader.entry.ts
var __Facade_ScheduledController__2 = class ___Facade_ScheduledController__2 {
  constructor(scheduledTime, cron, noRetry) {
    this.scheduledTime = scheduledTime;
    this.cron = cron;
    this.#noRetry = noRetry;
  }
  static {
    __name(this, "__Facade_ScheduledController__");
  }
  #noRetry;
  noRetry() {
    if (!(this instanceof ___Facade_ScheduledController__2)) {
      throw new TypeError("Illegal invocation");
    }
    this.#noRetry();
  }
};
function wrapExportedHandler2(worker) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__2 === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__2.length === 0) {
    return worker;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__2) {
    __facade_register__2(middleware);
  }
  const fetchDispatcher = /* @__PURE__ */ __name(function(request, env3, ctx) {
    if (worker.fetch === void 0) {
      throw new Error("Handler does not export a fetch() function.");
    }
    return worker.fetch(request, env3, ctx);
  }, "fetchDispatcher");
  return {
    ...worker,
    fetch(request, env3, ctx) {
      const dispatcher = /* @__PURE__ */ __name(function(type, init) {
        if (type === "scheduled" && worker.scheduled !== void 0) {
          const controller = new __Facade_ScheduledController__2(
            Date.now(),
            init.cron ?? "",
            () => {
            }
          );
          return worker.scheduled(controller, env3, ctx);
        }
      }, "dispatcher");
      return __facade_invoke__2(request, env3, ctx, dispatcher, fetchDispatcher);
    }
  };
}
__name(wrapExportedHandler2, "wrapExportedHandler");
function wrapWorkerEntrypoint2(klass) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__2 === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__2.length === 0) {
    return klass;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__2) {
    __facade_register__2(middleware);
  }
  return class extends klass {
    #fetchDispatcher = /* @__PURE__ */ __name((request, env3, ctx) => {
      this.env = env3;
      this.ctx = ctx;
      if (super.fetch === void 0) {
        throw new Error("Entrypoint class does not define a fetch() function.");
      }
      return super.fetch(request);
    }, "#fetchDispatcher");
    #dispatcher = /* @__PURE__ */ __name((type, init) => {
      if (type === "scheduled" && super.scheduled !== void 0) {
        const controller = new __Facade_ScheduledController__2(
          Date.now(),
          init.cron ?? "",
          () => {
          }
        );
        return super.scheduled(controller);
      }
    }, "#dispatcher");
    fetch(request) {
      return __facade_invoke__2(
        request,
        this.env,
        this.ctx,
        this.#dispatcher,
        this.#fetchDispatcher
      );
    }
  };
}
__name(wrapWorkerEntrypoint2, "wrapWorkerEntrypoint");
var WRAPPED_ENTRY2;
if (typeof middleware_insertion_facade_default2 === "object") {
  WRAPPED_ENTRY2 = wrapExportedHandler2(middleware_insertion_facade_default2);
} else if (typeof middleware_insertion_facade_default2 === "function") {
  WRAPPED_ENTRY2 = wrapWorkerEntrypoint2(middleware_insertion_facade_default2);
}
var middleware_loader_entry_default2 = WRAPPED_ENTRY2;
export {
  __INTERNAL_WRANGLER_MIDDLEWARE__2 as __INTERNAL_WRANGLER_MIDDLEWARE__,
  middleware_loader_entry_default2 as default
};
//# sourceMappingURL=ldwsi3ufds.js.map
